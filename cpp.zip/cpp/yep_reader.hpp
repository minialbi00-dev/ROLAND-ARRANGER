#pragma once
#include "ppf_reader.hpp"
#include <array>
#include <cstddef>
#include <cstdint>
#include <string>
#include <vector>

namespace arranger {

struct YepSummary {
    std::size_t vprm_bytes = 0;
    std::size_t vwdt_bytes = 0;
    std::size_t voice_count = 0;
    std::size_t zone_count = 0;
    std::size_t sample_block_count = 0;
    std::size_t mapped_zone_count = 0;
    std::size_t unresolved_zone_count = 0;
};

struct YepVoiceDescriptor {
    std::size_t voice_index = 0;
    std::string title;
    std::string voice_type = "Voice";
    std::array<std::uint8_t, 3> source_voice_id{};
    std::size_t first_zone_index = 0;
    std::size_t zone_count = 0;
};

class YepReader {
public:
    bool open(const std::string& path, std::string& error);
    void clear() noexcept;

    const YepSummary& summary() const noexcept { return summary_; }
    const std::vector<YepVoiceDescriptor>& voices() const noexcept { return voices_; }
    const std::vector<VoiceZone>& voice_zones() const noexcept { return zones_; }
    const std::string& path() const noexcept { return path_; }

    bool load_voice_zone_sample(std::size_t voice_index,
                                std::size_t zone_index,
                                PpfSample& out,
                                std::string& error) const;

private:
    struct ZoneSampleRef {
        std::size_t vwdt_left_byte = 0;
        std::size_t vwdt_right_byte = 0;
        std::size_t frames = 0;
        std::size_t right_frames = 0;
        std::uint8_t channels = 1;
        std::uint32_t sample_rate = 44100;
        std::uint8_t format = 0;
    };

    struct ByteRange { std::size_t offset = 0; std::size_t size = 0; };

    std::string path_;
    std::vector<std::uint8_t> file_data_;
    std::vector<std::uint8_t> vprm_;
    std::vector<std::uint8_t> vwdt_;
    std::vector<YepVoiceDescriptor> voices_;
    std::vector<VoiceZone> zones_;
    std::vector<ZoneSampleRef> refs_;
    YepSummary summary_{};

    static std::uint16_t be16(const std::uint8_t* p) noexcept;
    static std::uint32_t be32(const std::uint8_t* p) noexcept;
    static std::int16_t be16s(const std::uint8_t* p) noexcept;
    static std::int8_t s8(std::uint8_t x) noexcept;
    static std::string voice_title(std::size_t index, const std::array<std::uint8_t,3>& id);
    static bool read_chunk(const std::vector<std::uint8_t>& data,
                           std::size_t& pos,
                           std::string& tag,
                           std::vector<std::uint8_t>& payload);
    static bool safe_span(std::size_t offset, std::size_t bytes, std::size_t total) noexcept;
    static std::vector<std::int16_t> extract_be16_pcm(const std::vector<std::uint8_t>& src,
                                                      std::size_t byte_offset,
                                                      std::size_t frames);
    static std::vector<std::int16_t> extract_yep_pcm(const std::vector<std::uint8_t>& src,
                                                     std::size_t byte_offset,
                                                     std::size_t frames);
};

} // namespace arranger
