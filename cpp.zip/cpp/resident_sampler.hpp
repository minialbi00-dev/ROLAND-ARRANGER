#pragma once
#include "voice_types.hpp"
#include <array>
#include <cstddef>
#include <cstdint>
#include <atomic>

namespace arranger {

struct SamplerVoiceState {
    bool active = false;
    bool loop_enabled = false;
    bool releasing = false;
    bool key_down = true;
    bool sustain_held = false;
    ResidentSamplePtr sample;
    double source_pos = 0.0;
    double step = 1.0;
    double base_pitch_ratio = 1.0;
    float pitch_bend_norm = 0.0f;
    float pitch_bend_range = 2.0f;
    float modulation = 0.0f;
    double modulation_phase = 0.0;
    float expression = 1.0f;
    float gain = 1.0f;
    float pan = 0.0f; // -1..+1
    std::uint8_t note = 60;
    std::uint8_t velocity = 127;
    std::uint8_t part_index = 0;
    std::uint8_t alternate_group = 0;
    bool receive_note_off = true;
    bool receive_note_on = true;
    std::size_t loop_start = 0;
    std::size_t loop_end = 0;
    std::uint64_t age = 0;
    double release_remaining_seconds = 0.0;
};

class ResidentSampler {
public:
    static constexpr std::size_t kMaxVoices = 128;
    static constexpr double kDefaultReleaseSeconds = 0.050;

    // Backward-compatible one-shot note_on.
    bool note_on(const ResidentSamplePtr& sample,
                 std::uint8_t note = 60,
                 std::uint8_t velocity = 127,
                 float gain = 1.0f,
                 float pan = 0.0f,
                 double pitch_ratio = 1.0);

    // V0.13 note_on with per-zone loop metadata.
    bool note_on(const ResidentSamplePtr& sample,
                 std::uint8_t note,
                 std::uint8_t velocity,
                 float gain,
                 float pan,
                 double pitch_ratio,
                 std::size_t loop_start_frame,
                 std::size_t loop_end_frame,
                 bool loop_enabled);

    // Releases all active voices matching the MIDI note. Kept for backward compatibility.
    void note_off(std::uint8_t note) noexcept;
    void all_notes_off() noexcept;

    // V0.15 low-level slot operations used by PolyphonicVoiceManager.
    bool note_on_at_slot(std::size_t slot,
                         const ResidentSamplePtr& sample,
                         std::uint8_t note,
                         std::uint8_t velocity,
                         float gain,
                         float pan,
                         double pitch_ratio,
                         std::size_t loop_start_frame,
                         std::size_t loop_end_frame,
                         bool loop_enabled,
                         std::uint8_t part_index = 0,
                         std::uint8_t alternate_group = 0,
                         bool receive_note_off = true,
                         bool receive_note_on = true) noexcept;
    void note_off_slot(std::size_t slot) noexcept;
    void defer_note_off_slot(std::size_t slot) noexcept;
    void release_sustained_slot(std::size_t slot) noexcept;
    // Immediately stop an active voice carrying this Yamaha Alternate Group.
    // Yamaha uses this for mutually exclusive drum keys such as open/closed hats.
    void choke_alternate_group(std::size_t part, std::uint8_t alternate_group) noexcept;
    bool voice_active(std::size_t slot) const noexcept;
    bool voice_releasing(std::size_t slot) const noexcept;
    std::uint8_t voice_note(std::size_t slot) const noexcept;
    std::uint8_t voice_part_index(std::size_t slot) const noexcept;
    std::uint8_t voice_alternate_group(std::size_t slot) const noexcept;
    bool voice_receive_note_off(std::size_t slot) const noexcept;
    bool voice_receive_note_on(std::size_t slot) const noexcept;
    bool voice_key_down(std::size_t slot) const noexcept;
    bool voice_sustain_held(std::size_t slot) const noexcept;
    float voice_pitch_bend(std::size_t slot) const noexcept;
    float voice_modulation(std::size_t slot) const noexcept;
    float voice_expression(std::size_t slot) const noexcept;

    void set_part_pitch_bend(std::size_t part, float normalized, float range_semitones) noexcept;
    void set_part_modulation(std::size_t part, float normalized) noexcept;
    void set_part_expression(std::size_t part, float normalized) noexcept;

    // Existing monolithic realtime render path.
    // Realtime render path: stereo interleaved float32, additive mix into out.
    // No locks and no allocations are taken here.
    std::size_t render(float* out_stereo, std::size_t frames, int output_rate) noexcept;

    // V0.17: render one fixed stereo bus per arranger part.
    // Layout per frame: 16 parts * 2 floats. No allocations or locks.
    std::size_t render_to_parts(float* out_part_stereo, std::size_t frames, int output_rate) noexcept;

    std::size_t active_voice_count() const noexcept;
    std::size_t releasing_voice_count() const noexcept;

    // Select a slot for voice stealing. Prefer an unused slot, then the oldest
    // releasing voice, then the oldest active voice. The caller must clear any
    // external note->slot mapping before reusing a returned active slot.
    std::size_t find_reclaimable_slot() const noexcept;

    // V0.33 diagnostic telemetry: observe the PPF part bus immediately before
    // the existing per-part clamp. Telemetry only; no DSP change.
    void reset_signal_telemetry() noexcept;
    std::uint64_t preclamp_over_unity_samples() const noexcept {
        return preclamp_over_unity_samples_.load(std::memory_order_acquire);
    }
    std::uint64_t preclamp_nonfinite_samples() const noexcept {
        return preclamp_nonfinite_samples_.load(std::memory_order_acquire);
    }
    std::uint64_t preclamp_measured_samples() const noexcept {
        return preclamp_measured_samples_.load(std::memory_order_acquire);
    }
    std::uint64_t preclamp_max_peak_milli() const noexcept {
        return preclamp_max_peak_milli_.load(std::memory_order_acquire);
    }
    std::uint64_t preclamp_part_over_unity(std::size_t part) const noexcept {
        return part < kPartCount ? preclamp_part_over_unity_[part].load(std::memory_order_acquire) : 0;
    }
    std::uint64_t preclamp_part_max_peak_milli(std::size_t part) const noexcept {
        return part < kPartCount ? preclamp_part_max_peak_milli_[part].load(std::memory_order_acquire) : 0;
    }

    static constexpr std::size_t kPartCount = 16;

private:
    static void atomic_max(std::atomic<std::uint64_t>& target, std::uint64_t value) noexcept;
    std::array<SamplerVoiceState, kMaxVoices> voices_{};
    std::uint64_t next_age_ = 1;
    std::atomic<std::uint64_t> preclamp_over_unity_samples_{0};
    std::atomic<std::uint64_t> preclamp_nonfinite_samples_{0};
    std::atomic<std::uint64_t> preclamp_measured_samples_{0};
    std::atomic<std::uint64_t> preclamp_max_peak_milli_{0};
    std::array<std::atomic<std::uint64_t>, kPartCount> preclamp_part_over_unity_{};
    std::array<std::atomic<std::uint64_t>, kPartCount> preclamp_part_max_peak_milli_{};
};

} // namespace arranger
