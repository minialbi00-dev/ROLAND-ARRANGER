#pragma once

#include <stddef.h>
#include <stdint.h>

#ifdef _WIN32
#define YAC_EXPORT extern "C" __declspec(dllexport)
#define YAC_CALL __cdecl
#else
#define YAC_EXPORT extern "C"
#define YAC_CALL
#endif

#ifdef __cplusplus
extern "C" {
#endif

typedef struct YacmSlot {
    uint8_t ntr;
    uint8_t ntt;
    uint8_t high_key;
    uint8_t note_lo;
    uint8_t note_hi;
    uint8_t rtr;
} YacmSlot;

typedef struct YacmRule {
    uint8_t source_root;
    uint8_t source_type;
    uint8_t destination_channel;
    uint8_t slot_count;
    YacmSlot slots[3];
} YacmRule;

// Returns 1 when a slot/rule transformed the note; 0 when the supplied rule
// has no usable slots or output storage is invalid.
YAC_EXPORT int YAC_CALL yac_transform_note(const YacmRule* rule,
                                            uint8_t input_note,
                                            uint8_t chord_root_pc,
                                            uint8_t chord_type,
                                            uint8_t chord_bass_pc,
                                            uint8_t chord_bass_valid,
                                            uint8_t* output_note);

#ifdef __cplusplus
}
#endif
