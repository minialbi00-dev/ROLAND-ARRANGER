#include "installed_style_voice_router.hpp"

namespace arranger {

bool InstalledStyleVoiceRouter::is_bank_cc(const YamahaStyleMidiEvent& e) noexcept {
    if ((e.status & 0xF0u) != 0xB0u) return false;
    return e.data_len >= 2 && (e.data1 == 0u || e.data1 == 32u);
}

bool InstalledStyleVoiceRouter::is_program_change(const YamahaStyleMidiEvent& e) noexcept {
    return (e.status & 0xF0u) == 0xC0u && e.data_len >= 1;
}

std::uint8_t InstalledStyleVoiceRouter::channel_for_event(
    const YamahaStyleRuntime& style,
    const YamahaStyleMidiEvent& e) noexcept {
    const std::uint8_t src = static_cast<std::uint8_t>(e.status & 0x0Fu);
    if (src >= 16u) return src;
    for (const auto& section : style.sections()) {
        if (e.tick < section.start_tick || e.tick >= section.end_tick) continue;
        if (const auto* rule = style.find_casm_rule(section.name, src)) {
            if (rule->explicit_casm) {
                return static_cast<std::uint8_t>(rule->destination_channel & 0x0Fu);
            }
        }
        break;
    }
    if (const auto* full = style.find_casm_rule("FULL STYLE", src)) {
        if (full->explicit_casm) {
            return static_cast<std::uint8_t>(full->destination_channel & 0x0Fu);
        }
    }
    return src;
}

bool InstalledStyleVoiceRouter::scan(
    const YamahaStyleRuntime& style,
    const InstalledVoiceCatalog& catalog,
    std::vector<InstalledVoiceResolution>& out,
    std::string& error) const {
    out.clear();
    error.clear();

    std::array<std::uint8_t, 16> msb{};
    std::array<std::uint8_t, 16> lsb{};
    std::array<std::uint8_t, 16> program{};
    std::array<bool, 16> program_set{};

    for (const auto& e : style.events()) {
        const std::uint8_t source_ch = static_cast<std::uint8_t>(e.status & 0x0Fu);
        if (source_ch >= 16u) continue;
        const std::uint8_t logical_ch = channel_for_event(style, e);
        bool should_resolve = false;

        if (is_bank_cc(e)) {
            if (e.data1 == 0u) msb[logical_ch] = static_cast<std::uint8_t>(e.data2 & 0x7Fu);
            else lsb[logical_ch] = static_cast<std::uint8_t>(e.data2 & 0x7Fu);
            should_resolve = program_set[logical_ch];
        } else if (is_program_change(e)) {
            program[logical_ch] = static_cast<std::uint8_t>(e.data1 & 0x7Fu);
            program_set[logical_ch] = true;
            should_resolve = true;
        }
        if (!should_resolve) continue;

        StyleVoiceCall call{};
        call.tick = e.tick;
        call.channel = logical_ch;
        call.msb = msb[logical_ch];
        call.lsb = lsb[logical_ch];
        call.program = program[logical_ch];

        InstalledVoiceResolution resolution;
        if (!catalog.resolve_style_call(call, resolution, error)) return false;
        out.push_back(resolution);
    }

    if (out.empty()) {
        error = "Style contains no Bank Select / Program Change sequence";
        return false;
    }
    return true;
}

} // namespace arranger
