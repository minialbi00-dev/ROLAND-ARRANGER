#pragma once

#include <cstdint>
#include <set>
#include <string>
#include <vector>

namespace arranger {

// Yamaha PSR-SX920-style chord fingering families exposed by the GUI/native
// bridge. Mode 8 is retained as a project compatibility option for older
// Yamaha "Fingered 1/2" semantics; it is not an official SX920 selection.
enum class PerformanceFingerMode : std::uint8_t {
    SingleFinger = 0,
    Fingered = 1,
    FingeredOnBass = 2,
    MultiFinger = 3,
    AIFingered = 4,
    FullKeyboard = 5,
    AIFullKeyboard = 6,
    SmartChord = 7,
    Fingered12 = 8,
};

struct PerformanceRuntimeState {
    bool acmp_enabled = false;
    bool note_gate = true;
    std::uint8_t finger_mode = static_cast<std::uint8_t>(PerformanceFingerMode::Fingered);
    int transpose = 0;
    std::uint8_t chord_root_pc = 0;
    std::uint8_t chord_type = 0;
    std::string chord_name = "C";
    std::vector<std::uint8_t> held_notes;
    std::uint8_t chord_bass_pc = 0;
    bool chord_bass_valid = false;
    std::uint8_t split_point = 42; // Yamaha key naming: F#1 = MIDI 42 (Yamaha C3 = MIDI 60). Project split boundary.
    std::uint8_t smart_chord_key_pc = 0; // C major by default.
    std::uint8_t smart_chord_type = 0; // 0=Standard, 1=Pop, 2=Jazz, 3=Dance, 4=Basic
    bool smart_chord_minor = false;
    std::uint64_t note_on_count = 0;
    std::uint64_t note_off_count = 0;
};

class PerformanceRuntime {
public:
    PerformanceRuntime() = default;

    void reset() noexcept;
    void set_acmp(bool enabled) noexcept { state_.acmp_enabled = enabled; }
    void set_transpose(int semitones) noexcept;
    void set_chord(std::uint8_t root_pc, std::uint8_t chord_type, const std::string& chord_name = "") noexcept;
    void set_finger_mode(std::uint8_t mode) noexcept;
    void set_split_point(int note) noexcept;
    void set_smart_chord_key(int root_pc) noexcept;
    void set_smart_chord_type(std::uint8_t type) noexcept;
    void set_smart_chord_minor(bool minor) noexcept;
    void set_note_gate(bool enabled) noexcept { state_.note_gate = enabled; }

    // Decode one channel voice MIDI message. Chord/fingering logic is owned
    // entirely by this C++ class; Python only transports bytes/state.
    void feed_midi(std::uint8_t status, std::uint8_t data1, std::uint8_t data2) noexcept;
    void note_on(std::uint8_t note, std::uint8_t velocity) noexcept;
    void note_off(std::uint8_t note) noexcept;
    void clear_notes() noexcept;

    const PerformanceRuntimeState& state() const noexcept { return state_; }
    static const char* chord_name_for(std::uint8_t root_pc, std::uint8_t chord_type) noexcept;
    static const char* finger_mode_name(std::uint8_t mode) noexcept;
    static const char* smart_chord_type_name(std::uint8_t type) noexcept;

private:
    struct DetectedChord {
        bool valid = false;
        int root_pc = 0;
        int type = 0;
        std::string name = "C";
        int bass_note = -1;
    };

    PerformanceRuntimeState state_{};
    std::set<std::uint8_t> held_;

    // Last confirmed chord is the context used by AI Fingered / AI Full
    // Keyboard when fewer than three notes are supplied.
    bool have_last_chord_ = false;
    int last_root_pc_ = 0;
    int last_chord_type_ = 0;
    std::string last_chord_name_ = "C";

    static int normalize_pc(int pc) noexcept;
    static std::string note_name(std::uint8_t note);
    static const char* suffix_for_type(int type) noexcept;
    static int chord_type_for_suffix(const std::string& suffix) noexcept;
    static bool is_black_pc(int pc) noexcept;
    static bool is_white_pc(int pc) noexcept;
    static int nearest_left_key(int root_note, bool black_key) noexcept;

    std::vector<std::uint8_t> notes_in_detection_area() const;
    void recompute_chord(bool preserve_previous_on_invalid = true) noexcept;
    DetectedChord detect_single_finger(const std::vector<std::uint8_t>& notes) const noexcept;
    DetectedChord detect_fingered(const std::vector<std::uint8_t>& notes, bool allow_melody_extras, bool suppress_extended = false) const noexcept;
    DetectedChord detect_smart_chord(const std::vector<std::uint8_t>& notes) const noexcept;
    DetectedChord infer_ai(const std::vector<std::uint8_t>& notes, const DetectedChord& strict) const noexcept;
    void apply_detected(const DetectedChord& detected, bool bass_aware) noexcept;
    void keep_previous_or_major(const std::vector<std::uint8_t>& notes) noexcept;
};

} // namespace arranger
