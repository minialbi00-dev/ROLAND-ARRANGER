#pragma once

#include "ppf_reader.hpp"
#include "voice_types.hpp"

#include <cstddef>
#include <cstdint>
#include <string>
#include <unordered_map>
#include <vector>

namespace arranger {

// Native C++ runtime ownership for one resident PPF Voice.
// The resolver is deliberately independent from GUI code and from the
// residency/materialization policy. It only decides which already-resident
// VoiceZone is eligible for a NOTE ON.
struct PpfRuntimeZone {
    VoiceZone zone{};
    ResidentSamplePtr sample;
};

class PpfRuntimeVoice {
public:
    std::size_t bank_id = 0;
    std::size_t source_index = 0;
    std::vector<PpfRuntimeZone> zones;

    bool empty() const noexcept { return zones.empty(); }
    std::size_t zone_count() const noexcept { return zones.size(); }

    // Exact PPF runtime selection:
    //   1. MIDI note must be inside the declared KeyBank range.
    //   2. MIDI velocity must be inside the declared velocity layer range.
    //   3. There is NO key-only fallback when velocity misses every layer.
    //   4. When multiple layers overlap, choose deterministically by the
    //      narrowest key span, then narrowest velocity span, then the highest
    //      velocity lower-bound. Stable metadata indices break any remaining tie.
    const PpfRuntimeZone* resolve(int note, int velocity) const noexcept;
};

class PpfRuntime {
public:
    void clear() noexcept;

    bool upsert_voice(PpfRuntimeVoice voice, std::string& error);
    bool remove_voice(std::size_t bank_id, std::size_t source_index) noexcept;
    std::size_t remove_bank(std::size_t bank_id) noexcept;

    const PpfRuntimeVoice* find_voice(std::size_t bank_id,
                                      std::size_t source_index) const noexcept;
    PpfRuntimeVoice* find_voice(std::size_t bank_id,
                                std::size_t source_index) noexcept;

    const PpfRuntimeZone* resolve(std::size_t bank_id,
                                  std::size_t source_index,
                                  int note,
                                  int velocity) const noexcept;

    std::size_t voice_count() const noexcept { return voices_.size(); }
    std::size_t zone_count() const noexcept;

    // Used by lifecycle code to compute memory/diagnostic residency.
    template <typename Fn>
    void for_each_voice(Fn&& fn) const {
        for (const auto& entry : voices_) fn(entry.second);
    }

private:
    static std::uint64_t make_key(std::size_t bank_id, std::size_t source_index) noexcept;
    std::unordered_map<std::uint64_t, PpfRuntimeVoice> voices_;
};

} // namespace arranger
