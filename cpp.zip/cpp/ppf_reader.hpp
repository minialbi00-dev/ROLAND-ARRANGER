#pragma once
#include <cstdint>
#include <string>
#include <vector>
#include <unordered_map>

namespace arranger {

struct PpfSample {
    std::string uid;
    std::vector<std::int16_t> pcm;
    int sample_rate = 44100;
    int channels = 1;
    bool from_first_voice = false;
    std::string voice_title;
};

struct PpfSummary {
    std::size_t audio_count = 0;
    std::size_t voice_count = 0;
    std::size_t voice_zone_count = 0;
};

struct PpfVoiceDescriptor {
    std::size_t voice_index = 0;
    std::string title;
    std::string voice_name;
    std::string voice_type = "UNIVERSAL";
    std::uint8_t msb = 0;
    std::uint8_t lsb = 0;
    std::uint8_t program = 0;
    std::size_t first_zone_index = 0;
    std::size_t zone_count = 0;
};

struct VoiceZone {
    std::size_t voice_index = 0;
    std::size_t waveform_index = 0;
    std::size_t keybank_index = 0;
    std::string voice_title;
    std::string sample_uid;
    std::string sample_position;
    int root_note = 60;
    int key_lo = 0;
    int key_hi = 127;
    int velocity_lo = 1;
    int velocity_hi = 127;
    int sample_rate = 44100;
    double volume = 0.0;
    double pan = 0.0;
    int tune_coarse = 0;
    double tune_fine = 0.0;
    // Yamaha VoiceElement pitch-domain parameters. KeyBank tuning alone is
    // not sufficient: the Element can add NoteShift/Detune and alter keyboard
    // pitch scaling (including 0% fixed-pitch behavior).
    int element_note_shift = 0;
    int element_tune_coarse = 0;
    double element_tune_fine = 0.0;
    int pitch_scaling_sens = 100;
    int pitch_scaling_center_note = 60;
    int loop_start_frame = 0;
    int loop_end_frame = 0;
    bool one_shot = false;
    bool fixed_pitch = false;
    // Drum-key runtime behavior carried from Yamaha drumSetup. These fields
    // are stored per VoiceZone/KeyBank so velocity layers can have distinct
    // Alternate Group / Note-Off behavior when the PPF encodes it that way.
    std::uint8_t alternate_group = 0;
    bool receive_note_off = true;
    bool receive_note_on = true;
    bool release_only_aeg = false;
    double amplitude_release_rate = 1.0;
};

class PpfReader {
public:
    bool open(const std::string& path, std::string& error);
    // APCp-only parser path for stress verification. It deliberately skips UVF/XML.
    bool open_audio_only(const std::string& path, std::string& error);
    const PpfSummary& summary() const noexcept { return summary_; }
    const std::vector<VoiceZone>& voice_zones() const noexcept { return voice_zones_; }
    const std::vector<PpfVoiceDescriptor>& voices() const noexcept { return voice_descriptors_; }
    // Returns the single Yamaha expansion-bank LSB encoded by this PPF.
    // No free-slot allocation is performed here: the returned slot is source
    // metadata and must be preserved by the installer.
    bool source_bank_slot(std::uint8_t& msb, std::uint8_t& lsb, std::string& error) const;
    // Releases source container/index storage after residency is complete.
    void close() noexcept;

    // Existing Gate 2A API: behavior preserved.
    bool load_first_voice_sample(PpfSample& out, std::string& error) const;
    bool load_first_audio_sample(PpfSample& out, std::string& error) const;

    // V0.8: indexed access without exposing parser storage.
    bool load_audio_sample(std::size_t index, PpfSample& out, std::string& error) const;

    // V0.54: materialize one Voice zone through its authoritative sample UID.
    // This preserves the existing parser and adds only an indexed bridge from
    // Voice -> Zone -> APCp PCM for native sampler validation.
    bool load_voice_zone_sample(std::size_t voice_index,
                                std::size_t zone_index,
                                PpfSample& out,
                                std::string& error) const;

private:
    struct AudioEntry {
        std::string uid;
        std::size_t pcm_offset = 0;
        std::size_t pcm_bytes = 0;
    };

    struct VoiceEntry {
        std::string title;
        std::string first_sample_uid;
        int sample_rate = 44100;
    };

    // One container copy. APCp entries store byte spans into this buffer instead
    // of retaining another raw PCM vector for every sample.
    std::vector<std::uint8_t> file_data_;
    std::vector<AudioEntry> audio_;
    std::unordered_map<std::string, std::size_t> audio_index_by_uid_;
    std::vector<VoiceEntry> voices_;
    std::vector<PpfVoiceDescriptor> voice_descriptors_;
    std::vector<VoiceZone> voice_zones_;
    PpfSummary summary_{};

    const AudioEntry* find_audio(const std::string& uid) const;

    static bool find_tag4(const std::vector<std::uint8_t>& data,
                          std::size_t begin,
                          std::size_t end,
                          const char tag[4],
                          std::size_t& position) noexcept;

    static bool find_field(const std::vector<std::uint8_t>& data,
                           std::size_t begin,
                           std::size_t end,
                           const char tag[4],
                           std::size_t& payload_offset,
                           std::size_t& payload_size) noexcept;

    static bool extract_field(const std::vector<std::uint8_t>& blob,
                              const char tag[4],
                              std::vector<std::uint8_t>& payload);
    static std::string bytes_to_string(const std::vector<std::uint8_t>& v);
    static std::string bytes_to_string(const std::vector<std::uint8_t>& v,
                                       std::size_t offset,
                                       std::size_t length);
    static bool extract_xml_tag(const std::vector<std::uint8_t>& blob,
                                const char* tag,
                                std::string& value,
                                std::size_t start = 0);
    static int parse_int_tag(const std::vector<std::uint8_t>& blob,
                             const char* tag,
                             int fallback);
    static double parse_double_tag(const std::vector<std::uint8_t>& blob,
                                   const char* tag,
                                   double fallback);
    static int parse_midi_note_text(const std::string& value, int fallback) noexcept;
    static bool extract_attribute_from_open_tag(const std::vector<std::uint8_t>& blob,
                                                std::size_t open_pos,
                                                std::size_t open_end,
                                                const char* name,
                                                std::string& value);
    static void parse_voice_zones_from_blob(const std::vector<std::uint8_t>& blob,
                                            std::size_t voice_index,
                                            const std::string& title,
                                            std::vector<VoiceZone>& out);
    static std::uint32_t be32(const std::uint8_t* p) noexcept;

    bool fill_sample(const AudioEntry* entry,
                     const std::string& title,
                     int rate,
                     bool from_voice,
                     PpfSample& out,
                     std::string& error) const;
};

} // namespace arranger
