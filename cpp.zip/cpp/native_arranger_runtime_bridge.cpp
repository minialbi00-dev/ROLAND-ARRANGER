#include "native_arranger_runtime.h"
#include "native_arranger_runtime.hpp"

#include <algorithm>
#include <cstring>
#include <memory>
#include <new>
#include <string>
#include <vector>
#ifdef _WIN32
#ifndef NOMINMAX
#define NOMINMAX
#endif
#include <windows.h>
#include <mmsystem.h>
#include <mmdeviceapi.h>
#include <functiondiscoverykeys_devpkey.h>
#include <propvarutil.h>
#include <wrl/client.h>
#endif

namespace {
    using arranger::InstalledVoiceAddress;
    using arranger::NativeArrangerRuntime;

    void set_error(char* dst, size_t cap, const std::string& message) noexcept {
        if (!dst || cap == 0) return;
        const size_t n = std::min(cap - 1u, message.size());
        std::memcpy(dst, message.data(), n);
        dst[n] = '\0';
    }

    void clear_error(char* dst, size_t cap) noexcept { if (dst && cap) dst[0] = '\0'; }

    void copy_text(char* dst, size_t cap, const std::string& src) noexcept {
        if (!dst || cap == 0) return;
        const size_t n = std::min(cap - 1u, src.size());
        std::memcpy(dst, src.data(), n);
        dst[n] = '\0';
    }

    struct Bridge { NativeArrangerRuntime runtime; };
    Bridge* as_bridge(void* handle) noexcept { return static_cast<Bridge*>(handle); }

    bool require(void* handle, Bridge*& b, char* error_buf, size_t error_cap) noexcept {
        if (!handle) { set_error(error_buf, error_cap, "null native arranger runtime handle"); return false; }
        b = as_bridge(handle);
        return true;
    }

    int queue_section(void* handle, const char* name, char* error_buf, size_t error_cap,
        bool (NativeArrangerRuntime::* fn)(const std::string&, std::string&)) {
        Bridge* b = nullptr;
        if (!require(handle, b, error_buf, error_cap)) return 0;
        if (!name || !*name) { set_error(error_buf, error_cap, "section name is empty"); return 0; }
        std::string err;
        const bool ok = (b->runtime.*fn)(name, err);
        if (!ok) set_error(error_buf, error_cap, err);
        else clear_error(error_buf, error_cap);

        return ok ? 1 : 0;
    }

#ifdef _WIN32
    using Microsoft::WRL::ComPtr;

    struct AudioEndpointInfo {
        std::string name;
        std::string id;
    };

    std::string utf8_from_wide(const wchar_t* src) {
        if (!src) return {};
        const int n = WideCharToMultiByte(CP_UTF8, 0, src, -1, nullptr, 0, nullptr, nullptr);
        if (n <= 1) return {};
        std::string out(static_cast<std::size_t>(n - 1), '\0');
        WideCharToMultiByte(CP_UTF8, 0, src, -1, out.data(), n, nullptr, nullptr);
        return out;
    }

    std::wstring wide_from_utf8(const std::string& src) {
        const int n = MultiByteToWideChar(CP_UTF8, 0, src.c_str(), -1, nullptr, 0);
        if (n <= 0) return {};
        std::wstring out(static_cast<std::size_t>(n - 1), L'\0');
        MultiByteToWideChar(CP_UTF8, 0, src.c_str(), -1, out.data(), n);
        return out;
    }

    std::vector<AudioEndpointInfo> audio_endpoints() {
        std::vector<AudioEndpointInfo> out;
        HRESULT init = CoInitializeEx(nullptr, COINIT_MULTITHREADED);
        const bool owner = SUCCEEDED(init);
        if (FAILED(init) && init != RPC_E_CHANGED_MODE) return out;
        ComPtr<IMMDeviceEnumerator> en;
        if (FAILED(CoCreateInstance(__uuidof(MMDeviceEnumerator), nullptr, CLSCTX_ALL,
            IID_PPV_ARGS(en.GetAddressOf())))) {
            if (owner) CoUninitialize();
            return out;
        }
        ComPtr<IMMDeviceCollection> collection;
        if (FAILED(en->EnumAudioEndpoints(eRender, DEVICE_STATE_ACTIVE, collection.GetAddressOf()))) {
            if (owner) CoUninitialize();
            return out;
        }
        UINT count = 0;
        collection->GetCount(&count);
        for (UINT i = 0; i < count; ++i) {
            ComPtr<IMMDevice> dev;
            if (FAILED(collection->Item(i, dev.GetAddressOf()))) continue;
            LPWSTR id = nullptr;
            if (FAILED(dev->GetId(&id))) continue;
            ComPtr<IPropertyStore> store;
            std::string name;
            if (SUCCEEDED(dev->OpenPropertyStore(STGM_READ, store.GetAddressOf()))) {
                PROPVARIANT pv;
                PropVariantInit(&pv);
                if (SUCCEEDED(store->GetValue(PKEY_Device_FriendlyName, &pv))) {
                    if (pv.vt == VT_LPWSTR && pv.pwszVal) name = utf8_from_wide(pv.pwszVal);
                }
                PropVariantClear(&pv);
            }
            std::string sid = utf8_from_wide(id);
            CoTaskMemFree(id);
            if (!sid.empty()) out.push_back({ name.empty() ? sid : name, sid });
        }
        if (owner) CoUninitialize();
        return out;
    }
#endif
}

extern "C" {

    void* YAR_CALL yar_create(char* error_buf, size_t error_cap) {
        try {
            auto* b = new Bridge();
            clear_error(error_buf, error_cap);
            return b;
        }
        catch (const std::bad_alloc&) {
            set_error(error_buf, error_cap, "not enough memory creating native arranger runtime");
            return nullptr;
        }
        catch (...) {
            set_error(error_buf, error_cap, "unknown error creating native arranger runtime");
            return nullptr;
        }
    }

    void YAR_CALL yar_destroy(void* handle) { delete as_bridge(handle); }

    int YAR_CALL yar_load_style(void* handle, const char* path, char* error_buf, size_t error_cap) {
        Bridge* b = nullptr;
        if (!require(handle, b, error_buf, error_cap)) return 0;
        if (!path || !*path) { set_error(error_buf, error_cap, "Style path is empty"); return 0; }
        std::string err;
        const bool ok = b->runtime.load_style(path, err);
        if (!ok) set_error(error_buf, error_cap, err); else clear_error(error_buf, error_cap);
        return ok ? 1 : 0;
    }

    int YAR_CALL yar_install_ppf(void* handle, const char* path, uint8_t msb, uint8_t lsb, char* error_buf, size_t error_cap) {
        Bridge* b = nullptr;
        if (!require(handle, b, error_buf, error_cap)) return 0;
        if (!path || !*path) { set_error(error_buf, error_cap, "PPF path is empty"); return 0; }
        std::string err;
        const bool ok = b->runtime.install_ppf(path, InstalledVoiceAddress{ msb, lsb, 0 }, err);
        if (!ok) set_error(error_buf, error_cap, err); else clear_error(error_buf, error_cap);
        return ok ? 1 : 0;
    }

    int YAR_CALL yar_uninstall_ppf(void* handle, uint64_t bank_id, char* error_buf, size_t error_cap) {
        Bridge* b = nullptr;
        if (!require(handle, b, error_buf, error_cap)) return 0;
        std::string err;
        const bool ok = b->runtime.uninstall_ppf(static_cast<size_t>(bank_id), err);
        if (!ok) set_error(error_buf, error_cap, err); else clear_error(error_buf, error_cap);
        return ok ? 1 : 0;
    }

    int YAR_CALL yar_start(void* handle, char* error_buf, size_t error_cap) {
        Bridge* b = nullptr;
        if (!require(handle, b, error_buf, error_cap)) return 0;
        std::string err;
        const bool ok = b->runtime.start(err);
        if (!ok) set_error(error_buf, error_cap, err); else clear_error(error_buf, error_cap);
        return ok ? 1 : 0;
    }

    void YAR_CALL yar_stop(void* handle) { if (handle) as_bridge(handle)->runtime.stop(); }
    int YAR_CALL yar_running(void* handle) { return handle && as_bridge(handle)->runtime.running() ? 1 : 0; }

    int YAR_CALL yar_queue_main(void* handle, const char* name, char* e, size_t c) { return queue_section(handle, name, e, c, &NativeArrangerRuntime::queue_main); }
    int YAR_CALL yar_queue_fill(void* handle, const char* name, char* e, size_t c) { return queue_section(handle, name, e, c, &NativeArrangerRuntime::queue_fill); }
    int YAR_CALL yar_queue_intro(void* handle, const char* name, char* e, size_t c) { return queue_section(handle, name, e, c, &NativeArrangerRuntime::queue_intro); }
    int YAR_CALL yar_queue_ending(void* handle, const char* name, char* e, size_t c) { return queue_section(handle, name, e, c, &NativeArrangerRuntime::queue_ending); }

    void YAR_CALL yar_set_acmp(void* handle, int enabled) { if (handle) as_bridge(handle)->runtime.set_acmp(enabled != 0); }
    void YAR_CALL yar_set_chord(void* handle, uint8_t root, uint8_t type) { if (handle) as_bridge(handle)->runtime.set_chord(root, type); }
    void YAR_CALL yar_set_transpose(void* handle, int semitones) { if (handle) as_bridge(handle)->runtime.set_transpose(semitones); }
    void YAR_CALL yar_set_tempo(void* handle, double bpm) { if (handle) as_bridge(handle)->runtime.set_tempo(bpm); }

    int YAR_CALL yar_set_audio_output_device(void* handle, const char* device_id, char* error_buf, size_t error_cap) {
        Bridge* b = nullptr;
        if (!require(handle, b, error_buf, error_cap)) return 0;
        std::string err;
        const bool ok = b->runtime.set_audio_device_id(device_id ? std::string(device_id) : std::string{}, err);
        if (!ok) set_error(error_buf, error_cap, err); else clear_error(error_buf, error_cap);
        return ok ? 1 : 0;
    }

    int YAR_CALL yar_get_audio_output_device(void* handle, char* out, size_t out_cap) {
        if (!handle || !out || !out_cap) return 0;
        const std::string id = as_bridge(handle)->runtime.audio_device_id();
        copy_text(out, out_cap, id);
        return 1;
    }

    size_t YAR_CALL yar_audio_output_device_count(void) {
#ifdef _WIN32
        return audio_endpoints().size();
#else
        return 0;
#endif
    }

    int YAR_CALL yar_audio_output_device_name(size_t index, char* out, size_t out_cap) {
#ifdef _WIN32
        const auto items = audio_endpoints();
        if (index >= items.size() || !out || !out_cap) return 0;
        copy_text(out, out_cap, items[index].name);
        return 1;
#else
        (void)index; (void)out; (void)out_cap; return 0;
#endif
    }

    int YAR_CALL yar_audio_output_device_id(size_t index, char* out, size_t out_cap) {
#ifdef _WIN32
        const auto items = audio_endpoints();
        if (index >= items.size() || !out || !out_cap) return 0;
        copy_text(out, out_cap, items[index].id);
        return 1;
#else
        (void)index; (void)out; (void)out_cap; return 0;
#endif
    }

    size_t YAR_CALL yar_midi_input_device_count(void) {
        return NativeArrangerRuntime::midi_input_device_names().size();
    }

    int YAR_CALL yar_midi_input_device_name(size_t index, char* out, size_t out_cap) {
        const auto items = NativeArrangerRuntime::midi_input_device_names();
        if (index >= items.size() || !out || !out_cap) return 0;
        copy_text(out, out_cap, items[index]);
        return 1;
    }

    int YAR_CALL yar_midi_input_open(void* handle, uint32_t device_index, char* error_buf, size_t error_cap) {
        Bridge* b = nullptr;
        if (!require(handle, b, error_buf, error_cap)) return 0;
        std::string err;
        const bool ok = b->runtime.open_midi_input(device_index, err);
        if (!ok) set_error(error_buf, error_cap, err); else clear_error(error_buf, error_cap);
        return ok ? 1 : 0;
    }

    void YAR_CALL yar_midi_input_close(void* handle) {
        if (handle) as_bridge(handle)->runtime.close_midi_input();
    }

    int YAR_CALL yar_midi_input_active(void* handle) {
        return handle && as_bridge(handle)->runtime.midi_input_active() ? 1 : 0;
    }

    void YAR_CALL yar_midi_input(void* handle, uint8_t status, uint8_t data1, uint8_t data2) {
        if (handle) as_bridge(handle)->runtime.feed_midi(status, data1, data2);
    }

    void YAR_CALL yar_clear_performance_notes(void* handle) {
        if (handle) as_bridge(handle)->runtime.clear_performance_notes();
    }

    void YAR_CALL yar_set_finger_mode(void* handle, uint8_t mode) {
        if (handle) as_bridge(handle)->runtime.set_finger_mode(mode);
    }

    void YAR_CALL yar_set_split_point(void* handle, int note) {
        if (handle) as_bridge(handle)->runtime.set_split_point(note);
    }

    void YAR_CALL yar_set_smart_chord_key(void* handle, int root_pc) {
        if (handle) as_bridge(handle)->runtime.set_smart_chord_key(root_pc);
    }

    void YAR_CALL yar_set_smart_chord_type(void* handle, uint8_t type) {
        if (handle) as_bridge(handle)->runtime.set_smart_chord_type(type);
    }

    int YAR_CALL yar_get_performance_state(void* handle, YarPerformanceState* out_state) {
        if (!out_state || !handle) return 0;
        *out_state = {};
        const auto ps = as_bridge(handle)->runtime.performance_state();
        out_state->acmp_enabled = ps.acmp_enabled ? 1u : 0u;
        out_state->note_gate = ps.note_gate ? 1u : 0u;
        out_state->finger_mode = ps.finger_mode;
        out_state->transpose = static_cast<int16_t>(ps.transpose);
        out_state->chord_root_pc = ps.chord_root_pc;
        out_state->chord_type = ps.chord_type;
        copy_text(out_state->chord_name, sizeof(out_state->chord_name), ps.chord_name);
        out_state->held_note_count = static_cast<uint16_t>(std::min<std::size_t>(ps.held_notes.size(), 128u));
        for (std::size_t i = 0; i < out_state->held_note_count; ++i) out_state->held_notes[i] = ps.held_notes[i];
        out_state->note_on_count = ps.note_on_count;
        out_state->note_off_count = ps.note_off_count;
        out_state->chord_bass_pc = ps.chord_bass_pc;
        out_state->chord_bass_valid = ps.chord_bass_valid ? 1u : 0u;
        out_state->split_point = ps.split_point;
        out_state->smart_chord_key_pc = ps.smart_chord_key_pc;
        out_state->smart_chord_type = ps.smart_chord_type;
        return 1;
    }

    int YAR_CALL yar_get_state(void* handle, YarNativeState* out_state) {
        if (!out_state || !handle) return 0;
        *out_state = {};
        const auto s = as_bridge(handle)->runtime.state();
        out_state->running = s.running ? 1u : 0u;
        out_state->audio_active = s.audio_active ? 1u : 0u;
        out_state->scheduler_active = s.scheduler_active ? 1u : 0u;
        out_state->acmp_enabled = s.acmp_enabled ? 1u : 0u;
        out_state->transpose = static_cast<int16_t>(s.transpose);
        out_state->division = s.division;
        out_state->transport_tick = s.transport_tick;
        out_state->bar_ticks = s.bar_ticks;
        out_state->bpm = s.bpm;
        copy_text(out_state->current_section, sizeof(out_state->current_section), s.current_section);
        copy_text(out_state->active_main, sizeof(out_state->active_main), s.active_main);
        return 1;
    }

    void YAR_CALL yar_get_audio_stats(void* handle, YarNativeAudioStats* out_stats) {
        if (!out_stats) return;
        *out_stats = {};
        if (!handle) return;
        const auto s = as_bridge(handle)->runtime.audio_metrics();
        out_stats->output_rate = s.output_rate;
        out_stats->buffer_frames = s.buffer_frames;
        out_stats->ppf_voices = static_cast<uint32_t>(s.ppf_voice_count);
        out_stats->ppf_banks = static_cast<uint32_t>(s.ppf_bank_count);
        out_stats->resident_zones = static_cast<uint32_t>(s.resident_zone_count);
        out_stats->unique_pcm = static_cast<uint32_t>(s.unique_pcm_count);
        out_stats->resident_pcm_bytes = s.resident_pcm_bytes;
        out_stats->active_voices = static_cast<uint32_t>(s.active_voices);
        out_stats->rendered_frames = s.rendered_frames;
        out_stats->nonzero_samples = s.nonzero_samples;
        out_stats->nonfinite_samples = s.nonfinite_samples;
        out_stats->deadline_misses = s.render_deadline_misses;
        out_stats->dropped_events = s.dropped_events;
        out_stats->events_processed = s.events_processed;
        out_stats->max_render_us = s.max_render_us;
        out_stats->peak_milli = static_cast<uint32_t>(std::clamp(s.peak, 0.0f, 4294.967f) * 1000.0f);
        out_stats->active = s.active ? 1u : 0u;
        out_stats->buffer_latency_ms = s.buffer_latency_ms;
    }

    // INJEKSI FUNGSI SOUNDFONT YANG SUDAH TERHUBUNG KE HEADER
    int YAR_CALL yar_load_soundfont(void* handle, const char* path, char* error_buf, size_t error_cap) {
        Bridge* b = nullptr;
        if (!require(handle, b, error_buf, error_cap)) return 0;
        if (!path || !*path) { set_error(error_buf, error_cap, "SF2 path is empty"); return 0; }
        std::string err;
        const bool ok = b->runtime.load_soundfont(path, err);
        if (!ok) set_error(error_buf, error_cap, err); else clear_error(error_buf, error_cap);
        return ok ? 1 : 0;
    }

}