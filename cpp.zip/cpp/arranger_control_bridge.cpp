#include "arranger_control_bridge.h"
#include "arranger_engine.hpp"
#include "yamaha_style_runtime.hpp"
#include "performance_runtime.hpp"

#include <algorithm>
#include <cmath>
#include <cstring>
#include <memory>
#include <new>
#include <string>
#include <vector>

namespace {
using arranger::CppArrangerEngine;
using arranger::ArrangerOutputEvent;
using arranger::YamahaStyleRuntime;

void set_error(char* dst, size_t cap, const std::string& message) noexcept {
    if (!dst || cap == 0) return;
    const size_t n = std::min(cap - 1u, message.size());
    std::memcpy(dst, message.data(), n);
    dst[n] = '\0';
}

struct ControlBridge {
    YamahaStyleRuntime style;
    std::unique_ptr<CppArrangerEngine> engine;
    double bpm = 120.0;
    std::vector<ArrangerOutputEvent> pending;
    arranger::PerformanceRuntime performance;
};

ControlBridge* as_bridge(void* handle) noexcept {
    return static_cast<ControlBridge*>(handle);
}

bool require_engine(void* handle, ControlBridge*& b, char* error_buf, size_t error_cap) noexcept {
    if (!handle) {
        set_error(error_buf, error_cap, "null arranger control handle");
        return false;
    }
    b = as_bridge(handle);
    if (!b->engine) {
        set_error(error_buf, error_cap, "no Style loaded into arranger control bridge");
        return false;
    }
    return true;
}

void copy_text(char* dst, size_t cap, const std::string& src) noexcept {
    if (!dst || cap == 0) return;
    const size_t n = std::min(cap - 1u, src.size());
    std::memcpy(dst, src.data(), n);
    dst[n] = '\0';
}

} // namespace

extern "C" {

void* YAC_CALL yac_arranger_create(char* error_buf, size_t error_cap) {
    try {
        auto* b = new ControlBridge();
        if (error_buf && error_cap) error_buf[0] = '\0';
        return b;
    } catch (const std::bad_alloc&) {
        set_error(error_buf, error_cap, "not enough memory creating arranger control bridge");
        return nullptr;
    } catch (...) {
        set_error(error_buf, error_cap, "unknown error creating arranger control bridge");
        return nullptr;
    }
}

void YAC_CALL yac_arranger_destroy(void* handle) {
    delete as_bridge(handle);
}

int YAC_CALL yac_arranger_load_style(void* handle,
                                     const char* style_path,
                                     char* error_buf,
                                     size_t error_cap) {
    if (!handle) { set_error(error_buf, error_cap, "null arranger control handle"); return 0; }
    if (!style_path || !*style_path) { set_error(error_buf, error_cap, "Style path is empty"); return 0; }
    auto* b = as_bridge(handle);
    if (b->engine && b->engine->running()) {
        set_error(error_buf, error_cap, "cannot replace Style while arranger is running");
        return 0;
    }
    YamahaStyleRuntime fresh;
    std::string err;
    if (!fresh.load(style_path, err)) {
        set_error(error_buf, error_cap, err);
        return 0;
    }
    try {
        b->style = std::move(fresh);
        b->engine = std::make_unique<CppArrangerEngine>(b->style);
        b->bpm = std::clamp(b->style.summary().tempo_bpm, 30.0, 300.0);
        b->pending.clear();
        b->performance.reset();
    } catch (const std::bad_alloc&) {
        set_error(error_buf, error_cap, "not enough memory creating C++ Style arranger");
        return 0;
    }
    if (error_buf && error_cap) error_buf[0] = '\0';
    return 1;
}

int YAC_CALL yac_arranger_start(void* handle, char* error_buf, size_t error_cap) {
    ControlBridge* b = nullptr;
    if (!require_engine(handle, b, error_buf, error_cap)) return 0;
    std::string err;
    if (!b->engine->start(err)) {
        set_error(error_buf, error_cap, err);
        return 0;
    }
    b->pending.clear();
    if (error_buf && error_cap) error_buf[0] = '\0';
    return 1;
}

void YAC_CALL yac_arranger_stop(void* handle) {
    if (!handle) return;
    auto* b = as_bridge(handle);
    if (b->engine) b->engine->stop();
    b->pending.clear();
}

int YAC_CALL yac_arranger_running(void* handle) {
    if (!handle || !as_bridge(handle)->engine) return 0;
    return as_bridge(handle)->engine->running() ? 1 : 0;
}

#define YAC_QUEUE_METHOD(fn, method) \
int YAC_CALL fn(void* handle, const char* name, char* error_buf, size_t error_cap) { \
    ControlBridge* b = nullptr; \
    if (!require_engine(handle, b, error_buf, error_cap)) return 0; \
    if (!name || !*name) { set_error(error_buf, error_cap, "section name is empty"); return 0; } \
    std::string err; \
    const bool ok = b->engine->method(name, err); \
    if (!ok) set_error(error_buf, error_cap, err); \
    else if (error_buf && error_cap) error_buf[0] = '\0'; \
    return ok ? 1 : 0; \
}

YAC_QUEUE_METHOD(yac_arranger_queue_main, queue_main)
YAC_QUEUE_METHOD(yac_arranger_queue_fill, queue_fill)
YAC_QUEUE_METHOD(yac_arranger_queue_intro, queue_intro)
YAC_QUEUE_METHOD(yac_arranger_queue_ending, queue_ending)

#undef YAC_QUEUE_METHOD

void YAC_CALL yac_arranger_set_acmp(void* handle, int enabled) {
    if (!handle || !as_bridge(handle)->engine) return;
    auto* b = as_bridge(handle);
    b->engine->set_acmp(enabled != 0);
    b->performance.set_acmp(enabled != 0);
}

void YAC_CALL yac_arranger_set_chord(void* handle, uint8_t root_pc, uint8_t chord_type) {
    if (!handle || !as_bridge(handle)->engine) return;
    as_bridge(handle)->engine->set_chord(root_pc, chord_type);
}

void YAC_CALL yac_arranger_set_transpose(void* handle, int semitones) {
    if (!handle || !as_bridge(handle)->engine) return;
    auto* b = as_bridge(handle);
    b->engine->set_transpose(semitones);
    b->performance.set_transpose(semitones);
}

void YAC_CALL yac_arranger_set_tempo(void* handle, double bpm) {
    if (!handle) return;
    if (std::isfinite(bpm)) as_bridge(handle)->bpm = std::clamp(bpm, 30.0, 300.0);
}

void YAC_CALL yac_arranger_set_finger_mode(void* handle, uint8_t mode) {
    if (!handle) return;
    auto* b = as_bridge(handle);
    b->performance.set_finger_mode(mode);
    if (b->engine) {
        const auto& ps = b->performance.state();
        if (ps.chord_name != "No Chord")
            b->engine->set_chord(ps.chord_root_pc, ps.chord_type, ps.chord_bass_pc, ps.chord_bass_valid);
        b->engine->set_transpose(ps.transpose);
    }
}

void YAC_CALL yac_arranger_set_split_point(void* handle, int note) {
    if (!handle) return;
    auto* b = as_bridge(handle);
    b->performance.set_split_point(note);
    if (b->engine) {
        const auto& ps = b->performance.state();
        if (ps.chord_name != "No Chord")
            b->engine->set_chord(ps.chord_root_pc, ps.chord_type, ps.chord_bass_pc, ps.chord_bass_valid);
    }
}

void YAC_CALL yac_arranger_set_smart_chord_key(void* handle, int root_pc) {
    if (!handle) return;
    auto* b = as_bridge(handle);
    b->performance.set_smart_chord_key(root_pc);
    if (b->engine) {
        const auto& ps = b->performance.state();
        if (ps.chord_name != "No Chord")
            b->engine->set_chord(ps.chord_root_pc, ps.chord_type, ps.chord_bass_pc, ps.chord_bass_valid);
    }
}

void YAC_CALL yac_arranger_set_smart_chord_type(void* handle, uint8_t type) {
    if (!handle) return;
    auto* b = as_bridge(handle);
    b->performance.set_smart_chord_type(type);
    if (b->engine) {
        const auto& ps = b->performance.state();
        if (ps.chord_name != "No Chord")
            b->engine->set_chord(ps.chord_root_pc, ps.chord_type, ps.chord_bass_pc, ps.chord_bass_valid);
    }
}

void YAC_CALL yac_arranger_set_smart_chord_minor(void* handle, int minor) {
    if (!handle) return;
    auto* b = as_bridge(handle);
    b->performance.set_smart_chord_minor(minor != 0);
    if (b->engine) {
        const auto& ps = b->performance.state();
        if (ps.chord_name != "No Chord")
            b->engine->set_chord(ps.chord_root_pc, ps.chord_type, ps.chord_bass_pc, ps.chord_bass_valid);
    }
}

void YAC_CALL yac_arranger_clear_performance_notes(void* handle) {
    if (!handle) return;
    auto* b = as_bridge(handle);
    b->performance.clear_notes();
    if (b->engine) {
        const auto& ps = b->performance.state();
        if (ps.chord_name != "No Chord")
            b->engine->set_chord(ps.chord_root_pc, ps.chord_type, ps.chord_bass_pc, ps.chord_bass_valid);
    }
}

void YAC_CALL yac_arranger_midi_input(void* handle, uint8_t status, uint8_t data1, uint8_t data2) {
    if (!handle) return;
    auto* b = as_bridge(handle);
    b->performance.feed_midi(status, data1, data2);
    if (b->engine) {
        const auto& ps = b->performance.state();
        if (ps.chord_name != "No Chord")
            b->engine->set_chord(ps.chord_root_pc, ps.chord_type, ps.chord_bass_pc, ps.chord_bass_valid);
        b->engine->set_acmp(ps.acmp_enabled);
        b->engine->set_transpose(ps.transpose);
    }
}

int YAC_CALL yac_arranger_advance_to(void* handle,
                                     uint32_t global_tick,
                                     YacArrangerEvent* out_events,
                                     size_t out_capacity,
                                     size_t* out_count,
                                     char* error_buf,
                                     size_t error_cap) {
    if (out_count) *out_count = 0;
    ControlBridge* b = nullptr;
    if (!require_engine(handle, b, error_buf, error_cap)) return 0;
    std::string err;
    std::vector<ArrangerOutputEvent> events;
    if (!b->engine->advance_to(global_tick, events, err)) {
        set_error(error_buf, error_cap, err);
        return 0;
    }
    if (events.size() > out_capacity) {
        set_error(error_buf, error_cap, "arranger output buffer too small for this tick advance");
        return 0;
    }
    if (events.size() && !out_events) {
        set_error(error_buf, error_cap, "output event buffer is null");
        return 0;
    }
    for (size_t i = 0; i < events.size(); ++i) {
        const auto& e = events[i];
        out_events[i] = YacArrangerEvent{e.global_tick, e.status, e.data1, e.data2, e.track};
    }
    if (out_count) *out_count = events.size();
    if (error_buf && error_cap) error_buf[0] = '\0';
    return 1;
}

int YAC_CALL yac_arranger_get_performance_state(void* handle, YacPerformanceState* out_state) {
    if (!out_state) return 0;
    *out_state = {};
    if (!handle) return 0;
    const auto& ps = as_bridge(handle)->performance.state();
    out_state->acmp_enabled = ps.acmp_enabled ? 1u : 0u;
    out_state->note_gate = ps.note_gate ? 1u : 0u;
    out_state->finger_mode = ps.finger_mode;
    out_state->transpose = static_cast<int16_t>(ps.transpose);
    out_state->chord_root_pc = ps.chord_root_pc;
    out_state->chord_type = ps.chord_type;
    copy_text(out_state->chord_name, sizeof(out_state->chord_name), ps.chord_name);
    out_state->held_note_count = static_cast<uint16_t>(std::min<std::size_t>(ps.held_notes.size(), 128u));
    for (std::size_t i = 0; i < out_state->held_note_count; ++i) {
        out_state->held_notes[i] = ps.held_notes[i];
    }
    out_state->note_on_count = ps.note_on_count;
    out_state->note_off_count = ps.note_off_count;
    out_state->chord_bass_pc = ps.chord_bass_pc;
    out_state->chord_bass_valid = ps.chord_bass_valid ? 1u : 0u;
    out_state->split_point = ps.split_point;
    out_state->smart_chord_key_pc = ps.smart_chord_key_pc;
    out_state->smart_chord_type = ps.smart_chord_type;
    return 1;
}

int YAC_CALL yac_arranger_get_state(void* handle, YacArrangerState* out_state) {
    if (!out_state) return 0;
    *out_state = {};
    if (!handle || !as_bridge(handle)->engine) return 0;
    const auto* e = as_bridge(handle)->engine.get();
    out_state->running = e->running() ? 1u : 0u;
    out_state->acmp_enabled = e->acmp_enabled() ? 1u : 0u;
    out_state->transpose = static_cast<int16_t>(e->transpose());
    out_state->division = e->division();
    const auto bars = e->bar_ticks();
    out_state->bar_ticks = bars;
    out_state->transport_tick = e->current_tick();
    out_state->bpm = as_bridge(handle)->bpm;
    copy_text(out_state->current_section, sizeof(out_state->current_section), e->current_section());
    copy_text(out_state->active_main, sizeof(out_state->active_main), e->active_main());
    return 1;
}

} // extern "C"
