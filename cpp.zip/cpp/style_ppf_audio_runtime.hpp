#pragma once
#include "arranger_engine.hpp"
#include "ppf_reader.hpp"
#include "ppf_voice_bank.hpp"
#include "resident_sampler.hpp"
#include "style_voice_router.hpp"
#include "voice_install_catalog.hpp"
#include <array>
#include <cstddef>
#include <cstdint>
#include <memory>
#include <string>
#include <unordered_map>
#include <vector>

namespace arranger {

struct StylePpfAudioStats {
    std::size_t style_events = 0;
    std::size_t output_events = 0;
    std::size_t voice_setup_events = 0;
    std::size_t matched_voice_changes = 0;
    std::size_t installed_catalog_voice_resolutions = 0;
    std::size_t installed_catalog_note_resolutions = 0;
    std::size_t unique_matched_voices = 0;
    std::size_t zone_preloaded = 0;
    std::size_t unique_pcm_loaded = 0;
    std::size_t note_ons = 0;
    std::size_t note_offs = 0;
    std::size_t resolved_note_ons = 0;
    std::size_t resolved_note_offs = 0;
    std::size_t notes_without_voice = 0;
    std::size_t notes_without_zone = 0;
    std::size_t sampler_note_on_failures = 0;
    std::size_t rendered_frames = 0;
    std::size_t nonzero_samples = 0;
    std::size_t nonfinite_samples = 0;
    float peak = 0.0f;
};

class StylePpfAudioRuntime {
public:
    StylePpfAudioRuntime(const YamahaStyleRuntime& style,
                         const PpfReader& reader,
                         const PpfInstalledVoiceBank& bank);
    StylePpfAudioRuntime(const YamahaStyleRuntime& style,
                         const PpfReader& reader,
                         const PpfInstalledVoiceBank& bank,
                         const InstalledVoiceCatalog& installed_catalog);

    bool installed_bank_authoritative() const noexcept { return installed_catalog_ != nullptr; }
    bool prepare(std::string& error);
    bool render_ticks(std::uint32_t end_tick,
                      int output_rate,
                      std::vector<float>& out_stereo,
                      StylePpfAudioStats& stats,
                      std::string& error);

    // Stateful realtime bridge used only by the new scheduler -> PPF -> WASAPI path.
    // start_realtime() performs all event-vector allocation and sample preloading before
    // audio starts. render_realtime() then uses only preallocated state on the hot path.
    bool start_realtime(std::uint32_t end_tick,
                        int output_rate,
                        std::string& error);
    bool render_realtime(float* out_stereo,
                         std::size_t frames,
                         int output_rate,
                         std::string& error);

    double style_bpm() const noexcept { return style_.summary().tempo_bpm; }
    std::uint16_t division() const noexcept { return engine_.division(); }
    std::uint32_t realtime_rendered_frames() const noexcept {
        return realtime_rendered_frames_ > 0xFFFFFFFFull
            ? 0xFFFFFFFFu
            : static_cast<std::uint32_t>(realtime_rendered_frames_);
    }
    const StylePpfAudioStats& realtime_stats() const noexcept { return realtime_stats_; }
    const CppArrangerEngine& engine() const noexcept { return engine_; }

private:
    struct ResidentZone { VoiceZone zone{}; ResidentSamplePtr sample; };
    struct ActiveKey {
        std::uint8_t channel = 0; std::uint8_t note = 0;
        bool operator==(const ActiveKey& o) const noexcept { return channel==o.channel && note==o.note; }
    };
    struct ActiveKeyHash {
        std::size_t operator()(const ActiveKey& k) const noexcept { return (static_cast<std::size_t>(k.channel)<<8)^k.note; }
    };
    const YamahaStyleRuntime& style_;
    const PpfReader& reader_;
    const PpfInstalledVoiceBank& bank_;
    const InstalledVoiceCatalog* installed_catalog_ = nullptr;
    CppArrangerEngine engine_;
    ResidentSampler sampler_;
    std::unordered_map<std::size_t, std::vector<ResidentZone>> voices_;
    std::unordered_map<std::string, ResidentSamplePtr> pcm_cache_;
    std::unordered_map<ActiveKey, std::size_t, ActiveKeyHash> active_slots_;

    std::vector<ArrangerOutputEvent> realtime_events_;
    std::vector<std::uint64_t> realtime_event_frames_;
    std::vector<std::size_t> realtime_seen_;
    std::array<std::uint8_t,16> realtime_msb_{};
    std::array<std::uint8_t,16> realtime_lsb_{};
    std::array<std::uint8_t,16> realtime_program_{};
    StylePpfAudioStats realtime_stats_{};
    std::size_t realtime_event_index_ = 0;
    std::uint64_t realtime_rendered_frames_ = 0;
    std::uint64_t realtime_end_frame_ = 0;
    bool realtime_active_ = false;
    int realtime_output_rate_ = 48000;
    double realtime_frames_per_tick_ = 0.0;

    static ResidentSamplePtr to_resident(const PpfSample& src);
    static bool zone_accepts(const VoiceZone& z, int note, int velocity) noexcept;
    static float zone_gain(const VoiceZone& z, float master_gain) noexcept;
    static float zone_pan(const VoiceZone& z) noexcept;
    static double zone_pitch_ratio(const VoiceZone& z, int note) noexcept;
    const ResidentZone* choose_zone(std::size_t voice_index, int note, int velocity) const noexcept;
    bool preload_voice(std::size_t voice_index, std::size_t& zone_count, std::size_t& new_pcm, std::string& error);
    bool resolve_runtime_voice(std::uint8_t channel,
                               std::uint8_t msb,
                               std::uint8_t lsb,
                               std::uint8_t program,
                               const PpfVoiceDescriptor*& voice,
                               std::string& error,
                               InstalledVoiceResolution* mapping = nullptr) const;
    bool consume_output_event(const ArrangerOutputEvent& e,
                              std::array<std::uint8_t,16>& msb,
                              std::array<std::uint8_t,16>& lsb,
                              std::array<std::uint8_t,16>& program,
                              std::vector<std::size_t>& seen,
                              StylePpfAudioStats& stats,
                              std::string& error);
};
}
