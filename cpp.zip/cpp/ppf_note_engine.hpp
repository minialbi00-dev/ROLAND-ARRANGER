#pragma once

#include "ppf_runtime.hpp"
#include "ppf_voice_bank.hpp"
#include "resident_sampler.hpp"

#include <array>
#include <cstddef>
#include <cstdint>

namespace arranger {

// Native PPF note/voice-instance request. The catalog/style layer resolves the
// Yamaha source Voice identity; this engine owns the remaining musical decision
// path for that PPF Voice: exact Zone -> Voice Instance -> sampler slot.
struct PpfNoteRequest {
    std::size_t bank_id = 0;
    std::size_t source_index = 0;
    std::uint8_t part = 0;
    std::uint8_t note = 60;
    std::uint8_t velocity = 127;
};

class PpfNoteEngine {
public:
    PpfNoteEngine(PpfRuntime& runtime, ResidentSampler& sampler) noexcept
        : runtime_(runtime), sampler_(sampler) { reset(); }

    void reset() noexcept;

    // Returns false only when the PPF note could not be instantiated (no exact
    // zone, no resident sample, or no reclaimable sampler slot).
    bool note_on(const PpfNoteRequest& request) noexcept;

    // Returns true when the request belonged to an active PPF note slot or was
    // intentionally consumed by a Yamaha zone that ignores Note-Off.
    bool note_off(std::uint8_t part, std::uint8_t note) noexcept;

    // Native PPF controller path used by NOTE/voice instances. Returns true
    // when the controller is a controller owned by this engine.
    bool control_change(std::uint8_t part, std::uint8_t controller,
                        std::uint8_t value) noexcept;
    bool pitch_bend(std::uint8_t part, std::uint8_t lsb,
                    std::uint8_t msb) noexcept;

    void all_notes_off(std::size_t part = 16) noexcept;

    std::int64_t active_slot(std::uint8_t part, std::uint8_t note) const noexcept;
    std::size_t active_note_count() const noexcept;

private:
    static float zone_gain(const VoiceZone& zone) noexcept;
    static float zone_pan(const VoiceZone& zone) noexcept;
    static double zone_pitch_ratio(const VoiceZone& zone, int note) noexcept;
    static bool is_rhythm_part(std::uint8_t part) noexcept;

    void clear_slot_mapping(std::size_t slot) noexcept;
    void clear_mappings_for_part(std::size_t part) noexcept;

    PpfRuntime& runtime_;
    ResidentSampler& sampler_;
    std::array<std::array<std::int64_t, 128>, 16> active_slots_{};
    std::array<bool, 16> sustain_down_{};
};

} // namespace arranger
