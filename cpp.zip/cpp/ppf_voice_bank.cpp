#include "ppf_voice_bank.hpp"
#include <algorithm>
#include <new>

namespace arranger {

void PpfInstalledVoiceBank::clear() noexcept {
    std::vector<PpfVoiceDescriptor>().swap(voices_);
    decltype(exact_)().swap(exact_);
    decltype(by_msb_pc_)().swap(by_msb_pc_);
    decltype(lsbs_by_msb_)().swap(lsbs_by_msb_);
    reset_channel_addresses();
}

void PpfInstalledVoiceBank::reset_channel_addresses() noexcept {
    channel_msb_.fill(0);
    channel_lsb_.fill(0);
    channel_program_.fill(0);
    channel_address_set_.fill(false);
}

bool PpfInstalledVoiceBank::has_channel_address(std::uint8_t midi_channel) const noexcept {
    return midi_channel < kPartCount && channel_address_set_[midi_channel];
}

bool PpfInstalledVoiceBank::install(const PpfReader& reader, std::string& error) {
    error.clear();
    clear();

    const auto& src = reader.voices();
    if (src.empty()) {
        error = "PPF Voice Bank install failed: PPF contains no indexed Voice descriptors";
        return false;
    }

    try {
        voices_ = src;
        exact_.reserve(voices_.size() * 2u);
        by_msb_pc_.reserve(voices_.size() * 2u);
    } catch (const std::bad_alloc&) {
        clear();
        error = "not enough RAM while creating installed PPF Voice Bank";
        return false;
    }

    for (std::size_t i = 0; i < voices_.size(); ++i) {
        const auto& v = voices_[i];
        const AddressKey exact_key{v.msb, v.lsb, v.program};
        exact_[exact_key] = i;

        const MsbPcKey msb_pc{v.msb, v.program};
        by_msb_pc_[msb_pc].push_back(i);

        auto& slots = lsbs_by_msb_[v.msb];
        if (std::find(slots.begin(), slots.end(), v.lsb) == slots.end()) {
            slots.push_back(v.lsb);
        }
    }

    reset_channel_addresses();
    return true;
}

const PpfVoiceDescriptor* PpfInstalledVoiceBank::resolve(std::uint8_t midi_channel,
                                                         std::uint8_t msb,
                                                         std::uint8_t lsb,
                                                         std::uint8_t program) const noexcept {
    if (midi_channel >= kPartCount) return nullptr;

    const AddressKey exact_key{static_cast<std::uint8_t>(msb & 0x7F),
                               static_cast<std::uint8_t>(lsb & 0x7F),
                               static_cast<std::uint8_t>(program & 0x7F)};
    const auto exact_it = exact_.find(exact_key);
    if (exact_it != exact_.end()) {
        const auto& v = voices_[exact_it->second];
        const bool drum = v.voice_type == "DRUM_KIT";
        if ((midi_channel == kRhythm1Channel || midi_channel == kRhythm2Channel) == drum) {
            return &v;
        }
        return nullptr;
    }

    // Pack-slot alias: same MSB + PC is legal only if the pack has exactly
    // one source LSB for that MSB and exactly one candidate Voice.
    const MsbPcKey msb_pc{static_cast<std::uint8_t>(msb & 0x7F),
                          static_cast<std::uint8_t>(program & 0x7F)};
    const auto cand_it = by_msb_pc_.find(msb_pc);
    if (cand_it == by_msb_pc_.end() || cand_it->second.size() != 1u) return nullptr;

    const auto lsb_it = lsbs_by_msb_.find(msb_pc.msb);
    if (lsb_it == lsbs_by_msb_.end() || lsb_it->second.size() != 1u) return nullptr;

    const auto& v = voices_[cand_it->second.front()];
    const bool drum = v.voice_type == "DRUM_KIT";
    if ((midi_channel == kRhythm1Channel || midi_channel == kRhythm2Channel) == drum) {
        return &v;
    }
    return nullptr;
}

bool PpfInstalledVoiceBank::set_channel_address(std::uint8_t midi_channel,
                                                std::uint8_t msb,
                                                std::uint8_t lsb,
                                                std::uint8_t program) noexcept {
    if (midi_channel >= kPartCount) return false;
    channel_msb_[midi_channel] = static_cast<std::uint8_t>(msb & 0x7F);
    channel_lsb_[midi_channel] = static_cast<std::uint8_t>(lsb & 0x7F);
    channel_program_[midi_channel] = static_cast<std::uint8_t>(program & 0x7F);
    channel_address_set_[midi_channel] = true;
    return true;
}

const PpfVoiceDescriptor* PpfInstalledVoiceBank::resolve_channel(std::uint8_t midi_channel) const noexcept {
    if (midi_channel >= kPartCount) return nullptr;
    return resolve(midi_channel,
                   channel_msb_[midi_channel],
                   channel_lsb_[midi_channel],
                   channel_program_[midi_channel]);
}

} // namespace arranger
