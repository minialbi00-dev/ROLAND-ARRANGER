#include "yep_reader.hpp"
#include <algorithm>
#include <array>
#include <fstream>
#include <iomanip>
#include <limits>
#include <sstream>
#include <stdexcept>

namespace arranger {

std::uint16_t YepReader::be16(const std::uint8_t* p) noexcept {
    return static_cast<std::uint16_t>((static_cast<std::uint16_t>(p[0]) << 8) | p[1]);
}
std::uint32_t YepReader::be32(const std::uint8_t* p) noexcept {
    return (static_cast<std::uint32_t>(p[0]) << 24) |
           (static_cast<std::uint32_t>(p[1]) << 16) |
           (static_cast<std::uint32_t>(p[2]) << 8) |
           static_cast<std::uint32_t>(p[3]);
}
std::int16_t YepReader::be16s(const std::uint8_t* p) noexcept {
    return static_cast<std::int16_t>(be16(p));
}
std::int8_t YepReader::s8(std::uint8_t x) noexcept {
    return static_cast<std::int8_t>(x);
}
std::string YepReader::voice_title(std::size_t index, const std::array<std::uint8_t,3>& id) {
    std::ostringstream os;
    os << "YEP Voice " << index << " ["
       << static_cast<unsigned>(id[0]) << "/"
       << static_cast<unsigned>(id[1]) << "/"
       << static_cast<unsigned>(id[2]) << "]";
    return os.str();
}

bool YepReader::safe_span(std::size_t offset, std::size_t bytes, std::size_t total) noexcept {
    return offset <= total && bytes <= total - offset;
}

bool YepReader::read_chunk(const std::vector<std::uint8_t>& data,
                           std::size_t& pos,
                           std::string& tag,
                           std::vector<std::uint8_t>& payload) {
    if (pos + 8 > data.size()) return false;
    tag.assign(reinterpret_cast<const char*>(data.data() + pos), 4);
    const std::uint32_t n = be32(data.data() + pos + 4);
    pos += 8;
    if (!safe_span(pos, n, data.size())) return false;
    payload.assign(data.begin() + static_cast<std::ptrdiff_t>(pos),
                   data.begin() + static_cast<std::ptrdiff_t>(pos + n));
    pos += n;
    return true;
}

std::vector<std::int16_t> YepReader::extract_be16_pcm(const std::vector<std::uint8_t>& src,
                                                       std::size_t byte_offset,
                                                       std::size_t frames) {
    if (frames == 0 || frames > (std::numeric_limits<std::size_t>::max() / 2u)) return {};
    const std::size_t bytes = frames * 2u;
    if (!safe_span(byte_offset, bytes, src.size())) return {};
    std::vector<std::int16_t> out(frames);
    for (std::size_t i = 0; i < frames; ++i) out[i] = be16s(src.data() + byte_offset + i * 2u);
    return out;
}

std::vector<std::int16_t> YepReader::extract_yep_pcm(const std::vector<std::uint8_t>& src,
                                                      std::size_t byte_offset,
                                                      std::size_t frames) {
    // YEP VWDT samples used by the existing project parser are stored as signed
    // 16-bit big-endian words. The resulting PpfSample is little-runtime-native
    // int16 values, so decode each word explicitly rather than doing a byte copy.
    return extract_be16_pcm(src, byte_offset, frames);
}

void YepReader::clear() noexcept {
    path_.clear();
    file_data_.clear();
    vprm_.clear();
    vwdt_.clear();
    voices_.clear();
    zones_.clear();
    refs_.clear();
    summary_ = {};
}

bool YepReader::open(const std::string& path, std::string& error) {
    clear();
    error.clear();
    std::ifstream f(path, std::ios::binary);
    if (!f) { error = "Cannot open YEP file"; return false; }
    file_data_ = std::vector<std::uint8_t>((std::istreambuf_iterator<char>(f)),
                                            std::istreambuf_iterator<char>());
    if (file_data_.size() < 8) { error = "YEP file is too small"; clear(); return false; }

    std::size_t pos = 0;
    std::string tag;
    std::vector<std::uint8_t> payload;
    bool got_vprm = false, got_vwdt = false;
    while (pos + 8 <= file_data_.size()) {
        if (!read_chunk(file_data_, pos, tag, payload)) break;
        if (tag == "VPRM") { vprm_ = payload; got_vprm = true; }
        else if (tag == "VWDT") { vwdt_ = payload; got_vwdt = true; }
    }
    if (!got_vprm || !got_vwdt) {
        error = "YEP must contain both VPRM and VWDT chunks";
        clear();
        return false;
    }
    if (vprm_.size() < 24) { error = "VPRM chunk is too small"; clear(); return false; }

    const std::uint32_t sample_ptr = be32(vprm_.data() + 16);
    const std::uint32_t hdr1_end = be32(vprm_.data() + 20);
    if (hdr1_end < 24u || hdr1_end > sample_ptr || sample_ptr > vprm_.size()) {
        error = "Invalid YEP VPRM header pointers"; clear(); return false;
    }

    // Voice block boundaries are the offsets listed in the first VPRM header; the
    // established project parser terminates the final voice at sample_ptr.
    std::vector<std::uint32_t> hdr_offsets;
    for (std::size_t p = 24; p + 4 <= hdr1_end; p += 4) {
        const auto x = be32(vprm_.data() + p);
        if (x) hdr_offsets.push_back(x);
    }
    struct RawBlock { std::size_t start=0,end=0; std::array<std::uint8_t,3> id{}; bool drum=false; };
    std::vector<RawBlock> blocks;
    std::size_t cur = hdr1_end;
    for (const auto end_u32 : hdr_offsets) {
        const std::size_t end = static_cast<std::size_t>(end_u32);
        if (end < cur || end > sample_ptr || end > vprm_.size()) continue;
        if (end > cur && end - cur >= 0x26) {
            RawBlock rb;
            rb.start = cur; rb.end = end;
            rb.id = {vprm_[cur + 0x21], vprm_[cur + 0x22], vprm_[cur + 0x23]};
            rb.drum = vprm_[cur + 0x25] != 0;
            blocks.push_back(rb);
        }
        cur = end;
    }
    // Some real YEP files (including SUMBER.yep) have no non-zero voice
    // boundary in the first header. The reference parser treats the remaining
    // VPRM region up to sample_ptr as the final voice/element block.
    if (cur < sample_ptr && sample_ptr - cur >= 0x26) {
        RawBlock rb;
        rb.start = cur; rb.end = sample_ptr;
        rb.id = {vprm_[cur + 0x21], vprm_[cur + 0x22], vprm_[cur + 0x23]};
        rb.drum = vprm_[cur + 0x25] != 0;
        blocks.push_back(rb);
    }
    if (blocks.empty()) { error = "YEP VPRM voice blocks are malformed"; clear(); return false; }

    // Sample-group list and sample block descriptors.
    if (sample_ptr + 8 > vprm_.size()) { error = "Invalid YEP sample section"; clear(); return false; }
    const std::size_t sp = sample_ptr;
    const std::uint32_t shdr_len = be32(vprm_.data() + sp + 4);
    if (shdr_len < 8u || !safe_span(sp, shdr_len, vprm_.size())) {
        error = "Invalid YEP sample-group header"; clear(); return false;
    }
    struct Group { std::int16_t first=0,last=-1; };
    std::vector<Group> groups;
    for (std::size_t p = sp + 8; p + 4 <= sp + shdr_len; p += 4) {
        groups.push_back({static_cast<std::int16_t>(be16(vprm_.data()+p)),
                          static_cast<std::int16_t>(be16(vprm_.data()+p+2))});
    }

    const std::size_t off2 = sp + shdr_len;
    if (off2 + 4 > vprm_.size()) { error = "Invalid YEP sample block table"; clear(); return false; }
    const std::uint32_t block_hdr_len = be32(vprm_.data() + off2);
    const std::size_t table_start = off2 + 4;
    if (block_hdr_len < 4u || !safe_span(off2, block_hdr_len, vprm_.size())) {
        error = "Invalid YEP sample block table length"; clear(); return false;
    }
    std::vector<std::size_t> block_offsets;
    for (std::size_t p = table_start; p + 4 <= off2 + block_hdr_len; p += 4) {
        const auto rel = be32(vprm_.data() + p);
        if (rel) {
            const std::size_t abs = sp + static_cast<std::size_t>(rel);
            if (abs >= sp && abs < vprm_.size()) block_offsets.push_back(abs);
        }
    }
    block_offsets.push_back(vprm_.size());
    if (block_offsets.size() < 2) { error = "YEP contains no sample blocks"; clear(); return false; }

    struct BlockDesc {
        std::size_t index=0,start=0,end=0;
        int low=0, high=127, vel_lo=1, vel_hi=127, center=60;
        int coarse=0, fine=0;
        std::uint8_t channels=1, format=0;
        std::size_t frames=0;
        std::size_t left_frames=0,right_frames=0;
    };
    std::vector<BlockDesc> sample_blocks;
    for (std::size_t i = 0; i + 1 < block_offsets.size(); ++i) {
        const auto start = block_offsets[i], end = block_offsets[i+1];
        if (!(sp <= start && start < end && end <= vprm_.size())) continue;
        if (end - start < 0x48) continue;
        const auto* b = vprm_.data() + start;
        const std::uint32_t raw_len = be32(b + 0x24);
        const std::uint8_t fmt = b[0x2c];
        const std::size_t frames = static_cast<std::size_t>((fmt & 0x04u) ? raw_len * 16u : raw_len);
        const std::uint32_t off_l = be32(b + 0x3c);
        const std::uint32_t off_r = be32(b + 0x44);
        BlockDesc d;
        d.index=i; d.start=start; d.end=end;
        d.low=b[9]; d.high=b[8]; d.vel_lo=b[11]; d.vel_hi=b[10];
        d.center=b[16]; d.coarse=s8(b[17]); d.fine=s8(b[18]);
        d.channels=std::max<std::uint8_t>(1, b[19]); d.format=fmt;
        d.frames=frames; d.left_frames=off_l; d.right_frames=off_r;
        sample_blocks.push_back(d);
    }
    if (sample_blocks.empty()) { error = "YEP contains no usable sample block descriptors"; clear(); return false; }

    // The project’s established YEP parser maps KeyBank ordinal within its assigned
    // Sample Group to the corresponding sample block ordinal. Preserve that rule.
    voices_.reserve(blocks.size());
    for (std::size_t vi = 0; vi < blocks.size(); ++vi) {
        const auto& vb = blocks[vi];
        YepVoiceDescriptor voice;
        voice.voice_index=vi;
        voice.source_voice_id=vb.id;
        voice.voice_type=vb.drum ? "DrumKit" : "Voice";
        voice.title=voice_title(vi,vb.id);
        voice.first_zone_index=zones_.size();

        const auto block_base = vb.start;
        if (block_base + 0x24 + 16 > vb.end) { voices_.push_back(voice); continue; }
        const std::uint32_t h1off0=be32(vprm_.data()+block_base);
        const std::uint32_t h1off1=be32(vprm_.data()+block_base+4);
        if (h1off0 != 0x24u || h1off1 < h1off0 || block_base + h1off1 + 4 > vb.end) {
            voices_.push_back(voice); continue;
        }
        const std::size_t eoff_base = block_base + h1off1;
        const std::uint32_t first_element = be32(vprm_.data()+eoff_base);
        const std::size_t enum_count = first_element >= h1off1 ? (first_element - h1off1) / 4u : 0u;
        for (std::size_t ei=0; ei<enum_count; ++ei) {
            const auto p = eoff_base + ei*4u;
            if (p+4 > vb.end) break;
            const std::size_t eoff = block_base + be32(vprm_.data()+p);
            if (eoff + 176 > vb.end) continue;
            int group_id = static_cast<int>(be16(vprm_.data()+eoff));
            if (group_id >= 0x8000) group_id -= 0x8000;
            const auto nbank = vprm_[eoff+4];
            if (group_id < 0 || static_cast<std::size_t>(group_id) >= groups.size()) {
                summary_.unresolved_zone_count += nbank;
                continue;
            }
            const auto g = groups[static_cast<std::size_t>(group_id)];
            std::vector<const BlockDesc*> eligible;
            if (g.last >= g.first) {
                for (const auto& sb : sample_blocks) {
                    if (static_cast<std::int32_t>(sb.index) >= g.first && static_cast<std::int32_t>(sb.index) <= g.last)
                        eligible.push_back(&sb);
                }
            }
            const std::size_t banks_base = eoff + 176;
            for (std::size_t bi=0; bi<nbank; ++bi) {
                if (banks_base + bi*180u + 180u > vb.end) break;
                const auto* kb = vprm_.data()+banks_base+bi*180u;
                VoiceZone z;
                z.voice_index=vi; z.waveform_index=ei; z.keybank_index=bi; z.voice_title=voice.title;
                z.key_lo=kb[3]; z.key_hi=kb[2]; z.velocity_lo=kb[5]; z.velocity_hi=kb[4];
                const BlockDesc* sb = bi < eligible.size() ? eligible[bi] : nullptr;
                if (!sb) {
                    summary_.unresolved_zone_count++;
                    zones_.push_back(z);
                    refs_.push_back({});
                    continue;
                }
                z.root_note=sb->center; z.sample_rate=static_cast<int>(be32(vprm_.data()+sb->start+0x18));
                z.tune_coarse=sb->coarse; z.tune_fine=sb->fine;
                z.sample_uid = "YEP:" + std::to_string(vi) + ":" + std::to_string(ei) + ":" + std::to_string(bi) + ":" + std::to_string(sb->index);
                z.sample_position = std::to_string(sb->index);
                ZoneSampleRef ref;
                const std::size_t left_b = static_cast<std::size_t>(sb->left_frames) * 2u;
                const std::size_t right_b = static_cast<std::size_t>(sb->right_frames) * 2u;
                ref.vwdt_left_byte=left_b; ref.vwdt_right_byte=right_b; ref.frames=sb->frames;
                ref.right_frames=sb->right_frames; ref.channels=sb->channels; ref.sample_rate=static_cast<std::uint32_t>(z.sample_rate>0?z.sample_rate:44100); ref.format=sb->format;
                if (!safe_span(ref.vwdt_left_byte, ref.frames*2u, vwdt_.size())) {
                    summary_.unresolved_zone_count++;
                    zones_.push_back(z); refs_.push_back({});
                    continue;
                }
                // The production sampler currently consumes a mono resident stream.
                // For YEP stereo descriptors, keep channel 0 authoritative for the
                // first integrated bank; the source offsets remain fully retained in
                // the private ref for the later stereo path. Do not fabricate a second
                // sample or alter the source descriptor.
                zones_.push_back(z); refs_.push_back(ref); summary_.mapped_zone_count++;
            }
        }
        voice.zone_count=zones_.size()-voice.first_zone_index;
        voices_.push_back(voice);
    }

    summary_.vprm_bytes=vprm_.size(); summary_.vwdt_bytes=vwdt_.size();
    summary_.voice_count=voices_.size(); summary_.zone_count=zones_.size(); summary_.sample_block_count=sample_blocks.size();
    summary_.unresolved_zone_count = summary_.zone_count >= summary_.mapped_zone_count
        ? summary_.zone_count-summary_.mapped_zone_count : summary_.unresolved_zone_count;
    path_=path;
    return true;
}

bool YepReader::load_voice_zone_sample(std::size_t voice_index,
                                       std::size_t zone_index,
                                       PpfSample& out,
                                       std::string& error) const {
    out={}; error.clear();
    if (voice_index >= voices_.size()) { error="YEP Voice index out of range"; return false; }
    const auto& v=voices_[voice_index];
    if (zone_index >= v.zone_count || v.first_zone_index + zone_index >= zones_.size()) { error="YEP zone index out of range"; return false; }
    const std::size_t zi=v.first_zone_index+zone_index;
    const auto& z=zones_[zi];
    if (zi >= refs_.size() || refs_[zi].frames == 0) { error="YEP zone has no mapped PCM"; return false; }
    const auto& ref=refs_[zi];
    const auto pcm=extract_yep_pcm(vwdt_,ref.vwdt_left_byte,ref.frames);
    if (pcm.empty()) { error="YEP VWDT PCM extraction failed"; return false; }
    out.uid=z.sample_uid;
    out.pcm=pcm;
    out.sample_rate=static_cast<int>(ref.sample_rate ? ref.sample_rate : 44100u);
    out.from_first_voice=(voice_index==0);
    out.voice_title=v.title;
    return true;
}

} // namespace arranger
