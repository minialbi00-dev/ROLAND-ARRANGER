#pragma once

#include <cstddef>
#include <cstdint>
#include <string>
#include <unordered_map>
#include <vector>

namespace arranger {

struct YamahaStyleMidiEvent {
    std::uint32_t tick = 0;
    std::uint8_t status = 0;
    std::uint8_t data1 = 0;
    std::uint8_t data2 = 0;
    std::uint8_t data_len = 0;
    std::uint16_t track = 0;
};

struct YamahaStyleSection {
    std::string name;
    std::uint32_t start_tick = 0;
    std::uint32_t end_tick = 0;
    std::vector<YamahaStyleMidiEvent> events;
};

struct YamahaStyleCasmSlot {
    std::uint8_t ntr = 0;
    std::uint8_t ntt = 0;
    std::uint8_t high_key = 127;
    std::uint8_t note_lo = 0;
    std::uint8_t note_hi = 127;
    std::uint8_t rtr = 0;
};

struct YamahaStyleCasmRule {
    std::string role;
    std::uint8_t source_channel = 0;
    std::uint8_t destination_channel = 0;
    std::uint8_t source_root = 0;
    std::uint8_t source_type = 0;
    std::vector<YamahaStyleCasmSlot> slots;
    bool explicit_casm = false;
};

struct YamahaStyleSummary {
    std::uint16_t format_type = 0;
    std::uint16_t tracks = 0;
    std::uint16_t division = 480;
    double tempo_bpm = 120.0;
    std::uint8_t time_numerator = 4;
    std::uint8_t time_denominator = 4;
    std::size_t total_events = 0;
    std::size_t section_count = 0;
    std::size_t casm_rule_count = 0;
    std::size_t casm_section_count = 0;
    bool has_casm = false;
};

class YamahaStyleRuntime {
public:
    bool load(const std::string& path, std::string& error);
    void clear() noexcept;

    const YamahaStyleSummary& summary() const noexcept { return summary_; }
    const std::vector<YamahaStyleSection>& sections() const noexcept { return sections_; }
    const std::vector<YamahaStyleMidiEvent>& events() const noexcept { return events_; }
    const std::unordered_map<std::string, YamahaStyleCasmRule>& casm_rules() const noexcept { return casm_rules_; }
    const std::string& path() const noexcept { return path_; }

    const YamahaStyleSection* find_section(const std::string& name) const noexcept;
    const YamahaStyleCasmRule* find_casm_rule(const std::string& section,
                                              std::uint8_t source_channel) const noexcept;

    // C++ port of the baseline Yamaha chord/CASM note transformation path.
    // chord_root_pc: 0=C ... 11=B.
    // chord_type: 0=Major, 1=Minor, 2=7th, 3=Maj7, 4=m7, 5=Dim, 6=Aug.
    bool transform_note(const std::string& section,
                        std::uint8_t source_channel,
                        std::uint8_t input_note,
                        std::uint8_t chord_root_pc,
                        std::uint8_t chord_type,
                        std::uint8_t chord_bass_pc,
                        bool chord_bass_valid,
                        std::uint8_t& output_note,
                        std::uint8_t& destination_channel) const noexcept;

    static bool transform_note_with_rule(const YamahaStyleCasmRule& rule,
                                         std::uint8_t input_note,
                                         std::uint8_t chord_root_pc,
                                         std::uint8_t chord_type,
                                         std::uint8_t chord_bass_pc,
                                         bool chord_bass_valid,
                                         std::uint8_t& output_note,
                                         std::uint8_t& destination_channel) noexcept;

private:
    struct ByteRange { std::size_t offset = 0; std::size_t size = 0; };

    std::string path_;
    YamahaStyleSummary summary_{};
    std::vector<YamahaStyleMidiEvent> events_;
    std::vector<YamahaStyleSection> sections_;

    // Key = normalized section + ':' + source channel.
    std::unordered_map<std::string, YamahaStyleCasmRule> casm_rules_;

    static std::uint16_t read_be16(const std::vector<std::uint8_t>& data,
                                   std::size_t pos) noexcept;
    static std::uint32_t read_be32(const std::vector<std::uint8_t>& data,
                                   std::size_t pos) noexcept;
    static bool read_vlq(const std::vector<std::uint8_t>& data,
                         std::size_t& pos,
                         std::size_t end,
                         std::uint32_t& value) noexcept;

    static std::string normalize_section(const std::string& name);
    static std::string rule_key(const std::string& section,
                                std::uint8_t source_channel);
    static std::uint8_t clamp_note(int note) noexcept;

    bool parse_smf(const std::vector<std::uint8_t>& raw,
                   std::size_t& smf_end,
                   std::string& error);
    bool parse_track(const std::vector<std::uint8_t>& raw,
                     std::size_t start,
                     std::size_t size,
                     std::uint16_t track_index,
                     std::vector<std::pair<std::uint32_t, std::string>>& markers,
                     std::string& track_name,
                     std::string& error);
    void build_sections(const std::vector<std::pair<std::uint32_t, std::string>>& markers,
                        std::uint32_t max_tick);
    void parse_casm(const std::vector<std::uint8_t>& raw,
                    std::size_t smf_end);

    static void parse_casm_payload(const std::vector<std::uint8_t>& payload,
                                   std::unordered_map<std::string, YamahaStyleCasmRule>& out);

    static int major_map(int rel) noexcept;
    static int minor_map(int rel) noexcept;
    static int dom7_map(int rel) noexcept;
    static int maj7_map(int rel) noexcept;
    static int min7_map(int rel) noexcept;
    static int dim_map(int rel) noexcept;
    static int aug_map(int rel) noexcept;
};

} // namespace arranger
