#include "casm_transform_bridge.h"
#include "casm_transform.hpp"

#include <algorithm>

extern "C" {

int YAC_CALL yac_transform_note(const YacmRule* rule,
                                uint8_t input_note,
                                uint8_t chord_root_pc,
                                uint8_t chord_type,
                                uint8_t chord_bass_pc,
                                uint8_t chord_bass_valid,
                                uint8_t* output_note) {
    if (!rule || !output_note) return 0;
    const std::size_t count = std::min<std::size_t>(rule->slot_count, 3u);
    arranger::casm::Slot slots[3]{};
    for (std::size_t i = 0; i < count; ++i) {
        slots[i].ntr = rule->slots[i].ntr;
        slots[i].ntt = rule->slots[i].ntt;
        slots[i].high_key = rule->slots[i].high_key;
        slots[i].note_lo = rule->slots[i].note_lo;
        slots[i].note_hi = rule->slots[i].note_hi;
        slots[i].rtr = rule->slots[i].rtr;
    }
    arranger::casm::Rule cpp_rule{};
    cpp_rule.source_root = rule->source_root;
    cpp_rule.source_type = rule->source_type;
    cpp_rule.destination_channel = rule->destination_channel;
    cpp_rule.slots = slots;
    cpp_rule.slot_count = count;
    return arranger::casm::transform_note(cpp_rule,
                                          input_note,
                                          chord_root_pc,
                                          chord_type,
                                          chord_bass_pc,
                                          chord_bass_valid != 0,
                                          *output_note) ? 1 : 0;
}

} // extern "C"
