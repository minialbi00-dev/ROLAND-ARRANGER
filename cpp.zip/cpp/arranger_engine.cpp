#include "arranger_engine.hpp"

#include <algorithm>
#include <cctype>
#include <limits>
#include <sstream>

namespace arranger {

    namespace {
        std::string up_trim(std::string s) {
            while (!s.empty() && std::isspace(static_cast<unsigned char>(s.back()))) s.pop_back();
            std::size_t first = 0;
            while (first < s.size() && std::isspace(static_cast<unsigned char>(s[first]))) ++first;
            s.erase(0, first);
            for (char& c : s) {
                if (c == '_' || c == '-') c = ' ';
                c = static_cast<char>(std::toupper(static_cast<unsigned char>(c)));
            }
            return s;
        }

        bool starts_with(const std::string& s, const char* prefix) {
            const std::string p(prefix);
            return s.size() >= p.size() && s.compare(0, p.size(), p) == 0;
        }

        std::uint64_t map_key(std::uint8_t ch, std::uint8_t note) {
            return (static_cast<std::uint64_t>(ch) << 8) | note;
        }
    } // namespace

    CppArrangerEngine::CppArrangerEngine(const YamahaStyleRuntime& style)
        : style_(style) {
        division_ = std::max<std::uint16_t>(1, style_.summary().division);
        numerator_ = std::max<std::uint8_t>(1, style_.summary().time_numerator);
        denominator_ = std::max<std::uint8_t>(1, style_.summary().time_denominator);
        const double ticks = static_cast<double>(division_) * static_cast<double>(numerator_) * 4.0 /
            static_cast<double>(denominator_);
        bar_ticks_ = std::max<std::uint32_t>(1, static_cast<std::uint32_t>(ticks + 0.5));
    }

    void CppArrangerEngine::set_chord(std::uint8_t root_pc, std::uint8_t chord_type, std::uint8_t bass_pc, bool bass_valid) noexcept {
        chord_root_pc_ = static_cast<std::uint8_t>(root_pc % 12u);
        chord_type_ = chord_type;
        chord_bass_pc_ = static_cast<std::uint8_t>(bass_pc % 12u);
        chord_bass_valid_ = bass_valid;
    }

    void CppArrangerEngine::set_transpose(int semitones) noexcept {
        transpose_ = std::clamp(semitones, -12, 12);
    }

    std::string CppArrangerEngine::normalize_section(const std::string& name) {
        const std::string n = up_trim(name);
        if (n == "MAINA") return "MAIN A";
        if (n == "MAINB") return "MAIN B";
        if (n == "MAINC") return "MAIN C";
        if (n == "MAIND") return "MAIN D";
        if (n == "INTROA") return "INTRO A";
        if (n == "INTROB") return "INTRO B";
        if (n == "INTROC") return "INTRO C";
        if (n == "ENDINGA") return "ENDING A";
        if (n == "ENDINGB") return "ENDING B";
        if (n == "ENDINGC") return "ENDING C";
        if (starts_with(n, "FILL IN ")) return "FILL " + n.substr(8);
        if (n == "FILL BA" || n == "FILL IN BA" || n == "BREAK") return "BREAK";
        return n;
    }

    bool CppArrangerEngine::is_note_on(const YamahaStyleMidiEvent& e) noexcept {
        return (e.status & 0xF0u) == 0x90u && e.data2 != 0;
    }

    bool CppArrangerEngine::is_note_off(const YamahaStyleMidiEvent& e) noexcept {
        return (e.status & 0xF0u) == 0x80u ||
            ((e.status & 0xF0u) == 0x90u && e.data2 == 0);
    }

    bool CppArrangerEngine::is_rhythm_role(const std::string& role) {
        const std::string r = up_trim(role);
        return r.find("RHYTHM") != std::string::npos ||
            r.find("DRUM") != std::string::npos ||
            r.find("PERC") != std::string::npos ||
            r.find("KIT") != std::string::npos;
    }

    const YamahaStyleCasmRule* CppArrangerEngine::find_rule(const std::string& section,
        std::uint8_t source_ch) const noexcept {
        return style_.find_casm_rule(normalize_section(section), source_ch);
    }

    bool CppArrangerEngine::is_rhythm_event(const YamahaStyleMidiEvent& e,
        const std::string& section) const {
        const auto* rule = find_rule(section, static_cast<std::uint8_t>(e.status & 0x0Fu));
        if (rule) return is_rhythm_role(rule->role);
        return (e.status & 0x0Fu) == 8u || (e.status & 0x0Fu) == 9u;
    }

    std::uint8_t CppArrangerEngine::logical_channel(const YamahaStyleMidiEvent& e,
        const std::string& section) const noexcept {
        const auto source = static_cast<std::uint8_t>(e.status & 0x0Fu);
        if (const auto* rule = find_rule(section, source)) {
            if (is_rhythm_role(rule->role)) return static_cast<std::uint8_t>(rule->destination_channel & 0x0Fu);
        }
        return source;
    }

    ArrangerSectionState CppArrangerEngine::load_state(const std::string& name,
            std::uint32_t start_tick,
            std::uint32_t phase) const {
        ArrangerSectionState state{};
        const auto* section = style_.find_section(normalize_section(name));
        if (!section) return state;
        state.name = section->name;
        state.start_tick = start_tick;
        state.span = std::max<std::uint32_t>(1, section->end_tick - section->start_tick);
        state.phase = std::min(phase, state.span);
        state.one_shot = !(starts_with(state.name, "MAIN ") || starts_with(state.name, "FULL STYLE"));
        state.one_shot_done = false;
        state.last_raw = static_cast<std::int64_t>(state.phase) - 1;
        state.fill_end = 0;
        const auto* section_data = style_.find_section(state.name);
        if (section_data) {
            const auto it = std::lower_bound(section_data->events.begin(), section_data->events.end(),
                section_data->start_tick + state.phase,
                [](const YamahaStyleMidiEvent& event, std::uint32_t tick) {
                    return event.tick < tick;
                });
            state.index = static_cast<std::size_t>(it - section_data->events.begin());
        }
        return state;
    }

    bool CppArrangerEngine::section_exists(const std::string& name) const noexcept {
        return style_.find_section(normalize_section(name)) != nullptr;
    }

    std::string CppArrangerEngine::fill_destination_for(const std::string& fill) const {
        const std::string n = normalize_section(fill);
        if (n == "FILL AA") return "MAIN A";
        if (n == "FILL BB") return "MAIN B";
        if (n == "FILL CC") return "MAIN C";
        if (n == "FILL DD") return "MAIN D";
        if (n == "BREAK") return active_main_.empty() ? "MAIN A" : active_main_;
        return active_main_.empty() ? "MAIN A" : active_main_;
    }

    bool CppArrangerEngine::start(std::string& error) {
        error.clear();
        if (style_.sections().empty()) { error = "Style has no sections"; return false; }
        if (running_) return true;

        division_ = std::max<std::uint16_t>(1, style_.summary().division);
        numerator_ = std::max<std::uint8_t>(1, style_.summary().time_numerator);
        denominator_ = std::max<std::uint8_t>(1, style_.summary().time_denominator);
        const double ticks = static_cast<double>(division_) * static_cast<double>(numerator_) * 4.0 /
            static_cast<double>(denominator_);
        bar_ticks_ = std::max<std::uint32_t>(1, static_cast<std::uint32_t>(ticks + 0.5));

        std::string main;
        if (!active_main_.empty() && starts_with(active_main_, "MAIN ") && section_exists(active_main_))
            main = active_main_;
        if (main.empty() && section_exists("MAIN A")) main = "MAIN A";
        if (main.empty()) {
            for (const auto& s : style_.sections()) {
                const auto n = normalize_section(s.name);
                if (starts_with(n, "MAIN ")) { main = n; break; }
            }
        }
        if (main.empty()) main = normalize_section(style_.sections().front().name);

        active_main_ = starts_with(main, "MAIN ") ? main : "";
        current_section_ = main;
        intro_return_main_ = active_main_.empty() ? "MAIN A" : active_main_;
        pending_main_.clear();
        pending_fill_.clear();
        pending_ending_.clear();
        fill_destination_.clear();
        has_fill_ = false;
        ending_completed_ = false;
        current_tick_ = 0;
        scheduler_initialized_ = true;
        main_state_ = load_state(main, 0, 0);
        if (main_state_.name.empty()) { error = "Unable to initialize starting Style section"; return false; }
        fill_state_ = {};
        running_ = true;
        acmp_note_map_.clear();
        voice_msb_.clear();
        voice_lsb_.clear();
        voice_program_.clear();
        return true;
    }

    bool CppArrangerEngine::queue_main(const std::string& name, std::string& error) {
        error.clear();
        const auto n = normalize_section(name);
        if (!section_exists(n)) { error = "MAIN section not found: " + n; return false; }
        if (!running_) {
            active_main_ = starts_with(n, "MAIN ") ? n : active_main_;
            current_section_ = n;
            pending_main_.clear();
            pending_fill_.clear();
            pending_ending_.clear();
            has_fill_ = false;
            fill_state_ = {};
            return true;
        }
        pending_main_ = n;
        pending_fill_.clear();
        pending_ending_.clear();
        fill_state_ = has_fill_ ? fill_state_ : ArrangerSectionState{};
        fill_destination_ = n;
        return true;
    }

    bool CppArrangerEngine::queue_fill(const std::string& name, std::string& error) {
        error.clear();
        const auto n = normalize_section(name);
        if (!section_exists(n)) { error = "FILL section not found: " + n; return false; }
        if (!running_) {
            const std::string destination = fill_destination_for(n);
            if (section_exists(destination) && starts_with(destination, "MAIN ")) active_main_ = destination;
            current_section_ = n;
            pending_main_.clear();
            pending_fill_.clear();
            pending_ending_.clear();
            has_fill_ = false;
            fill_state_ = {};
            return true;
        }
        pending_main_.clear();
        pending_ending_.clear();
        pending_fill_ = n;
        fill_destination_ = fill_destination_for(n);
        return true;
    }

    bool CppArrangerEngine::queue_intro(const std::string& name, std::string& error) {
        error.clear();
        const auto n = normalize_section(name);
        if (!section_exists(n)) { error = "INTRO section not found: " + n; return false; }
        intro_return_main_ = active_main_.empty() ? "MAIN A" : active_main_;
        pending_fill_.clear();
        pending_ending_.clear();
        pending_main_ = n;
        return true;
    }

    bool CppArrangerEngine::queue_ending(const std::string& name, std::string& error) {
        error.clear();
        const auto n = normalize_section(name);
        if (!section_exists(n)) { error = "ENDING section not found: " + n; return false; }
        pending_ending_ = n;
        pending_main_.clear();
        pending_fill_.clear();
        return true;
    }

    void CppArrangerEngine::stop() noexcept {
        running_ = false;
        scheduler_initialized_ = false;
        ending_completed_ = false;
        current_tick_ = 0;
        has_fill_ = false;
        pending_main_.clear();
        pending_fill_.clear();
        pending_ending_.clear();
        fill_destination_.clear();
        fill_state_ = {};
        current_section_ = active_main_;
        if (current_section_.empty()) current_section_ = "MAIN A";
        main_state_ = {};
        acmp_note_map_.clear();
        voice_msb_.clear();
        voice_lsb_.clear();
        voice_program_.clear();
    }

    void CppArrangerEngine::emit_event(const YamahaStyleMidiEvent& e,
        const std::string& section,
        std::uint32_t global_tick,
        std::vector<ArrangerOutputEvent>& out) {
        auto status = e.status;
        std::uint8_t data1 = e.data1;
        const auto source_ch = static_cast<std::uint8_t>(status & 0x0Fu);
        std::uint8_t dest_ch = logical_channel(e, section);

        if (status >= 0xF0u) return;

        if ((status & 0xF0u) == 0xB0u) {
            if (e.data1 == 0u) voice_msb_[dest_ch] = static_cast<std::uint8_t>(e.data2 & 0x7Fu);
            if (e.data1 == 32u) voice_lsb_[dest_ch] = static_cast<std::uint8_t>(e.data2 & 0x7Fu);
            if (e.data1 == 0u || e.data1 == 32u || e.data1 == 7u || e.data1 == 10u || e.data1 == 11u || e.data1 == 64u || e.data1 == 91u)
                voice_program_[dest_ch] = voice_program_[dest_ch];
        }
        if ((status & 0xF0u) == 0xC0u) voice_program_[dest_ch] = data1 & 0x7Fu;

        if (is_note_on(e) || is_note_off(e)) {
            if (!is_rhythm_event(e, section) && acmp_enabled_) {
                std::uint8_t transformed = data1;
                std::uint8_t casm_dest = dest_ch;
                if (is_note_off(e)) {
                    const auto it = acmp_note_map_.find(map_key(source_ch, e.data1));
                    if (it != acmp_note_map_.end()) {
                        data1 = it->second;
                        acmp_note_map_.erase(it);
                    }
                    else {
                        std::uint8_t transformed = data1;
                        if (style_.transform_note(section, source_ch, data1, chord_root_pc_, chord_type_, chord_bass_pc_, chord_bass_valid_, transformed, casm_dest)) {
                            dest_ch = static_cast<std::uint8_t>(casm_dest & 0x0Fu);
                            data1 = transformed;
                        }
                        else {
                            const int shifted = static_cast<int>(data1) + transpose_;
                            data1 = static_cast<std::uint8_t>(std::clamp(shifted, 0, 127));
                        }
                    }
                }
                else if (style_.transform_note(section, source_ch, data1, chord_root_pc_, chord_type_, chord_bass_pc_, chord_bass_valid_, transformed, casm_dest)) {
                    dest_ch = static_cast<std::uint8_t>(casm_dest & 0x0Fu);
                    data1 = transformed;
                    acmp_note_map_[map_key(source_ch, e.data1)] = data1;
                }
                else {
                    const int shifted = static_cast<int>(data1) + transpose_;
                    data1 = static_cast<std::uint8_t>(std::clamp(shifted, 0, 127));
                }
            }
            else {
                const int shifted = static_cast<int>(data1) + ((!is_rhythm_event(e, section)) ? transpose_ : 0);
                data1 = static_cast<std::uint8_t>(std::clamp(shifted, 0, 127));
            }
        }

        status = static_cast<std::uint8_t>((status & 0xF0u) | (dest_ch & 0x0Fu));
        out.push_back(ArrangerOutputEvent{ global_tick, status, data1,
                                          static_cast<std::uint8_t>(e.data2 & 0x7Fu), e.track, section });
    }

    void CppArrangerEngine::process_state(ArrangerSectionState& state,
        std::uint32_t until_tick,
        std::uint8_t filter_mode,
        std::vector<ArrangerOutputEvent>& out) {
        if (state.name.empty() || state.span == 0 || until_tick < state.start_tick) return;
        const auto* section = style_.find_section(state.name);
        if (!section) return;

        const std::int64_t from_raw = state.last_raw;
        const std::int64_t to_raw = static_cast<std::int64_t>(until_tick - state.start_tick);
        if (to_raw < from_raw) return;

        const auto& events = section->events;
        const auto first_event_after = [&](std::int64_t relative_tick) {
            return std::upper_bound(events.begin(), events.end(), relative_tick,
                [&](std::int64_t tick, const YamahaStyleMidiEvent& event) {
                    return tick < static_cast<std::int64_t>(event.tick - section->start_tick);
                });
        };
        auto should_emit = [&](const YamahaStyleMidiEvent& e) {
            switch (filter_mode) {
            case 0u: return true;
            case 1u: return is_rhythm_event(e, state.name);
            case 2u: return !is_rhythm_event(e, state.name);
            case 3u: return false;
            default: return true;
            }
            };

        if (state.one_shot) {
            for (auto it = first_event_after(from_raw); it != events.end(); ++it) {
                const auto rel = it->tick - section->start_tick;
                if (static_cast<std::int64_t>(rel) > to_raw) break;
                if (should_emit(*it)) emit_event(*it, state.name, state.start_tick + rel, out);
            }
            state.last_raw = to_raw;
            return;
        }

        const std::uint64_t span = state.span;
        const std::uint64_t first_cycle = from_raw < 0 ? 0u : static_cast<std::uint64_t>(from_raw) / span;
        const std::uint64_t last_cycle = static_cast<std::uint64_t>(to_raw) / span;
        for (std::uint64_t cycle = first_cycle; cycle <= last_cycle; ++cycle) {
            const std::int64_t cycle_base = static_cast<std::int64_t>(cycle * span);
            const std::int64_t from_local = from_raw - cycle_base;
            for (auto it = first_event_after(from_local); it != events.end(); ++it) {
                const auto rel = it->tick - section->start_tick;
                const std::int64_t local = cycle_base + static_cast<std::int64_t>(rel);
                if (local > to_raw) break;
                if (should_emit(*it)) emit_event(*it, state.name, state.start_tick + static_cast<std::uint32_t>(local), out);
            }
            if (cycle == std::numeric_limits<std::uint64_t>::max()) break;
        }
        state.last_raw = to_raw;
    }

    bool CppArrangerEngine::advance_to(std::uint32_t global_tick,
        std::vector<ArrangerOutputEvent>& out,
        std::string& error) {
        error.clear();
        out.clear();
        if (!running_) { error = "Arranger scheduler is not running"; return false; }
        if (global_tick < current_tick_) { error = "Scheduler cannot move backward in time"; return false; }
        if (!scheduler_initialized_) { error = "Scheduler is not initialized"; return false; }
        if (global_tick == current_tick_ && current_tick_ != 0) return true;

        const std::uint32_t start_tick = current_tick_;
        const std::uint32_t first_boundary = ((start_tick / bar_ticks_) + 1u) * bar_ticks_;
        std::uint32_t cursor = start_tick;
        bool boundary_processed = false;

        auto process_boundary = [&](std::uint32_t boundary) -> bool {
            if (boundary == 0) return true;

            if (has_fill_ && boundary >= fill_state_.fill_end) {
                has_fill_ = false;
                const std::string target = fill_destination_.empty()
                    ? (active_main_.empty() ? "MAIN A" : active_main_)
                    : fill_destination_;
                fill_destination_.clear();
                if (section_exists(target)) {
                    main_state_ = load_state(target, boundary, 0);
                    current_section_ = target;
                    active_main_ = starts_with(target, "MAIN ") ? target : active_main_;
                }
            }

            if (pending_ending_.size() && !has_fill_) {
                const std::string target = pending_ending_;
                pending_ending_.clear();
                main_state_ = load_state(target, boundary, 0);
                current_section_ = target;
                fill_state_ = {};
                if (section_exists(target)) {
                    active_main_.clear();
                    return true;
                }
            }

            if (pending_main_.size() && !has_fill_) {
                const std::string target = pending_main_;
                pending_main_.clear();
                if (section_exists(target)) {
                    if (starts_with(target, "INTRO ")) intro_return_main_ = active_main_.empty() ? "MAIN A" : active_main_;
                    if (starts_with(target, "MAIN ")) active_main_ = target;
                    main_state_ = load_state(target, boundary, 0);
                    current_section_ = target;
                    return true;
                }
            }
            return true;
            };

        if (!boundary_processed && cursor == 0) {
            process_state(main_state_, 0, 0u, out);
            boundary_processed = true;
        }

        auto start_pending_fill_now = [&]() {
            if (pending_fill_.empty() || has_fill_) return;
            const std::string requested = pending_fill_;
            pending_fill_.clear();
            fill_destination_ = fill_destination_for(requested);
            const std::uint32_t bar_start = (cursor / bar_ticks_) * bar_ticks_;
            const std::uint32_t phase = cursor - bar_start;
            fill_state_ = load_state(requested, bar_start, phase);
            fill_state_.fill_end = bar_start + bar_ticks_;
            if (fill_state_.span > bar_ticks_) fill_state_.fill_end = bar_start + fill_state_.span;
            has_fill_ = !fill_state_.name.empty();
            if (has_fill_) current_section_ = fill_state_.name;
            };

        start_pending_fill_now();

        while (cursor < global_tick&& running_) {
            const std::uint32_t boundary = ((cursor / bar_ticks_) + 1u) * bar_ticks_;
            const bool has_boundary = boundary > cursor && boundary <= global_tick;

            if (has_boundary) {
                const std::uint32_t pre_boundary = boundary - 1u;
                if (has_fill_) {
                    const bool late = fill_state_.phase > division_ / 4u;
                    process_state(main_state_, pre_boundary, late ? 2u : 3u, out);
                    process_state(fill_state_, pre_boundary, late ? 1u : 0u, out);
                }
                else {
                    process_state(main_state_, pre_boundary, 0u, out);
                }
                cursor = boundary;
                if (!process_boundary(boundary)) {
                    error = "Failed applying section boundary";
                    return false;
                }

                if (!has_fill_) start_pending_fill_now();

                if (has_fill_) {
                    const bool late = fill_state_.phase > division_ / 4u;
                    process_state(main_state_, boundary, late ? 2u : 3u, out);
                    process_state(fill_state_, boundary, late ? 1u : 0u, out);
                }
                else {
                    process_state(main_state_, boundary, 0u, out);
                }

                if (main_state_.one_shot &&
                    static_cast<std::uint32_t>(cursor - main_state_.start_tick) >= main_state_.span) {
                    const auto completed = main_state_.name;
                    main_state_.one_shot_done = true;
                    if (starts_with(completed, "INTRO ")) {
                        const std::string target = intro_return_main_.empty() ? "MAIN A" : intro_return_main_;
                        if (section_exists(target)) {
                            main_state_ = load_state(target, cursor, 0);
                            current_section_ = target;
                            active_main_ = target;
                        }
                    }
                    else if (starts_with(completed, "ENDING ")) {
                        ending_completed_ = true;
                        running_ = false;
                        break;
                    }
                    else if (completed == "BREAK" || starts_with(completed, "FILL ")) {
                        const std::string target = active_main_.empty() ? "MAIN A" : active_main_;
                        if (section_exists(target)) {
                            main_state_ = load_state(target, cursor, 0);
                            current_section_ = target;
                        }
                    }
                }

                if (has_fill_ && !pending_fill_.empty()) {
                    const std::string requested = pending_fill_;
                    pending_fill_.clear();
                    fill_destination_ = fill_destination_for(requested);
                }
                continue;
            }

            if (has_fill_) {
                const bool late = fill_state_.phase > division_ / 4u;
                process_state(main_state_, global_tick, late ? 2u : 3u, out);
                process_state(fill_state_, global_tick, late ? 1u : 0u, out);
            }
            else {
                process_state(main_state_, global_tick, 0u, out);
            }
            cursor = global_tick;

            if (main_state_.one_shot &&
                static_cast<std::uint32_t>(cursor - main_state_.start_tick) >= main_state_.span) {
                const auto completed = main_state_.name;
                main_state_.one_shot_done = true;
                if (starts_with(completed, "INTRO ")) {
                    const std::string target = intro_return_main_.empty() ? "MAIN A" : intro_return_main_;
                    if (section_exists(target)) {
                        main_state_ = load_state(target, cursor, 0);
                        current_section_ = target;
                        active_main_ = target;
                    }
                }
                else if (starts_with(completed, "ENDING ")) {
                    ending_completed_ = true;
                    running_ = false;
                    break;
                }
                else if (completed == "BREAK" || starts_with(completed, "FILL ")) {
                    const std::string target = active_main_.empty() ? "MAIN A" : active_main_;
                    if (section_exists(target)) {
                        main_state_ = load_state(target, cursor, 0);
                        current_section_ = target;
                    }
                }
            }
        }

        current_tick_ = global_tick;
        return true;
    }

} // namespace arranger