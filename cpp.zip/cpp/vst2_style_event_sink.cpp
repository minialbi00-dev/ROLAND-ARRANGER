#include "vst2_style_event_sink.hpp"
#include <algorithm>
#include <cmath>
#include <limits>

namespace arranger {

bool Vst2StyleEventSink::push(const ArrangerOutputEvent& event,
                              std::uint32_t block_start_tick,
                              double frames_per_tick,
                              std::size_t block_frames,
                              std::string& error) {
    error.clear();
    if (!std::isfinite(frames_per_tick) || frames_per_tick <= 0.0) { error="Invalid VST frame/tick conversion"; return false; }
    if (event.global_tick < block_start_tick) { error="Arranger event lies before VST block start"; return false; }
    const auto delta = static_cast<long long>(std::llround(
        static_cast<double>(event.global_tick - block_start_tick) * frames_per_tick));
    if (delta < 0 || delta >= static_cast<long long>(block_frames)) {
        error="Arranger event falls outside VST process block";
        return false;
    }
    const auto cmd=static_cast<std::uint8_t>(event.status & 0xF0u);
    if (cmd != 0x80u && cmd != 0x90u && cmd != 0xA0u && cmd != 0xB0u && cmd != 0xC0u && cmd != 0xD0u && cmd != 0xE0u) {
        return true;
    }
    VstMidiPacket p;
    p.delta_frames=static_cast<std::int32_t>(delta);
    p.midi={event.status,event.data1,event.data2};
    packets_.push_back(p);
    return true;
}

bool Vst2StyleEventSink::build_events(VstEvents* out,
                                      std::vector<VstMidiEvent>& storage,
                                      std::vector<VstEvent*>& pointers,
                                      std::string& error) const {
    error.clear();
    if (!out) { error="Null VST event batch"; return false; }
    if (packets_.size() > 128u) { error="VST event batch exceeds safety limit"; return false; }
    storage.clear(); pointers.clear(); storage.reserve(packets_.size()); pointers.reserve(packets_.size());
    for (const auto& p : packets_) {
        VstMidiEvent m{};
        m.type=vst2mini::kVstMidiType;
        m.byteSize=sizeof(VstMidiEvent);
        m.deltaFrames=p.delta_frames;
        m.midiData[0]=static_cast<char>(p.midi[0]);
        m.midiData[1]=static_cast<char>(p.midi[1]);
        m.midiData[2]=static_cast<char>(p.midi[2]);
        storage.push_back(m);
    }
    for (auto& m:storage) pointers.push_back(reinterpret_cast<VstEvent*>(&m));
    out->numEvents=static_cast<vst2mini::VstInt32>(pointers.size());
    out->reserved=0;
    // VstEvents is a variable-length structure. Its first two inline pointers are
    // not enough for arbitrary batches, so the caller must provide its own compatible
    // trailing storage when passing this object to a host. This function is therefore
    // intended for deterministic packet construction/tests, not direct host dispatch.
    for (std::size_t i=0; i<std::min<std::size_t>(2,pointers.size()); ++i) out->events[i]=pointers[i];
    return true;
}

} // namespace arranger
