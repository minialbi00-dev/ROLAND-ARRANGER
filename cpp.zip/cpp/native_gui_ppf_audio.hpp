#pragma once
#include "ppf_reader.hpp"
#include "ppf_runtime.hpp"
#include "ppf_note_engine.hpp"
#include "ppf_voice_bank.hpp"
#include "resident_sampler.hpp"
#include "soundfont_bank.hpp"
#include "voice_install_catalog.hpp"
#include "yamaha_style_runtime.hpp"
#include "arranger_engine.hpp"
#ifdef __ANDROID__
#include <oboe/Oboe.h>
#endif

#include <array>
#include <atomic>
#include <cstddef>
#include <cstdint>
#include <memory>
#include <string>
#include <thread>
#include <unordered_map>
#include <vector>

namespace arranger {

#ifdef ARRANGER_ENABLE_TEST_ACCESS
struct NativeGuiPpfAudioTestAccess;
#endif

struct NativeGuiAudioEvent {
    std::uint32_t tick = 0;
    std::uint8_t status = 0;
    std::uint8_t data1 = 0;
    std::uint8_t data2 = 0;
};

struct NativeGuiPpfBankInfo {
    std::size_t bank_id = 0;
    std::uint8_t msb = 63;
    std::uint8_t lsb = 62;
    std::size_t voice_count = 0;
    std::string path;
};

struct NativeGuiAudioMetrics {
    std::size_t ppf_voice_count = 0;
    std::size_t ppf_bank_count = 0;
    std::size_t resident_zone_count = 0;
    std::size_t unique_pcm_count = 0;
    std::uint64_t resident_pcm_bytes = 0;
    std::size_t active_voices = 0;
    std::uint64_t rendered_frames = 0;
    std::uint64_t nonzero_samples = 0;
    std::uint64_t nonfinite_samples = 0;
    std::uint64_t render_deadline_misses = 0;
    std::uint64_t dropped_events = 0;
    std::uint64_t events_processed = 0;
    std::uint64_t max_render_us = 0;
    std::uint32_t output_rate = 0;
    std::uint32_t buffer_frames = 0;
    double buffer_latency_ms = 0.0;
    float peak = 0.0f;
    bool active = false;
    bool soundfont_loaded = false;
    std::size_t soundfont_zone_count = 0;
    std::size_t soundfont_sample_count = 0;
    std::uint64_t soundfont_fallback_notes = 0;
};

struct NativeGuiPpfVoiceInfo {
    std::size_t bank_id = 0;
    std::size_t source_index = 0;
    std::string title;
    std::string source_path;
    InstalledVoiceAddress source_address{};
    InstalledVoiceAddress installed_address{};
    bool source_address_valid = false;
    bool installed_address_valid = false;
    std::size_t zone_count = 0;
    std::size_t resident_zone_count = 0;
    std::string voice_type;
};

#ifdef __ANDROID__
class NativeGuiPpfAudio : public oboe::AudioStreamDataCallback {
#else
class NativeGuiPpfAudio {
#endif
public:
    NativeGuiPpfAudio();
    ~NativeGuiPpfAudio();

    // Product API: install a PPF bank preserving its exact Yamaha source slot.
    // 0xFF/0xFF means read the slot from PPF metadata. No free-slot allocator
    // or import-order remapping is permitted.
    bool install_ppf_bank(const std::string& ppf_path,
                          InstalledVoiceAddress installed_base,
                          const YamahaStyleRuntime& style,
                          std::string& error);

    // Audio-only installation path. It installs the PPF bank and preserves
    // source/install addresses, but does not parse or schedule Yamaha Style
    // data. The Python Original Baseline remains the arranger authority.
    bool install_ppf_bank_audio_only(const std::string& ppf_path,
                                     InstalledVoiceAddress installed_base,
                                     std::string& error);
    bool uninstall_ppf_bank(std::size_t bank_id, std::string& error);
    std::vector<NativeGuiPpfBankInfo> installed_ppf_banks() const;
    std::vector<NativeGuiPpfVoiceInfo> installed_ppf_voices() const;

    // Preload exactly one Voice identified by the baseline-emitted MSB/LSB/PC.
    // Return 1 when resolved and resident, 0 when the address is not present,
    // and -1 on a residency/argument error. This is an audio-residency API;
    // it does not modify arranger semantics.
    int preload_style_voice(const StyleVoiceCall& call, std::string& error);

    // Regression-only compatibility path retained for V0.60 probes. It clears
    // the installed PPF catalog and installs exactly one explicit bank.
    bool configure(const std::string& ppf_path,
                   const YamahaStyleRuntime& style,
                   std::string& error);

    bool start(double bpm, std::uint16_t division, std::string& error);
    // Load a user-selected SF2 file before playback. Safe only while stopped.
    bool load_soundfont(const std::string& path, std::string& error);
#ifdef __ANDROID__
    oboe::DataCallbackResult onAudioReady(oboe::AudioStream* stream, void* audio_data,
                                          std::int32_t num_frames) override;
#endif
    void set_audio_device_id(const std::string& device_id) noexcept;
    std::string audio_device_id() const;
    void stop() noexcept;
    bool is_active() const noexcept { return active_.load(std::memory_order_acquire); }

    bool enqueue(const ArrangerOutputEvent& event) noexcept;
    bool prepare_style(const YamahaStyleRuntime& style, std::string& error);
    void set_timing(double bpm, std::uint16_t division) noexcept;
    void reanchor(std::uint32_t tick = 0) noexcept;

    std::size_t installed_ppf_bank_count() const noexcept;
    bool has_audio_source() const noexcept;
    NativeGuiAudioMetrics metrics() const noexcept;

private:
#ifdef ARRANGER_ENABLE_TEST_ACCESS
    friend struct NativeGuiPpfAudioTestAccess;
#endif
    static constexpr std::size_t kQueueCapacity = 8192;
    static constexpr std::size_t kPendingCapacity = 512;
    static constexpr std::size_t kMaxVoices = ResidentSampler::kMaxVoices;

    struct Ring {
        std::array<NativeGuiAudioEvent, kQueueCapacity> data{};
        std::atomic<std::uint32_t> head{0};
        std::atomic<std::uint32_t> tail{0};
    };

    struct PpfRuntimeBank {
        std::size_t bank_id = 0;
        std::string path;
        InstalledVoiceAddress installed_base{};
        std::shared_ptr<PpfReader> reader;
        PpfInstalledVoiceBank voice_bank;
    };

    bool render_audio(float* out_stereo, std::size_t frames, int output_rate) noexcept;
    bool open_wasapi(double bpm, std::uint16_t division, std::string& error);
    void audio_thread_main();
    void close_wasapi() noexcept;

    PpfRuntimeBank* find_runtime_bank(std::size_t bank_id) noexcept;
    const PpfRuntimeBank* find_runtime_bank(std::size_t bank_id) const noexcept;
    bool prepare_voice(const InstalledVoiceRecord& voice, std::string& error);
    bool ensure_soundfont(std::string& error);
    void reset_transport() noexcept;
    const PpfRuntimeZone* choose_zone(std::size_t bank_id, std::size_t voice_index,
                                      int note, int velocity) const noexcept;
    bool handle_event(const NativeGuiAudioEvent& event) noexcept;

    static ResidentSamplePtr to_resident(const PpfSample& src);
    static float zone_gain(const VoiceZone& z) noexcept;
    static float zone_pan(const VoiceZone& z) noexcept;
    static double zone_pitch_ratio(const VoiceZone& z, int note) noexcept;

    bool push(const NativeGuiAudioEvent& e) noexcept;
    bool pop(NativeGuiAudioEvent& e) noexcept;

    std::vector<PpfRuntimeBank> ppf_banks_;
    std::string audio_device_id_;
    InstalledVoiceCatalog catalog_;
    // Native PPF runtime ownership/resolution is isolated from the GUI/audio
    // transport layer. This object contains only already-resident Voice zones
    // and performs exact Note + Velocity eligibility decisions in C++.
    PpfRuntime ppf_runtime_;
    std::unordered_map<std::string, ResidentSamplePtr> pcm_cache_;
    std::array<std::array<std::int64_t, 128>, 16> active_slots_{};
    std::array<std::uint8_t, 16> msb_{};
    std::array<std::uint8_t, 16> lsb_{};
    std::array<std::uint8_t, 16> program_{};
    SoundFontBank soundfont_;
    std::atomic<std::uint64_t> soundfont_fallback_notes_{0};
    std::vector<NativeGuiAudioEvent> pending_;
    ResidentSampler sampler_;
    PpfNoteEngine ppf_note_engine_;

    Ring queue_;
    std::atomic<bool> active_{false};
    std::atomic<bool> stop_requested_{false};
    std::thread audio_thread_;
#ifdef __ANDROID__
    std::shared_ptr<oboe::AudioStream> android_stream_;
#endif

    std::atomic<std::uint64_t> rendered_frames_{0};
    std::atomic<std::uint64_t> nonzero_samples_{0};
    std::atomic<std::uint64_t> nonfinite_samples_{0};
    std::atomic<std::uint64_t> render_deadline_misses_{0};
    std::atomic<std::uint64_t> dropped_events_{0};
    std::atomic<std::uint64_t> events_processed_{0};
    std::atomic<std::uint64_t> max_render_us_{0};
    std::atomic<std::uint32_t> active_voices_{0};
    std::atomic<std::uint32_t> output_rate_{0};
    std::atomic<std::uint32_t> buffer_frames_{0};
    std::atomic<std::uint32_t> ppf_voice_count_{0};
    std::atomic<std::uint32_t> ppf_bank_count_{0};
    std::atomic<std::uint32_t> resident_zone_count_{0};
    std::atomic<std::uint32_t> unique_pcm_count_{0};
    std::atomic<std::uint64_t> resident_pcm_bytes_{0};
    std::atomic<std::uint64_t> nonzero_peak_milli_{0};

    std::atomic<double> bpm_{120.0};
    std::atomic<std::uint32_t> anchor_tick_{0};
    std::atomic<std::uint64_t> anchor_frame_{0};
    std::atomic<std::uint16_t> division_{480};

#ifdef _WIN32
    struct WasapiState;
    std::unique_ptr<WasapiState> wasapi_;
#endif
};

} // namespace arranger