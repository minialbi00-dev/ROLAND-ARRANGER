#pragma once
#include "voice_types.hpp"
#include <cstdint>
#include <memory>
#include <string>
#include <unordered_map>
#include <vector>

namespace arranger {

class SoundFontBank {
public:
    struct Zone {
        std::uint16_t bank = 0;
        std::uint8_t program = 0;
        std::uint8_t key_lo = 0;
        std::uint8_t key_hi = 127;
        std::uint8_t velocity_lo = 1;
        std::uint8_t velocity_hi = 127;
        std::int16_t coarse_tune = 0;
        std::int16_t fine_tune = 0;
        std::int16_t attenuation_tenthdB = 0;
        std::int16_t pan_tenths_percent = 0;
        std::int16_t root_override = -1;
        bool loop = false;
        std::size_t loop_start_frame = 0;
        std::size_t loop_end_frame = 0;
        ResidentSamplePtr sample;
    };

    bool load(const std::string& path, std::string& error);
    bool loaded() const noexcept { return loaded_; }
    const std::string& path() const noexcept { return path_; }
    std::size_t zone_count() const noexcept { return zone_count_; }
    std::size_t sample_count() const noexcept { return samples_.size(); }

    const Zone* choose(std::uint16_t bank, std::uint8_t program,
                       std::uint8_t key, std::uint8_t velocity) const noexcept;

private:
    struct PresetKey {
        std::uint16_t bank = 0;
        std::uint8_t program = 0;
        bool operator==(const PresetKey& o) const noexcept {
            return bank == o.bank && program == o.program;
        }
    };
    struct PresetKeyHash {
        std::size_t operator()(const PresetKey& k) const noexcept {
            return (static_cast<std::size_t>(k.bank) << 8) ^ k.program;
        }
    };

    std::string path_;
    bool loaded_ = false;
    std::size_t zone_count_ = 0;
    std::vector<ResidentSamplePtr> samples_;
    std::unordered_map<PresetKey, std::vector<Zone>, PresetKeyHash> zones_;
};

} // namespace arranger
