#include "ppf_runtime.hpp"

#include <algorithm>
#include <limits>
#include <new>

namespace arranger {

namespace {

int clamp_midi(int value) noexcept {
    return std::clamp(value, 0, 127);
}

int key_span(const VoiceZone& z) noexcept {
    return std::max(0, z.key_hi - z.key_lo);
}

int velocity_span(const VoiceZone& z) noexcept {
    return std::max(0, z.velocity_hi - z.velocity_lo);
}

bool better_zone(const VoiceZone& candidate, const VoiceZone* best) noexcept {
    if (!best) return true;

    const int candidate_key_span = key_span(candidate);
    const int best_key_span = key_span(*best);
    if (candidate_key_span != best_key_span) return candidate_key_span < best_key_span;

    const int candidate_velocity_span = velocity_span(candidate);
    const int best_velocity_span = velocity_span(*best);
    if (candidate_velocity_span != best_velocity_span) return candidate_velocity_span < best_velocity_span;

    if (candidate.velocity_lo != best->velocity_lo)
        return candidate.velocity_lo > best->velocity_lo;

    if (candidate.keybank_index != best->keybank_index)
        return candidate.keybank_index < best->keybank_index;

    if (candidate.waveform_index != best->waveform_index)
        return candidate.waveform_index < best->waveform_index;

    if (candidate.sample_position != best->sample_position)
        return candidate.sample_position < best->sample_position;

    if (candidate.sample_uid != best->sample_uid)
        return candidate.sample_uid < best->sample_uid;

    return false;
}

} // namespace

const PpfRuntimeZone* PpfRuntimeVoice::resolve(int note, int velocity) const noexcept {
    const int n = clamp_midi(note);
    const int v = clamp_midi(velocity);

    const PpfRuntimeZone* best = nullptr;
    for (const auto& candidate : zones) {
        const auto& z = candidate.zone;
        if (n < z.key_lo || n > z.key_hi) continue;
        if (v < z.velocity_lo || v > z.velocity_hi) continue;
        if (!candidate.sample || candidate.sample->pcm.empty()) continue;
        if (better_zone(z, best ? &best->zone : nullptr)) best = &candidate;
    }
    return best;
}

void PpfRuntime::clear() noexcept {
    std::unordered_map<std::uint64_t, PpfRuntimeVoice>().swap(voices_);
}

std::uint64_t PpfRuntime::make_key(std::size_t bank_id, std::size_t source_index) noexcept {
    return (static_cast<std::uint64_t>(bank_id) << 32) |
           static_cast<std::uint64_t>(source_index);
}

bool PpfRuntime::upsert_voice(PpfRuntimeVoice voice, std::string& error) {
    error.clear();
    if (voice.bank_id > std::numeric_limits<std::uint32_t>::max() ||
        voice.source_index > std::numeric_limits<std::uint32_t>::max()) {
        error = "PPF runtime Voice identity exceeds 32-bit key range";
        return false;
    }

    if (voice.zones.empty()) {
        error = "PPF runtime Voice has no resident zones";
        return false;
    }

    for (const auto& z : voice.zones) {
        if (!z.sample || z.sample->pcm.empty()) {
            error = "PPF runtime Voice contains an empty resident zone";
            return false;
        }
        if (z.zone.key_lo < 0 || z.zone.key_hi > 127 || z.zone.key_lo > z.zone.key_hi) {
            error = "PPF runtime Voice contains an invalid note range";
            return false;
        }
        if (z.zone.velocity_lo < 0 || z.zone.velocity_hi > 127 || z.zone.velocity_lo > z.zone.velocity_hi) {
            error = "PPF runtime Voice contains an invalid velocity range";
            return false;
        }
    }

    try {
        voices_[make_key(voice.bank_id, voice.source_index)] = std::move(voice);
    } catch (const std::bad_alloc&) {
        error = "not enough RAM while storing PPF runtime Voice";
        return false;
    }
    return true;
}

bool PpfRuntime::remove_voice(std::size_t bank_id, std::size_t source_index) noexcept {
    return voices_.erase(make_key(bank_id, source_index)) != 0;
}

std::size_t PpfRuntime::remove_bank(std::size_t bank_id) noexcept {
    std::size_t removed = 0;
    for (auto it = voices_.begin(); it != voices_.end();) {
        const std::size_t stored_bank = static_cast<std::size_t>(it->first >> 32);
        if (stored_bank == bank_id) {
            it = voices_.erase(it);
            ++removed;
        } else {
            ++it;
        }
    }
    return removed;
}

const PpfRuntimeVoice* PpfRuntime::find_voice(std::size_t bank_id,
                                              std::size_t source_index) const noexcept {
    const auto it = voices_.find(make_key(bank_id, source_index));
    return it == voices_.end() ? nullptr : &it->second;
}

PpfRuntimeVoice* PpfRuntime::find_voice(std::size_t bank_id,
                                        std::size_t source_index) noexcept {
    const auto it = voices_.find(make_key(bank_id, source_index));
    return it == voices_.end() ? nullptr : &it->second;
}

const PpfRuntimeZone* PpfRuntime::resolve(std::size_t bank_id,
                                          std::size_t source_index,
                                          int note,
                                          int velocity) const noexcept {
    const auto* voice = find_voice(bank_id, source_index);
    return voice ? voice->resolve(note, velocity) : nullptr;
}

std::size_t PpfRuntime::zone_count() const noexcept {
    std::size_t total = 0;
    for (const auto& entry : voices_) total += entry.second.zone_count();
    return total;
}

} // namespace arranger
