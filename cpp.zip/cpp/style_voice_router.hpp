#pragma once
#include "ppf_voice_bank.hpp"
#include "yamaha_style_runtime.hpp"
#include <array>
#include <cstddef>
#include <cstdint>
#include <string>
#include <vector>

namespace arranger {

struct StyleVoiceCall {
    std::uint32_t tick = 0;
    std::uint8_t channel = 0;
    std::uint8_t msb = 0;
    std::uint8_t lsb = 0;
    std::uint8_t program = 0;
};

struct StyleVoiceResolution {
    StyleVoiceCall call{};
    const PpfVoiceDescriptor* voice = nullptr;
    bool exact = false;
    bool alias = false;
};

// C++ port of the baseline Style -> imported Voice address tracker.
// Semantics are deliberately narrow and deterministic:
//   - CC#0 updates MSB
//   - CC#32 updates LSB
//   - Program Change updates PC
//   - resolution is exact MSB+LSB+PC first, then only the already-proven
//     PpfInstalledVoiceBank unambiguous MSB+PC alias rule.
//   - there is NEVER program-only fallback.
class StyleVoiceRouter {
public:
    void reset() noexcept;
    bool scan(const YamahaStyleRuntime& style,
              const PpfInstalledVoiceBank& bank,
              std::vector<StyleVoiceResolution>& out,
              std::string& error) const;

private:
    static bool is_bank_cc(const YamahaStyleMidiEvent& e) noexcept;
    static bool is_program_change(const YamahaStyleMidiEvent& e) noexcept;
    static std::uint8_t channel_for_event(const YamahaStyleRuntime& style,
                                          const YamahaStyleMidiEvent& e) noexcept;
};

} // namespace arranger
