#include "ppf_note_engine.hpp"

#include <algorithm>
#include <cmath>
#include <limits>

namespace arranger {

namespace {
constexpr double kPi = 3.14159265358979323846;
}

void PpfNoteEngine::reset() noexcept {
    for (auto& row : active_slots_) row.fill(-1);
    sustain_down_.fill(false);
}

bool PpfNoteEngine::is_rhythm_part(std::uint8_t part) noexcept {
    return part == static_cast<std::uint8_t>(PpfInstalledVoiceBank::kRhythm1Channel) ||
           part == static_cast<std::uint8_t>(PpfInstalledVoiceBank::kRhythm2Channel);
}

float PpfNoteEngine::zone_gain(const VoiceZone& z) noexcept {
    double g = 1.0;
    if (z.volume < 0.0) g = std::pow(10.0, std::clamp(z.volume, -60.0, 0.0) / 20.0);
    return static_cast<float>(std::clamp(g, 0.0, 1.0));
}

float PpfNoteEngine::zone_pan(const VoiceZone& z) noexcept {
    double p = z.pan;
    if (std::fabs(p) > 1.0) p /= 64.0;
    return static_cast<float>(std::clamp(p, -1.0, 1.0));
}

double PpfNoteEngine::zone_pitch_ratio(const VoiceZone& z, int note) noexcept {
    const double scale = z.fixed_pitch
        ? 0.0
        : std::clamp(static_cast<double>(z.pitch_scaling_sens) / 100.0, 0.0, 1.0);
    const double keyboard_delta = static_cast<double>(note - z.root_note) * scale;
    const double semis = keyboard_delta +
                         static_cast<double>(z.tune_coarse) + z.tune_fine / 100.0 +
                         static_cast<double>(z.element_note_shift) +
                         static_cast<double>(z.element_tune_coarse) +
                         z.element_tune_fine / 100.0;
    const double ratio = std::pow(2.0, semis / 12.0);
    return std::isfinite(ratio) && ratio > 0.0 ? ratio : 1.0;
}

void PpfNoteEngine::clear_slot_mapping(std::size_t slot) noexcept {
    if (slot >= ResidentSampler::kMaxVoices) return;
    for (auto& row : active_slots_) {
        for (auto& mapped : row) {
            if (mapped == static_cast<std::int64_t>(slot)) mapped = -1;
        }
    }
}

void PpfNoteEngine::clear_mappings_for_part(std::size_t part) noexcept {
    if (part >= 16) return;
    active_slots_[part].fill(-1);
}

bool PpfNoteEngine::note_on(const PpfNoteRequest& request) noexcept {
    if (request.part >= 16) return false;
    const auto* runtime_zone = runtime_.resolve(request.bank_id, request.source_index,
                                                static_cast<int>(request.note),
                                                static_cast<int>(request.velocity));
    if (!runtime_zone || !runtime_zone->sample) return true;

    const auto& zone = runtime_zone->zone;
    if (!zone.receive_note_on) return true;

    if (zone.alternate_group != 0u) {
        sampler_.choke_alternate_group(request.part, zone.alternate_group);
        for (auto& mapped : active_slots_[request.part]) {
            if (mapped < 0) continue;
            const auto slot = static_cast<std::size_t>(mapped);
            if (slot < ResidentSampler::kMaxVoices &&
                sampler_.voice_part_index(slot) == request.part &&
                sampler_.voice_alternate_group(slot) == zone.alternate_group) {
                mapped = -1;
            }
        }
    }

    const bool drum = zone.one_shot || is_rhythm_part(request.part);
    const float gain = zone_gain(zone);
    const float pan = zone_pan(zone);
    const double pitch = zone_pitch_ratio(zone, static_cast<int>(request.note));

    const std::size_t slot = sampler_.find_reclaimable_slot();
    if (slot == ResidentSampler::kMaxVoices) return false;

    if (sampler_.voice_active(slot)) clear_slot_mapping(slot);

    if (!sampler_.note_on_at_slot(
            slot, runtime_zone->sample, request.note, request.velocity,
            gain, pan, pitch,
            static_cast<std::size_t>(std::max(0, zone.loop_start_frame)),
            static_cast<std::size_t>(std::max(0, zone.loop_end_frame)),
            !drum && !zone.one_shot,
            request.part,
            zone.alternate_group,
            zone.receive_note_off,
            zone.receive_note_on)) {
        return false;
    }

    active_slots_[request.part][request.note] = static_cast<std::int64_t>(slot);
    return true;
}

bool PpfNoteEngine::note_off(std::uint8_t part, std::uint8_t note) noexcept {
    if (part >= 16) return false;
    auto& mapped = active_slots_[part][note];
    if (mapped < 0) return false;
    const std::size_t slot = static_cast<std::size_t>(mapped);
    if (!sampler_.voice_active(slot) || sampler_.voice_part_index(slot) != part ||
        sampler_.voice_note(slot) != note) {
        mapped = -1;
        return false;
    }

    // A Yamaha rcvNoteOff=0 zone intentionally consumes the event and leaves
    // the voice alive until natural one-shot completion or an alternate-group
    // choke. Do not trigger the generic 50 ms release in this case.
    if (!sampler_.voice_receive_note_off(slot)) return true;

    if (sustain_down_[part] || sampler_.voice_sustain_held(slot)) sampler_.defer_note_off_slot(slot);
    else sampler_.note_off_slot(slot);
    mapped = -1;
    return true;
}

bool PpfNoteEngine::control_change(std::uint8_t part,
                                   std::uint8_t controller,
                                   std::uint8_t value) noexcept {
    if (part >= 16) return false;
    const std::uint8_t v = static_cast<std::uint8_t>(value & 0x7Fu);
    if (controller == 1u) {
        sampler_.set_part_modulation(part, static_cast<float>(v) / 127.0f);
        return true;
    }
    if (controller == 11u) {
        sampler_.set_part_expression(part, static_cast<float>(v) / 127.0f);
        return true;
    }
    if (controller == 64u) {
        const bool sustain = v >= 64u;
        sustain_down_[part] = sustain;
        for (std::size_t slot = 0; slot < ResidentSampler::kMaxVoices; ++slot) {
            if (!sampler_.voice_active(slot) || sampler_.voice_part_index(slot) != part) continue;
            if (sustain) {
                if (!sampler_.voice_key_down(slot)) sampler_.defer_note_off_slot(slot);
            } else if (sampler_.voice_sustain_held(slot)) {
                sampler_.release_sustained_slot(slot);
            }
        }
        return true;
    }
    if (controller == 120u || controller == 123u) {
        for (std::size_t slot = 0; slot < ResidentSampler::kMaxVoices; ++slot) {
            if (sampler_.voice_active(slot) && sampler_.voice_part_index(slot) == part)
                sampler_.note_off_slot(slot);
        }
        clear_mappings_for_part(part);
        return true;
    }
    return false;
}

bool PpfNoteEngine::pitch_bend(std::uint8_t part, std::uint8_t lsb,
                               std::uint8_t msb) noexcept {
    if (part >= 16) return false;
    const int value14 = (static_cast<int>(msb & 0x7Fu) << 7) |
                        static_cast<int>(lsb & 0x7Fu);
    const float norm = static_cast<float>(value14 - 8192) / 8192.0f;
    sampler_.set_part_pitch_bend(part, norm, 2.0f);
    return true;
}

void PpfNoteEngine::all_notes_off(std::size_t part) noexcept {
    if (part >= 16) sampler_.all_notes_off();
    else {
        for (std::size_t slot = 0; slot < ResidentSampler::kMaxVoices; ++slot) {
            if (sampler_.voice_active(slot) && sampler_.voice_part_index(slot) == part)
                sampler_.note_off_slot(slot);
        }
    }
    if (part >= 16) reset();
    else {
        clear_mappings_for_part(part);
        sustain_down_[part] = false;
    }
}

std::int64_t PpfNoteEngine::active_slot(std::uint8_t part, std::uint8_t note) const noexcept {
    if (part >= 16) return -1;
    const auto slot = active_slots_[part][note];
    if (slot < 0) return -1;
    const auto index = static_cast<std::size_t>(slot);
    if (index >= ResidentSampler::kMaxVoices || !sampler_.voice_active(index) ||
        sampler_.voice_part_index(index) != part || sampler_.voice_note(index) != note) return -1;
    return slot;
}

std::size_t PpfNoteEngine::active_note_count() const noexcept {
    std::size_t count = 0;
    for (const auto& row : active_slots_) {
        for (const auto slot : row) {
            if (slot < 0) continue;
            const auto index = static_cast<std::size_t>(slot);
            if (index < ResidentSampler::kMaxVoices && sampler_.voice_active(index)) ++count;
        }
    }
    return count;
}

} // namespace arranger
