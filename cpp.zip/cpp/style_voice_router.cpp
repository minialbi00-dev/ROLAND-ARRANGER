#include "style_voice_router.hpp"

#include <algorithm>
#include <array>

namespace arranger {

void StyleVoiceRouter::reset() noexcept {}

bool StyleVoiceRouter::is_bank_cc(const YamahaStyleMidiEvent& e) noexcept {
    if ((e.status & 0xF0u) != 0xB0u) return false;
    return e.data_len >= 2 && (e.data1 == 0u || e.data1 == 32u);
}

bool StyleVoiceRouter::is_program_change(const YamahaStyleMidiEvent& e) noexcept {
    return (e.status & 0xF0u) == 0xC0u && e.data_len >= 1;
}

std::uint8_t StyleVoiceRouter::channel_for_event(const YamahaStyleRuntime& style,
                                                 const YamahaStyleMidiEvent& e) noexcept {
    const std::uint8_t src = static_cast<std::uint8_t>(e.status & 0x0Fu);
    if (src >= 16u) return src;

    // Preserve the existing Yamaha/CASM rule: the style source channel is
    // mapped to the destination part when an explicit CASM rule exists.
    // Voice setup follows that logical part so Style -> Voice resolution uses
    // the same channel identity as subsequent NOTE events.
    for (const auto& section : style.sections()) {
        if (e.tick < section.start_tick || e.tick >= section.end_tick) continue;
        if (const auto* rule = style.find_casm_rule(section.name, src)) {
            if (rule->explicit_casm) return static_cast<std::uint8_t>(rule->destination_channel & 0x0Fu);
        }
        break;
    }

    if (const auto* full = style.find_casm_rule("FULL STYLE", src)) {
        if (full->explicit_casm) return static_cast<std::uint8_t>(full->destination_channel & 0x0Fu);
    }
    return src;
}

bool StyleVoiceRouter::scan(const YamahaStyleRuntime& style,
                            const PpfInstalledVoiceBank& bank,
                            std::vector<StyleVoiceResolution>& out,
                            std::string& error) const {
    out.clear();
    error.clear();

    std::array<std::uint8_t, 16> msb{};
    std::array<std::uint8_t, 16> lsb{};
    std::array<std::uint8_t, 16> program{};
    std::array<bool, 16> program_set{};

    for (const auto& e : style.events()) {
        const std::uint8_t source_ch = static_cast<std::uint8_t>(e.status & 0x0Fu);
        if (source_ch >= 16u) continue;
        const std::uint8_t logical_ch = channel_for_event(style, e);

        bool should_resolve = false;
        if (is_bank_cc(e)) {
            if (e.data1 == 0u) msb[logical_ch] = static_cast<std::uint8_t>(e.data2 & 0x7Fu);
            else lsb[logical_ch] = static_cast<std::uint8_t>(e.data2 & 0x7Fu);
            // A Bank Select change is meaningful only after that same logical
            // part already has a Program Change. Do not use another channel's PC.
            should_resolve = program_set[logical_ch];
        } else if (is_program_change(e)) {
            program[logical_ch] = static_cast<std::uint8_t>(e.data1 & 0x7Fu);
            program_set[logical_ch] = true;
            should_resolve = true;
        }

        if (!should_resolve) continue;

        StyleVoiceResolution r;
        r.call.tick = e.tick;
        r.call.channel = logical_ch;
        r.call.msb = msb[logical_ch];
        r.call.lsb = lsb[logical_ch];
        r.call.program = program[logical_ch];
        r.voice = bank.resolve(logical_ch, r.call.msb, r.call.lsb, r.call.program);
        if (r.voice != nullptr) {
            r.exact = (r.voice->msb == r.call.msb &&
                       r.voice->lsb == r.call.lsb &&
                       r.voice->program == r.call.program);
            r.alias = !r.exact;
        }
        out.push_back(r);
    }

    if (out.empty()) {
        error = "Style contains no Bank Select / Program Change sequence";
        return false;
    }
    return true;
}

} // namespace arranger
