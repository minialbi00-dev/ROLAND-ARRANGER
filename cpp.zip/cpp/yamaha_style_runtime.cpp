#include "yamaha_style_runtime.hpp"

#include <algorithm>
#include <cmath>
#include <fstream>
#include <iterator>
#include <limits>
#include <utility>

namespace arranger {

namespace {

constexpr const char* kAliases[][2] = {
    {"MAIN A", "MAIN A"}, {"MAIN B", "MAIN B"}, {"MAIN C", "MAIN C"}, {"MAIN D", "MAIN D"},
    {"MAINA", "MAIN A"}, {"MAINB", "MAIN B"}, {"MAINC", "MAIN C"}, {"MAIND", "MAIN D"},
    {"INTRO A", "INTRO A"}, {"INTRO B", "INTRO B"}, {"INTRO C", "INTRO C"},
    {"INTROA", "INTRO A"}, {"INTROB", "INTRO B"}, {"INTROC", "INTRO C"},
    {"ENDING A", "ENDING A"}, {"ENDING B", "ENDING B"}, {"ENDING C", "ENDING C"},
    {"ENDINGA", "ENDING A"}, {"ENDINGB", "ENDING B"}, {"ENDINGC", "ENDING C"},
    {"FILL IN AA", "FILL AA"}, {"FILL IN BB", "FILL BB"}, {"FILL IN CC", "FILL CC"},
    {"FILL IN DD", "FILL DD"}, {"FILL AA", "FILL AA"}, {"FILL BB", "FILL BB"},
    {"FILL CC", "FILL CC"}, {"FILL DD", "FILL DD"},
    {"FILL IN BA", "BREAK"}, {"FILL BA", "BREAK"}, {"BREAK", "BREAK"},
};

std::string upper_trim(std::string s) {
    while (!s.empty() && (s.back() == '\0' || s.back() == ' ' || s.back() == '\t' || s.back() == '\r' || s.back() == '\n')) s.pop_back();
    std::size_t first = 0;
    while (first < s.size() && (s[first] == ' ' || s[first] == '\t' || s[first] == '\r' || s[first] == '\n')) ++first;
    s.erase(0, first);
    for (char& c : s) {
        if (c == '_' || c == '-') c = ' ';
        if (c >= 'a' && c <= 'z') c = static_cast<char>(c - 'a' + 'A');
    }
    return s;
}


} // namespace

std::uint16_t YamahaStyleRuntime::read_be16(const std::vector<std::uint8_t>& data, std::size_t pos) noexcept {
    if (pos + 2 > data.size()) return 0;
    return static_cast<std::uint16_t>((static_cast<std::uint16_t>(data[pos]) << 8) | data[pos + 1]);
}

std::uint32_t YamahaStyleRuntime::read_be32(const std::vector<std::uint8_t>& data, std::size_t pos) noexcept {
    if (pos + 4 > data.size()) return 0;
    return (static_cast<std::uint32_t>(data[pos]) << 24) |
           (static_cast<std::uint32_t>(data[pos + 1]) << 16) |
           (static_cast<std::uint32_t>(data[pos + 2]) << 8) |
           static_cast<std::uint32_t>(data[pos + 3]);
}

bool YamahaStyleRuntime::read_vlq(const std::vector<std::uint8_t>& data,
                                  std::size_t& pos,
                                  std::size_t end,
                                  std::uint32_t& value) noexcept {
    value = 0;
    for (int i = 0; i < 5; ++i) {
        if (pos >= end) return false;
        const std::uint8_t b = data[pos++];
        if (value > 0x0FFFFFFFu) return false;
        value = (value << 7) | (b & 0x7Fu);
        if ((b & 0x80u) == 0) return true;
    }
    return false;
}

std::string YamahaStyleRuntime::normalize_section(const std::string& name) {
    const std::string up = upper_trim(name);
    for (const auto& a : kAliases) {
        if (up == a[0]) return a[1];
    }
    if (up.rfind("FILL IN ", 0) == 0) return "FILL " + up.substr(8);
    return up;
}

std::string YamahaStyleRuntime::rule_key(const std::string& section,
                                         std::uint8_t source_channel) {
    return normalize_section(section) + ":" + std::to_string(source_channel & 0x0F);
}

std::uint8_t YamahaStyleRuntime::clamp_note(int note) noexcept {
    return static_cast<std::uint8_t>(std::clamp(note, 0, 127));
}

void YamahaStyleRuntime::clear() noexcept {
    path_.clear();
    summary_ = YamahaStyleSummary{};
    events_.clear();
    sections_.clear();
    casm_rules_.clear();
}

bool YamahaStyleRuntime::load(const std::string& path, std::string& error) {
    clear();
    std::ifstream f(path, std::ios::binary);
    if (!f) { error = "Cannot open Yamaha Style file"; return false; }
    const std::vector<std::uint8_t> raw((std::istreambuf_iterator<char>(f)), std::istreambuf_iterator<char>());
    if (raw.size() < 14 || !(raw[0] == 'M' && raw[1] == 'T' && raw[2] == 'h' && raw[3] == 'd')) {
        error = "Style is not an SMF/Yamaha container (missing MThd)";
        return false;
    }
    path_ = path;
    std::size_t smf_end = 0;
    if (!parse_smf(raw, smf_end, error)) return false;
    parse_casm(raw, smf_end);
    summary_.section_count = sections_.size();
    summary_.total_events = events_.size();
    summary_.casm_rule_count = casm_rules_.size();
    std::unordered_map<std::string, bool> casm_sections;
    for (const auto& kv : casm_rules_) {
        const auto p = kv.first.find(':');
        if (p != std::string::npos) casm_sections.emplace(kv.first.substr(0, p), true);
    }
    summary_.casm_section_count = casm_sections.size();
    summary_.has_casm = !casm_rules_.empty();
    return true;
}

bool YamahaStyleRuntime::parse_smf(const std::vector<std::uint8_t>& raw,
                                   std::size_t& smf_end,
                                   std::string& error) {
    const std::uint32_t header_len = read_be32(raw, 4);
    if (header_len < 6 || 8ull + header_len > raw.size()) { error = "Invalid MThd length"; return false; }
    summary_.format_type = read_be16(raw, 8);
    summary_.tracks = read_be16(raw, 10);
    summary_.division = read_be16(raw, 12);
    if (summary_.format_type > 1) { error = "Unsupported MIDI format (only 0/1)"; return false; }
    if (summary_.division & 0x8000u) { error = "SMPTE timing is unsupported"; return false; }

    std::size_t pos = 8 + header_len;
    std::vector<std::pair<std::uint32_t, std::string>> conductor_markers;
    std::uint32_t max_tick = 0;
    std::unordered_map<std::uint16_t, std::string> track_names;

    for (std::uint16_t ti = 0; ti < summary_.tracks; ++ti) {
        if (pos + 8 > raw.size() || raw[pos] != 'M' || raw[pos + 1] != 'T' || raw[pos + 2] != 'r' || raw[pos + 3] != 'k') {
            error = "Missing MTrk " + std::to_string(ti); return false;
        }
        const std::uint32_t length = read_be32(raw, pos + 4);
        const std::size_t start = pos + 8;
        if (start + length > raw.size()) { error = "MTrk extends beyond file"; return false; }
        std::vector<std::pair<std::uint32_t, std::string>> markers;
        std::string track_name;
        if (!parse_track(raw, start, length, ti, markers, track_name, error)) return false;
        if (ti == 0) conductor_markers = markers;
        if (!track_name.empty()) track_names.emplace(ti, track_name);
        for (const auto& e : events_) max_tick = std::max(max_tick, e.tick);
        pos = start + length;
    }
    if (events_.empty()) { error = "No MIDI events found"; return false; }

    // Tempo/time signature are extracted directly from the raw SMF metadata.
    // data1 is meta type; data2 is first payload byte. The remaining 2 payload bytes are not kept,
    // so use the raw SMF event scan for those two global values.
    std::size_t scan = 8 + header_len;
    while (scan + 8 <= raw.size() && scan < pos) {
        if (raw[scan] != 'M' || raw[scan+1] != 'T' || raw[scan+2] != 'r' || raw[scan+3] != 'k') break;
        const std::size_t start = scan + 8;
        const std::uint32_t len = read_be32(raw, scan + 4);
        const std::size_t end = start + len;
        std::size_t q = start; std::uint32_t tick = 0; std::uint8_t running = 0;
        while (q < end) {
            std::uint32_t delta = 0; if (!read_vlq(raw, q, end, delta)) break; tick += delta;
            if (q >= end) break;
            std::uint8_t status = raw[q];
            if (status < 0x80) { if (!running) break; status = running; }
            else { ++q; if (status < 0xF0) running = status; }
            if (status == 0xFF) {
                if (q >= end) break;
                const std::uint8_t mt = raw[q++];
                std::uint32_t n = 0;
                if (!read_vlq(raw,q,end,n) || q+n>end) break;
                if (mt == 0x51 && n == 3) { const std::uint32_t us=(static_cast<std::uint32_t>(raw[q])<<16)|(static_cast<std::uint32_t>(raw[q+1])<<8)|raw[q+2]; if (us) summary_.tempo_bpm = 60000000.0/static_cast<double>(us); }
                if (mt == 0x58 && n >= 2) { summary_.time_numerator=raw[q]; const std::uint8_t dd=raw[q+1]; summary_.time_denominator=static_cast<std::uint8_t>(1u<<std::min<std::uint8_t>(dd, 6)); }
                q += n; if (mt == 0x2F) break; continue;
            }
            if (status == 0xF0 || status == 0xF7) { std::uint32_t n=0; if (!read_vlq(raw,q,end,n)||q+n>end) break; q+=n; continue; }
            const std::uint8_t cmd = status & 0xF0u; const std::size_t n = (cmd == 0xC0 || cmd == 0xD0) ? 1 : 2; if (q+n>end) break; q+=n;
        }
        scan = end;
    }

    build_sections(conductor_markers, max_tick);
    smf_end = pos;
    return true;
}

bool YamahaStyleRuntime::parse_track(const std::vector<std::uint8_t>& raw,
                                     std::size_t start,
                                     std::size_t size,
                                     std::uint16_t track_index,
                                     std::vector<std::pair<std::uint32_t, std::string>>& markers,
                                     std::string& track_name,
                                     std::string& error) {
    const std::size_t end = start + size;
    std::size_t pos = start;
    std::uint32_t tick = 0;
    std::uint8_t running = 0;
    while (pos < end) {
        std::uint32_t delta = 0;
        if (!read_vlq(raw, pos, end, delta)) { error = "Invalid MIDI VLQ"; return false; }
        tick += delta;
        if (pos >= end) break;
        std::uint8_t status = raw[pos];
        if (status < 0x80) { if (!running) { error = "Invalid running status"; return false; } status = running; }
        else { ++pos; if (status < 0xF0) running = status; }

        if (status == 0xFF) {
            if (pos >= end) break;
            const std::uint8_t mt = raw[pos++];
            std::uint32_t n = 0; if (!read_vlq(raw, pos, end, n) || pos+n > end) { error = "Invalid MIDI meta event"; return false; }
            if (mt == 0x03) track_name.assign(reinterpret_cast<const char*>(raw.data()+pos), reinterpret_cast<const char*>(raw.data()+pos+n));
            if (mt == 0x06) markers.emplace_back(tick, std::string(reinterpret_cast<const char*>(raw.data()+pos), reinterpret_cast<const char*>(raw.data()+pos+n)));
            if (mt == 0x2F) { pos += n; break; }
            pos += n;
            continue;
        }
        if (status == 0xF0 || status == 0xF7) {
            std::uint32_t n = 0; if (!read_vlq(raw,pos,end,n)||pos+n>end) { error="Invalid sysex length"; return false; }
            pos += n; continue;
        }
        const std::uint8_t cmd = status & 0xF0u;
        const std::size_t data_len = (cmd == 0xC0 || cmd == 0xD0) ? 1 : 2;
        if (pos + data_len > end) { error = "MIDI event exceeds track boundary"; return false; }
        YamahaStyleMidiEvent e{};
        e.tick=tick; e.status=status; e.data_len=static_cast<std::uint8_t>(data_len); e.track=track_index; e.data1=raw[pos]; e.data2=(data_len>1?raw[pos+1]:0);
        events_.push_back(e);
        pos += data_len;
    }
    return true;
}

void YamahaStyleRuntime::build_sections(const std::vector<std::pair<std::uint32_t, std::string>>& markers,
                                        std::uint32_t max_tick) {
    std::vector<std::pair<std::uint32_t, std::string>> normalized;
    for (const auto& m : markers) {
        const std::string n = normalize_section(m.second);
        if (!n.empty()) normalized.emplace_back(m.first, n);
    }
    std::sort(normalized.begin(), normalized.end());
    if (normalized.empty()) {
        sections_.push_back(YamahaStyleSection{"FULL STYLE",0,max_tick,{}});
        for (const auto& e : events_) if (e.status < 0xF0) sections_.back().events.push_back(e);
        std::stable_sort(sections_.back().events.begin(), sections_.back().events.end(),
            [](const YamahaStyleMidiEvent& a, const YamahaStyleMidiEvent& b) {
                if (a.tick != b.tick) return a.tick < b.tick;
                return a.track < b.track;
            });
        return;
    }
    for (std::size_t i=0;i<normalized.size();++i) {
        YamahaStyleSection s;
        s.name=normalized[i].second; s.start_tick=normalized[i].first; s.end_tick=(i+1<normalized.size()?normalized[i+1].first:max_tick);
        if (s.end_tick <= s.start_tick) continue;
        for (const auto& e : events_) if (e.status < 0xF0 && e.tick >= s.start_tick && e.tick < s.end_tick) s.events.push_back(e);
        std::stable_sort(s.events.begin(), s.events.end(),
            [](const YamahaStyleMidiEvent& a, const YamahaStyleMidiEvent& b) {
                if (a.tick != b.tick) return a.tick < b.tick;
                return a.track < b.track;
            });
        sections_.push_back(std::move(s));
    }
}

void YamahaStyleRuntime::parse_casm(const std::vector<std::uint8_t>& raw, std::size_t smf_end) {
    std::size_t pos = smf_end;
    while (pos + 8 <= raw.size()) {
        const std::string id(reinterpret_cast<const char*>(raw.data()+pos), 4);
        const std::uint32_t n = read_be32(raw, pos+4);
        if (pos + 8ull + n > raw.size()) break;
        if (id == "CASM") {
            std::vector<std::uint8_t> payload(raw.begin()+static_cast<std::ptrdiff_t>(pos+8), raw.begin()+static_cast<std::ptrdiff_t>(pos+8+n));
            parse_casm_payload(payload, casm_rules_);
        }
        pos += 8u + n;
    }
}

void YamahaStyleRuntime::parse_casm_payload(const std::vector<std::uint8_t>& payload,
                                            std::unordered_map<std::string, YamahaStyleCasmRule>& out) {
    std::size_t q=0;
    while (q+8<=payload.size()) {
        const std::string tag(reinterpret_cast<const char*>(payload.data()+q),4);
        const std::uint32_t n=read_be32(payload,q+4);
        if (q+8ull+n>payload.size()) break;
        if (tag=="CSEG") {
            const std::size_t bs=q+8, be=bs+n; std::string sdec;
            std::vector<YamahaStyleCasmRule> tables;
            std::size_t r=bs;
            while (r+8<=be) {
                const std::string t(reinterpret_cast<const char*>(payload.data()+r),4); const std::uint32_t m=read_be32(payload,r+4);
                if (r+8ull+m>be) break;
                if (t=="Sdec") sdec.assign(reinterpret_cast<const char*>(payload.data()+r+8), reinterpret_cast<const char*>(payload.data()+r+8+m));
                if (t=="Ctb2" || t=="Ctab") {
                    const std::size_t o=r+8;
                    YamahaStyleCasmRule rule{};
                    rule.explicit_casm=true;
                    rule.source_channel = m>0 ? payload[o]&0x0F : 0;
                    if (m>=10) { rule.destination_channel=payload[o+9]&0x0F; rule.role.assign(reinterpret_cast<const char*>(payload.data()+o+1), reinterpret_cast<const char*>(payload.data()+o+9)); }
                    if (m>=20) { rule.source_root=payload[o+18]&0x7F; rule.source_type=payload[o+19]&0x7F; }
                    if (m>=47) {
                        for (std::size_t base : {22u,28u,34u}) if (base+5<m) {
                            YamahaStyleCasmSlot s{}; s.ntr=payload[o+base]&0x7F; s.ntt=payload[o+base+1]&0x7F; s.high_key=payload[o+base+2]&0x7F; s.note_lo=payload[o+base+3]&0x7F; s.note_hi=payload[o+base+4]&0x7F; s.rtr=payload[o+base+5]&0x7F; rule.slots.push_back(s);
                        }
                    } else if (m>=12) {
                        YamahaStyleCasmSlot s{}; s.ntr=payload[o+10]&0x7F; s.ntt=payload[o+11]&0x7F; rule.slots.push_back(s);
                    }
                    if (rule.slots.empty()) rule.slots.push_back(YamahaStyleCasmSlot{});
                    tables.push_back(std::move(rule));
                }
                r += 8u+m;
            }
            std::size_t b=0;
            while (b<sdec.size()) {
                std::size_t e=sdec.find(',',b); if (e==std::string::npos) e=sdec.size();
                const std::string sec=normalize_section(sdec.substr(b,e-b));
                for (const auto& rule : tables) out[rule_key(sec,rule.source_channel)] = rule;
                b=e+1; if(e==sdec.size()) break;
            }
        }
        q += 8u+n;
    }
}

const YamahaStyleSection* YamahaStyleRuntime::find_section(const std::string& name) const noexcept {
    const std::string n=normalize_section(name);
    for (const auto& s: sections_) if (normalize_section(s.name)==n) return &s;
    return nullptr;
}

const YamahaStyleCasmRule* YamahaStyleRuntime::find_casm_rule(const std::string& section,
                                                              std::uint8_t source_channel) const noexcept {
    const auto it=casm_rules_.find(rule_key(section,source_channel));
    return it==casm_rules_.end()?nullptr:&it->second;
}

int YamahaStyleRuntime::major_map(int rel) noexcept { static constexpr int a[12]={0,0,2,4,4,5,7,7,7,9,0,0}; return a[rel%12]; }
int YamahaStyleRuntime::minor_map(int rel) noexcept { static constexpr int a[12]={0,0,2,3,3,5,7,7,8,7,0,0}; return a[rel%12]; }
int YamahaStyleRuntime::dom7_map(int rel) noexcept { static constexpr int a[12]={0,0,2,4,4,5,7,7,7,9,10,10}; return a[rel%12]; }
int YamahaStyleRuntime::maj7_map(int rel) noexcept { static constexpr int a[12]={0,0,2,4,4,5,7,7,7,9,11,11}; return a[rel%12]; }
int YamahaStyleRuntime::min7_map(int rel) noexcept { static constexpr int a[12]={0,0,2,3,3,5,7,7,8,10,10,10}; return a[rel%12]; }
int YamahaStyleRuntime::dim_map(int rel) noexcept { static constexpr int a[12]={0,0,2,3,3,5,6,6,8,9,0,0}; return a[rel%12]; }
int YamahaStyleRuntime::aug_map(int rel) noexcept { static constexpr int a[12]={0,0,2,4,4,6,6,8,8,10,10,0}; return a[rel%12]; }

bool YamahaStyleRuntime::transform_note(const std::string& section,
                                         std::uint8_t source_channel,
                                         std::uint8_t input_note,
                                         std::uint8_t chord_root_pc,
                                         std::uint8_t chord_type,
                                         std::uint8_t chord_bass_pc,
                                         bool chord_bass_valid,
                                         std::uint8_t& output_note,
                                         std::uint8_t& destination_channel) const noexcept {
    const auto* rule = find_casm_rule(section, source_channel);
    if (!rule) return false;
    return transform_note_with_rule(*rule, input_note, chord_root_pc, chord_type, chord_bass_pc, chord_bass_valid, output_note, destination_channel);
}

bool YamahaStyleRuntime::transform_note_with_rule(const YamahaStyleCasmRule& rule,
                                                  std::uint8_t input_note,
                                                  std::uint8_t chord_root_pc,
                                                  std::uint8_t chord_type,
                                                  std::uint8_t chord_bass_pc,
                                                  bool chord_bass_valid,
                                                  std::uint8_t& output_note,
                                                  std::uint8_t& destination_channel) noexcept {
    destination_channel = rule.destination_channel & 0x0F;
    if (rule.slots.empty()) { output_note = input_note; return true; }
    std::size_t idx = 0;
    if (chord_type == 1 || chord_type == 4 || chord_type == 5) idx = 1;
    else if (chord_type == 2 || chord_type == 3) idx = 2;
    if (idx >= rule.slots.size()) idx = 0;
    const auto* slot = &rule.slots[idx];
    if (slot->ntr == 0 && slot->ntt == 0) slot = &rule.slots[0];
    int note = static_cast<int>(input_note);
    const int source_root = rule.source_root % 12;
    const std::string role = upper_trim(rule.role);
    const bool is_bass_role = role.find("BASS") != std::string::npos;
    const std::uint8_t effective_root_pc =
        (is_bass_role && chord_bass_valid) ? static_cast<std::uint8_t>(chord_bass_pc % 12u) : chord_root_pc;
    int shift = 0;
    if (slot->ntr != 2) {
        shift = static_cast<int>(effective_root_pc % 12) - source_root;
        if (shift > 6) shift -= 12;
        else if (shift < -5) shift += 12;
    }
    int new_note = note + shift;
    if (slot->ntt > 0 || slot->ntr == 2) {
        const int rel0 = ((new_note - static_cast<int>(effective_root_pc) + 120) % 12);
        const int octave = new_note - rel0;
        const bool tight = (slot->ntt == 2);
        int mapped = rel0;
        switch (chord_type) {
            case 0: mapped = tight ? (rel0==0||rel0==1||rel0==2||rel0==10||rel0==11 ? 0 : (rel0==3||rel0==4||rel0==5 ? 4 : 7)) : major_map(rel0); break;
            case 1: mapped = tight ? (rel0==0||rel0==1||rel0==10||rel0==11 ? 0 : (rel0==2||rel0==3||rel0==4 ? 3 : 7)) : minor_map(rel0); break;
            case 2: mapped = tight ? (rel0==0||rel0==1||rel0==2 ? 0 : (rel0==3||rel0==4||rel0==5 ? 4 : (rel0==6||rel0==7||rel0==8 ? 7 : 10))) : dom7_map(rel0); break;
            case 3: mapped = tight ? (rel0==0||rel0==1||rel0==2 ? 0 : (rel0==3||rel0==4||rel0==5 ? 4 : (rel0==6||rel0==7||rel0==8 ? 7 : 11))) : maj7_map(rel0); break;
            case 4: mapped = tight ? (rel0==0||rel0==1 ? 0 : (rel0==2||rel0==3||rel0==4 ? 3 : (rel0==5||rel0==6||rel0==7 ? 7 : 10))) : min7_map(rel0); break;
            case 5: mapped = tight ? (rel0==0||rel0==1||rel0>=9 ? 0 : (rel0==2||rel0==3||rel0==4 ? 3 : 6)) : dim_map(rel0); break;
            case 6: mapped = tight ? (rel0==0||rel0==1||rel0==2||rel0==10||rel0==11 ? 0 : (rel0==3||rel0==4||rel0==5 ? 4 : 8)) : aug_map(rel0); break;
            default: mapped = major_map(rel0); break;
        }
        new_note = octave + mapped;
    }
    int lo = slot->note_lo, hi = slot->note_hi;
    if (hi == 0 || hi <= lo) { lo = 0; hi = 127; }
    if (hi < 127 || lo > 0) {
        int failsafe = 10;
        while (new_note < lo && failsafe-- > 0) new_note += 12;
        failsafe = 10;
        while (new_note > hi && failsafe-- > 0) new_note -= 12;
    }
    output_note = clamp_note(new_note);
    return true;
}

} // namespace arranger
