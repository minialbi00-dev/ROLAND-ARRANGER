#include "ppf_audio_bridge.h"
#include "native_gui_ppf_audio.hpp"

#include <algorithm>
#include <cstring>
#include <memory>
#include <new>
#include <cstdio>
#include <string>

namespace {
using arranger::InstalledVoiceAddress;
using arranger::NativeGuiPpfAudio;
using arranger::NativeGuiAudioMetrics;
using arranger::StyleVoiceCall;

void set_error(char* dst, size_t cap, const std::string& message) noexcept {
    if (!dst || cap == 0) return;
    const size_t n = std::min(cap - 1u, message.size());
    std::memcpy(dst, message.data(), n);
    dst[n] = '\0';
}

struct Bridge {
    NativeGuiPpfAudio audio;
};

Bridge* as_bridge(void* handle) noexcept {
    return static_cast<Bridge*>(handle);
}

} // namespace

extern "C" {

void* YPA_CALL ypa_create(char* error_buf, size_t error_cap) {
    try {
        auto* b = new Bridge();
        if (error_buf && error_cap) error_buf[0] = '\0';
        return b;
    } catch (const std::bad_alloc&) {
        set_error(error_buf, error_cap, "not enough memory creating PPF audio engine");
        return nullptr;
    } catch (...) {
        set_error(error_buf, error_cap, "unknown error creating PPF audio engine");
        return nullptr;
    }
}

void YPA_CALL ypa_destroy(void* handle) {
    delete as_bridge(handle);
}

int YPA_CALL ypa_load_soundfont(void* handle, const char* sf2_path,
                                char* error_buf, size_t error_cap) {
    if (!handle) { set_error(error_buf, error_cap, "null PPF audio handle"); return 0; }
    if (!sf2_path || !*sf2_path) { set_error(error_buf, error_cap, "SoundFont path is empty"); return 0; }
    std::string err;
    const bool ok = as_bridge(handle)->audio.load_soundfont(sf2_path, err);
    if (!ok) set_error(error_buf, error_cap, err);
    else if (error_buf && error_cap) error_buf[0] = '\0';
    return ok ? 1 : 0;
}

int YPA_CALL ypa_has_soundfont(void* handle) {
    if (!handle) return 0;
    return as_bridge(handle)->audio.metrics().soundfont_loaded ? 1 : 0;
}

int YPA_CALL ypa_install_ppf(void* handle,
                             const char* ppf_path,
                             uint8_t installed_msb,
                             uint8_t installed_lsb,
                             char* error_buf,
                             size_t error_cap) {
    if (!handle) { set_error(error_buf, error_cap, "null PPF audio handle"); return 0; }
    if (!ppf_path || !*ppf_path) { set_error(error_buf, error_cap, "PPF path is empty"); return 0; }
    std::string err;
    const bool ok = as_bridge(handle)->audio.install_ppf_bank_audio_only(
        ppf_path, InstalledVoiceAddress{installed_msb, installed_lsb, 0}, err);
    if (!ok) set_error(error_buf, error_cap, err);
    else if (error_buf && error_cap) error_buf[0] = '\0';
    return ok ? 1 : 0;
}

int YPA_CALL ypa_preload_voice(void* handle,
                               uint8_t msb,
                               uint8_t lsb,
                               uint8_t program,
                               char* error_buf,
                               size_t error_cap) {
    if (!handle) { set_error(error_buf, error_cap, "null PPF audio handle"); return -1; }
    StyleVoiceCall call{};
    call.channel = 0;
    call.msb = msb;
    call.lsb = lsb;
    call.program = program;
    std::string err;
    const int rc = as_bridge(handle)->audio.preload_style_voice(call, err);
    if (rc < 0) set_error(error_buf, error_cap, err);
    else if (error_buf && error_cap) error_buf[0] = '\0';
    return rc;
}

int YPA_CALL ypa_uninstall_ppf(void* handle,
                               uint64_t bank_id,
                               char* error_buf,
                               size_t error_cap) {
    if (!handle) { set_error(error_buf, error_cap, "null PPF audio handle"); return 0; }
    std::string err;
    const bool ok = as_bridge(handle)->audio.uninstall_ppf_bank(static_cast<std::size_t>(bank_id), err);
    if (!ok) set_error(error_buf, error_cap, err);
    else if (error_buf && error_cap) error_buf[0] = '\0';
    return ok ? 1 : 0;
}

size_t YPA_CALL ypa_get_ppf_bank_count(void* handle) {
    if (!handle) return 0;
    return as_bridge(handle)->audio.installed_ppf_banks().size();
}

int YPA_CALL ypa_get_ppf_bank_info(void* handle,
                                   size_t index,
                                   YpaPpfBankInfo* out_info) {
    if (!out_info) return 0;
    *out_info = {};
    if (!handle) return 0;
    const auto banks = as_bridge(handle)->audio.installed_ppf_banks();
    if (index >= banks.size()) return 0;
    const auto& b = banks[index];
    out_info->bank_id = static_cast<uint64_t>(b.bank_id);
    out_info->installed_msb = b.msb;
    out_info->installed_lsb = b.lsb;
    out_info->voice_count = static_cast<uint32_t>(b.voice_count);
    return 1;
}

size_t YPA_CALL ypa_get_ppf_voice_count(void* handle) {
    if (!handle) return 0;
    return as_bridge(handle)->audio.installed_ppf_voices().size();
}

int YPA_CALL ypa_get_ppf_voice_info(void* handle,
                                    size_t index,
                                    YpaPpfVoiceInfo* out_info) {
    if (!out_info) return 0;
    *out_info = {};
    if (!handle) return 0;
    const auto voices = as_bridge(handle)->audio.installed_ppf_voices();
    if (index >= voices.size()) return 0;
    const auto& v = voices[index];
    out_info->bank_id = static_cast<uint64_t>(v.bank_id);
    out_info->source_index = static_cast<uint64_t>(v.source_index);
    out_info->source_msb = v.source_address.msb;
    out_info->source_lsb = v.source_address.lsb;
    out_info->source_program = v.source_address.program;
    out_info->installed_msb = v.installed_address.msb;
    out_info->installed_lsb = v.installed_address.lsb;
    out_info->installed_program = v.installed_address.program;
    out_info->source_address_valid = v.source_address_valid ? 1u : 0u;
    out_info->installed_address_valid = v.installed_address_valid ? 1u : 0u;
    out_info->zone_count = static_cast<uint32_t>(v.zone_count);
    out_info->resident_zone_count = static_cast<uint32_t>(v.resident_zone_count);
    std::snprintf(out_info->title, sizeof(out_info->title), "%s", v.title.c_str());
    std::snprintf(out_info->source_path, sizeof(out_info->source_path), "%s", v.source_path.c_str());
    std::snprintf(out_info->voice_type, sizeof(out_info->voice_type), "%s", v.voice_type.c_str());
    return 1;
}

int YPA_CALL ypa_start(void* handle,
                       double bpm,
                       uint16_t division,
                       char* error_buf,
                       size_t error_cap) {
    if (!handle) { set_error(error_buf, error_cap, "null PPF audio handle"); return 0; }
    std::string err;
    const bool ok = as_bridge(handle)->audio.start(bpm, division, err);
    if (!ok) set_error(error_buf, error_cap, err);
    else if (error_buf && error_cap) error_buf[0] = '\0';
    return ok ? 1 : 0;
}

void YPA_CALL ypa_stop(void* handle) {
    if (handle) as_bridge(handle)->audio.stop();
}

int YPA_CALL ypa_active(void* handle) {
    return handle && as_bridge(handle)->audio.is_active() ? 1 : 0;
}

int YPA_CALL ypa_set_timing(void* handle, double bpm, uint16_t division) {
    if (!handle) return 0;
    as_bridge(handle)->audio.set_timing(bpm, division);
    return 1;
}

void YPA_CALL ypa_reanchor(void* handle, uint32_t tick) {
    if (handle) as_bridge(handle)->audio.reanchor(tick);
}

int YPA_CALL ypa_enqueue_midi(void* handle,
                              uint32_t tick,
                              uint8_t status,
                              uint8_t data1,
                              uint8_t data2) {
    if (!handle) return 0;
    arranger::ArrangerOutputEvent event{};
    event.global_tick = tick;
    event.status = status;
    event.data1 = data1;
    event.data2 = data2;
    return as_bridge(handle)->audio.enqueue(event) ? 1 : 0;
}

void YPA_CALL ypa_get_stats(void* handle, YpaAudioStats* out_stats) {
    if (!out_stats) return;
    *out_stats = {};
    if (!handle) return;
    const NativeGuiAudioMetrics m = as_bridge(handle)->audio.metrics();
    out_stats->output_rate = static_cast<uint32_t>(m.output_rate);
    out_stats->buffer_frames = static_cast<uint32_t>(m.buffer_frames);
    out_stats->ppf_voices = static_cast<uint32_t>(m.ppf_voice_count);
    out_stats->ppf_banks = static_cast<uint32_t>(m.ppf_bank_count);
    out_stats->resident_zones = static_cast<uint32_t>(m.resident_zone_count);
    out_stats->unique_pcm = static_cast<uint32_t>(m.unique_pcm_count);
    out_stats->resident_pcm_bytes = static_cast<uint64_t>(m.resident_pcm_bytes);
    out_stats->active_voices = static_cast<uint32_t>(m.active_voices);
    out_stats->rendered_frames = m.rendered_frames;
    out_stats->nonzero_samples = m.nonzero_samples;
    out_stats->nonfinite_samples = m.nonfinite_samples;
    out_stats->deadline_misses = m.render_deadline_misses;
    out_stats->dropped_events = m.dropped_events;
    out_stats->events_processed = m.events_processed;
    out_stats->max_render_us = m.max_render_us;
    out_stats->peak_milli = static_cast<uint32_t>(m.peak * 1000.0f);
    out_stats->active = m.active ? 1u : 0u;
    out_stats->buffer_latency_ms = m.buffer_latency_ms;
}

} // extern "C"
