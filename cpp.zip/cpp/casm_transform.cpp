#include "casm_transform.hpp"

#include <algorithm>

namespace arranger::casm {
namespace {

constexpr int major_map[12] = {0,0,2,4,4,5,7,7,7,9,0,0};
constexpr int minor_map[12] = {0,0,2,3,3,5,7,7,8,7,0,0};
constexpr int dom7_map[12]  = {0,0,2,4,4,5,7,7,7,9,10,10};
constexpr int maj7_map[12]  = {0,0,2,4,4,5,7,7,7,9,11,11};
constexpr int min7_map[12]  = {0,0,2,3,3,5,7,7,8,10,10,10};
constexpr int dim_map[12]   = {0,0,2,3,3,5,6,6,8,9,0,0};
constexpr int aug_map[12]   = {0,0,2,4,4,6,6,8,8,10,10,0};

int map_relative(int rel, std::uint8_t chord_type) noexcept {
    rel %= 12;
    if (rel < 0) rel += 12;
    switch (chord_type) {
        case 0: return major_map[rel];
        case 1: return minor_map[rel];
        case 2: return dom7_map[rel];
        case 3: return maj7_map[rel];
        case 4: return min7_map[rel];
        case 5: return dim_map[rel];
        case 6: return aug_map[rel];
        default: return major_map[rel];
    }
}

int tight_map(int rel, std::uint8_t chord_type) noexcept {
    rel %= 12;
    if (rel < 0) rel += 12;
    switch (chord_type) {
        case 0:
            if (rel == 0 || rel == 1 || rel == 2 || rel == 10 || rel == 11) return 0;
            if (rel == 3 || rel == 4 || rel == 5) return 4;
            return 7;
        case 1:
            if (rel == 0 || rel == 1 || rel == 10 || rel == 11) return 0;
            if (rel == 2 || rel == 3 || rel == 4) return 3;
            return 7;
        case 2:
            if (rel == 0 || rel == 1 || rel == 2) return 0;
            if (rel == 3 || rel == 4 || rel == 5) return 4;
            if (rel == 6 || rel == 7 || rel == 8) return 7;
            return 10;
        case 3:
            if (rel == 0 || rel == 1 || rel == 2) return 0;
            if (rel == 3 || rel == 4 || rel == 5) return 4;
            if (rel == 6 || rel == 7 || rel == 8) return 7;
            return 11;
        case 4:
            if (rel == 0 || rel == 1) return 0;
            if (rel == 2 || rel == 3 || rel == 4) return 3;
            if (rel == 5 || rel == 6 || rel == 7) return 7;
            return 10;
        case 5:
            if (rel == 0 || rel == 1 || rel >= 9) return 0;
            if (rel == 2 || rel == 3 || rel == 4) return 3;
            return 6;
        case 6:
            if (rel == 0 || rel == 1 || rel == 2 || rel == 10 || rel == 11) return 0;
            if (rel == 3 || rel == 4 || rel == 5) return 4;
            return 8;
        default:
            return major_map[rel];
    }
}

std::uint8_t clamp_note(int note) noexcept {
    return static_cast<std::uint8_t>(std::clamp(note, 0, 127));
}

} // namespace

bool transform_note(const Rule& rule,
                    std::uint8_t input_note,
                    std::uint8_t chord_root_pc,
                    std::uint8_t chord_type,
                    std::uint8_t chord_bass_pc,
                    bool chord_bass_valid,
                    std::uint8_t& output_note) noexcept {
    (void)chord_bass_pc;
    (void)chord_bass_valid;

    if (!rule.slots || rule.slot_count == 0) return false;

    std::size_t idx = 0;
    if (chord_type == 1 || chord_type == 4 || chord_type == 5) idx = 1;
    else if (chord_type == 2 || chord_type == 3) idx = 2;
    if (idx >= rule.slot_count) idx = 0;

    const Slot* slot = &rule.slots[idx];
    if (slot->ntr == 0 && slot->ntt == 0) slot = &rule.slots[0];

    const int source_root_pc = static_cast<int>(rule.source_root) % 12;
    const int root_pc = static_cast<int>(chord_root_pc) % 12;

    int shift = 0;
    if (slot->ntr != 2) {
        shift = root_pc - source_root_pc;
        if (shift > 6) shift -= 12;
        else if (shift < -5) shift += 12;
    }

    int new_note = static_cast<int>(input_note) + shift;

    if (slot->ntt > 0 || slot->ntr == 2) {
        const int rel = ((new_note - root_pc) % 12 + 12) % 12;
        const int octave = new_note - rel;
        const bool is_chord = (slot->ntt == 2);
        const int mapped = is_chord ? tight_map(rel, chord_type) : map_relative(rel, chord_type);
        new_note = octave + mapped;
    }

    int note_lo = slot->note_lo;
    int note_hi = slot->note_hi;
    if (note_hi == 0 || note_hi <= note_lo) {
        note_lo = 0;
        note_hi = 127;
    }

    if (0 < note_hi && note_hi < 127 || note_lo > 0) {
        int failsafe = 10;
        while (new_note < note_lo && failsafe > 0) {
            new_note += 12;
            --failsafe;
        }
        while (new_note > note_hi && failsafe > 0) {
            new_note -= 12;
            --failsafe;
        }
    }

    output_note = clamp_note(new_note);
    return true;
}

} // namespace arranger::casm
