#include "vst2_legacy_abi.hpp"
#include "vst2_xg_profile.hpp"

#include <algorithm>
#include <array>
#include <cstdint>
#include <cstring>
#include <memory>
#include <new>
#include <string>

namespace {

constexpr std::size_t kMaxOutboundEvents = 64;
constexpr std::size_t kMaxSysExBytes = 4096;
constexpr std::size_t kInitSysExBytes = xgprofile::kXgSystemOn.size();
constexpr vst2mini::VstInt32 kPluginVersion = 1000;
constexpr vst2mini::VstInt32 kPluginUniqueId = vst2mini::cconst('Y','A','M','2');

struct OutboundEvents {
    vst2mini::VstInt32 numEvents = 0;
    vst2mini::VstIntPtr reserved = 0;
    vst2mini::VstEvent* events[kMaxOutboundEvents]{};
};

struct BridgeState {
    AEffect* effect = nullptr;
    vst2mini::audioMasterCallback host = nullptr;
    float sample_rate = 48000.0f;
    vst2mini::VstInt32 block_size = 1024;
    bool active = false;

    std::array<vst2mini::VstMidiEvent, kMaxOutboundEvents> midi{};
    std::array<vst2mini::VstSysExEvent, kMaxOutboundEvents> sysex{};
    std::array<std::array<char, kMaxSysExBytes>, kMaxOutboundEvents> sysex_storage{};
    std::array<char, kInitSysExBytes> xg_init_storage{};
    vst2mini::VstSysExEvent xg_init_event{};
    vst2mini::VstEvent* xg_init_events[1]{};
    vst2mini::VstEvents xg_init_batch{};
    bool xg_init_sent = false;
};

BridgeState* state(AEffect* effect) noexcept {
    return effect ? static_cast<BridgeState*>(effect->user) : nullptr;
}

const BridgeState* state(const AEffect* effect) noexcept {
    return effect ? static_cast<const BridgeState*>(effect->user) : nullptr;
}

void zero_audio(float** outputs, vst2mini::VstInt32 sample_frames) noexcept {
    if (!outputs || sample_frames <= 0) return;
    for (int ch = 0; ch < 2; ++ch) {
        if (outputs[ch]) {
            std::memset(outputs[ch], 0, static_cast<std::size_t>(sample_frames) * sizeof(float));
        }
    }
}

void copy_text(char* dst, std::size_t capacity, const char* text) noexcept {
    if (!dst || capacity == 0) return;
    std::strncpy(dst, text ? text : "", capacity - 1);
    dst[capacity - 1] = '\0';
}

bool send_xg_init(BridgeState& s) noexcept {
    if (!s.host || s.xg_init_sent) return true;
    xgprofile::fill_sysex_event(
        s.xg_init_event,
        s.xg_init_storage.data(),
        s.xg_init_storage.size(),
        xgprofile::kXgSystemOn.data(),
        xgprofile::kXgSystemOn.size(),
        0);
    s.xg_init_events[0] = reinterpret_cast<vst2mini::VstEvent*>(&s.xg_init_event);
    s.xg_init_batch.numEvents = 1;
    s.xg_init_batch.reserved = 0;
    s.xg_init_batch.events[0] = s.xg_init_events[0];
    const auto ok = s.host(s.effect, vst2mini::audioMasterProcessEvents, 0, 0,
                           reinterpret_cast<void*>(&s.xg_init_batch), 0.0f) != 0;
    if (ok) s.xg_init_sent = true;
    return ok;
}

bool send_outbound(BridgeState& s, OutboundEvents& out) noexcept {
    if (!s.host || out.numEvents <= 0) return true;
    return s.host(s.effect, vst2mini::audioMasterProcessEvents, 0, 0,
                  reinterpret_cast<void*>(&out), 0.0f) != 0;
}

vst2mini::VstIntPtr VSTCALLBACK dispatcher(AEffect* effect,
                                            vst2mini::VstInt32 opcode,
                                            vst2mini::VstInt32 index,
                                            vst2mini::VstIntPtr value,
                                            void* ptr,
                                            float opt) noexcept {
    BridgeState* s = state(effect);
    switch (opcode) {
        case vst2mini::effOpen:
            if (!s) return 0;
            s->active = true;
            if (s->host) {
                // Request host MIDI delivery. Return value is host-specific and ignored.
                (void)s->host(effect, vst2mini::audioMasterWantMidi, 0, 0, nullptr, 0.0f);
            }
            return 1;
        case vst2mini::effClose:
            delete s;
            if (effect) effect->user = nullptr;
            delete effect;
            return 1;
        case vst2mini::effSetSampleRate:
            if (s && opt > 0.0f) s->sample_rate = opt;
            return 1;
        case vst2mini::effSetBlockSize:
            if (s && value > 0) s->block_size = static_cast<vst2mini::VstInt32>(value);
            return 1;
        case vst2mini::effMainsChanged:
            if (s) {
                s->active = value != 0;
                if (s->active) {
                    // One XG System On at activation. This initializes Yamaha XG state
                    // before the first normal MIDI stream reaches the external VSTi.
                    (void)send_xg_init(*s);
                }
            }
            return 1;
        case vst2mini::effProcessEvents: {
            if (!s || !ptr) return 0;
            const auto* in = reinterpret_cast<const vst2mini::VstEvents*>(ptr);
            const int count = std::max(0, std::min<int>(in->numEvents, static_cast<int>(kMaxOutboundEvents)));
            OutboundEvents out{};
            int midi_count = 0;
            int sysex_count = 0;
            for (int i = 0; i < count; ++i) {
                auto* base = in->events[i];
                if (!base) continue;
                if (base->type == vst2mini::kVstMidiType) {
                    const auto* src = reinterpret_cast<const vst2mini::VstMidiEvent*>(base);
                    if (midi_count >= static_cast<int>(kMaxOutboundEvents)) continue;
                    auto& dst = s->midi[static_cast<std::size_t>(midi_count)];
                    dst = *src;
                    dst.type = vst2mini::kVstMidiType;
                    dst.byteSize = sizeof(vst2mini::VstMidiEvent);
                    out.events[out.numEvents++] = reinterpret_cast<vst2mini::VstEvent*>(&dst);
                    ++midi_count;
                } else if (base->type == vst2mini::kVstSysExType) {
                    const auto* src = reinterpret_cast<const vst2mini::VstSysExEvent*>(base);
                    const int bytes = std::max(0, std::min<int>(src->dumpBytes, static_cast<int>(kMaxSysExBytes)));
                    if (sysex_count >= static_cast<int>(kMaxOutboundEvents)) continue;
                    auto& dst = s->sysex[static_cast<std::size_t>(sysex_count)];
                    auto& storage = s->sysex_storage[static_cast<std::size_t>(sysex_count)];
                    dst.type = vst2mini::kVstSysExType;
                    dst.byteSize = sizeof(vst2mini::VstSysExEvent);
                    dst.deltaFrames = src->deltaFrames;
                    dst.flags = src->flags;
                    dst.dumpBytes = bytes;
                    dst.resvd1 = 0;
                    dst.sysexDump = storage.data();
                    dst.resvd2 = 0;
                    if (bytes > 0 && src->sysexDump) {
                        std::memcpy(storage.data(), src->sysexDump, static_cast<std::size_t>(bytes));
                    }
                    out.events[out.numEvents++] = reinterpret_cast<vst2mini::VstEvent*>(&dst);
                    ++sysex_count;
                }
            }
            (void)send_outbound(*s, out);
            return 1;
        }
        case vst2mini::effGetEffectName:
            copy_text(static_cast<char*>(ptr), 64, "Yamaha Arranger MIDI Bridge");
            return 1;
        case vst2mini::effGetVendorString:
            copy_text(static_cast<char*>(ptr), 64, "Yogi Music Studio");
            return 1;
        case vst2mini::effGetProductString:
            copy_text(static_cast<char*>(ptr), 64, "Yamaha Arranger VST2 MIDI XG");
            return 1;
        case vst2mini::effGetVendorVersion:
            return 23;
        case vst2mini::effGetPlugCategory:
            return vst2mini::kPlugCategSynth;
        case vst2mini::effGetVstVersion:
            return 2400;
        case vst2mini::effCanDo: {
            const char* text = static_cast<const char*>(ptr);
            if (!text) return 0;
            if (std::strcmp(text, "receiveVstEvents") == 0 ||
                std::strcmp(text, "receiveVstMidiEvent") == 0 ||
                std::strcmp(text, "sendVstEvents") == 0 ||
                std::strcmp(text, "sendVstMidiEvent") == 0 ||
                std::strcmp(text, "receiveVstTimeInfo") == 0) {
                return 1;
            }
            return 0;
        }
        default:
            return 0;
    }
}

void VSTCALLBACK processReplacing(AEffect* effect, float**, float** outputs,
                                  vst2mini::VstInt32 sample_frames) noexcept {
    (void)effect;
    zero_audio(outputs, sample_frames);
}

void VSTCALLBACK setParameter(AEffect*, vst2mini::VstInt32, float) noexcept {}
float VSTCALLBACK getParameter(AEffect*, vst2mini::VstInt32) noexcept { return 0.0f; }

} // namespace

VST_EXPORT AEffect* VSTCALLBACK VSTPluginMain(vst2mini::audioMasterCallback host) noexcept {
    if (!host) return nullptr;
    auto* effect = new (std::nothrow) AEffect{};
    auto* s = new (std::nothrow) BridgeState{};
    if (!effect || !s) {
        delete effect;
        delete s;
        return nullptr;
    }

    effect->magic = vst2mini::kEffectMagic;
    effect->dispatcher = dispatcher;
    effect->process = processReplacing;
    effect->setParameter = setParameter;
    effect->getParameter = getParameter;
    effect->numPrograms = 1;
    effect->numParams = 0;
    effect->numInputs = 0;
    effect->numOutputs = 2; // silent audio outputs; MIDI is the primary output.
    effect->flags = vst2mini::effFlagsCanReplacing | vst2mini::effFlagsIsSynth;
    effect->resvd1 = 0;
    effect->resvd2 = 0;
    effect->initialDelay = 0;
    effect->realQualities = 0;
    effect->offQualities = 0;
    effect->ioRatio = 1.0f;
    effect->object = nullptr;
    effect->user = s;
    effect->uniqueID = kPluginUniqueId;
    effect->version = kPluginVersion;
    effect->processReplacing = processReplacing;
    effect->processDoubleReplacing = nullptr;
    std::memset(effect->future, 0, sizeof(effect->future));

    s->effect = effect;
    s->host = host;
    return effect;
}

