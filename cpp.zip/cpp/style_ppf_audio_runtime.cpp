#include "style_ppf_audio_runtime.hpp"
#include "installed_style_voice_router.hpp"
#include <algorithm>
#include <cmath>
#include <limits>
#include <set>

namespace arranger {
StylePpfAudioRuntime::StylePpfAudioRuntime(const YamahaStyleRuntime& style,
                                           const PpfReader& reader,
                                           const PpfInstalledVoiceBank& bank)
    : style_(style), reader_(reader), bank_(bank), engine_(style) {}

StylePpfAudioRuntime::StylePpfAudioRuntime(const YamahaStyleRuntime& style,
                                           const PpfReader& reader,
                                           const PpfInstalledVoiceBank& bank,
                                           const InstalledVoiceCatalog& installed_catalog)
    : style_(style), reader_(reader), bank_(bank), installed_catalog_(&installed_catalog), engine_(style) {}

ResidentSamplePtr StylePpfAudioRuntime::to_resident(const PpfSample& src) {
    auto r = std::make_shared<ResidentSample>();
    r->uid_full = src.uid;
    r->sample_rate = src.sample_rate > 0 ? src.sample_rate : 44100;
    r->channels = 1;
    r->pcm.resize(src.pcm.size());
    for (std::size_t i=0;i<src.pcm.size();++i) r->pcm[i]=static_cast<float>(src.pcm[i])/32768.0f;
    return r;
}
bool StylePpfAudioRuntime::zone_accepts(const VoiceZone& z,int note,int velocity) noexcept { return note>=z.key_lo&&note<=z.key_hi&&velocity>=z.velocity_lo&&velocity<=z.velocity_hi; }
float StylePpfAudioRuntime::zone_gain(const VoiceZone& z,float master_gain) noexcept { double g=1.0; if(z.volume<0.0) g=std::pow(10.0,std::max(-60.0,std::min(0.0,z.volume))/20.0); g*=std::clamp((double)master_gain,0.0,1.0); return (float)std::clamp(g,0.0,1.0); }
float StylePpfAudioRuntime::zone_pan(const VoiceZone& z) noexcept { double p=z.pan; if(std::fabs(p)>1.0)p/=64.0; return (float)std::clamp(p,-1.0,1.0); }
double StylePpfAudioRuntime::zone_pitch_ratio(const VoiceZone& z,int note) noexcept { const double scale=z.fixed_pitch?0.0:std::clamp((double)z.pitch_scaling_sens/100.0,0.0,1.0); const double keyboard_delta=(double)(note-z.root_note)*scale; const double s=keyboard_delta+(double)z.tune_coarse+z.tune_fine/100.0+(double)z.element_note_shift+(double)z.element_tune_coarse+z.element_tune_fine/100.0; const double r=std::pow(2.0,s/12.0); return std::isfinite(r)&&r>0.0?r:1.0; }
const StylePpfAudioRuntime::ResidentZone* StylePpfAudioRuntime::choose_zone(std::size_t vi,int note,int vel) const noexcept {
    auto it=voices_.find(vi); if(it==voices_.end())return nullptr; const auto& zs=it->second; const ResidentZone* fallback=nullptr; const ResidentZone* best=nullptr; int best_span=std::numeric_limits<int>::max(); int best_vlo=-1;
    for(const auto& z:zs){ if(note>=z.zone.key_lo&&note<=z.zone.key_hi){ if(!fallback)fallback=&z; if(vel>=z.zone.velocity_lo&&vel<=z.zone.velocity_hi){int span=z.zone.key_hi-z.zone.key_lo; if(span<best_span||(span==best_span&&z.zone.velocity_lo>best_vlo)){best=&z;best_span=span;best_vlo=z.zone.velocity_lo;}}}}
    return best?best:fallback;
}
bool StylePpfAudioRuntime::preload_voice(std::size_t vi,std::size_t& count,std::size_t& new_pcm,std::string& error){
    if(vi>=reader_.voices().size()){error="PPF Voice index out of range";return false;} const auto& v=reader_.voices()[vi]; auto& dst=voices_[vi]; if(!dst.empty())return true; dst.reserve(v.zone_count);
    for(std::size_t zi=0;zi<v.zone_count;++zi){ const auto gi=v.first_zone_index+zi; if(gi>=reader_.voice_zones().size()){error="PPF zone index out of range";return false;} const auto& z=reader_.voice_zones()[gi]; const auto key=z.sample_uid+"|"+std::to_string(z.sample_rate); ResidentSamplePtr sample; auto it=pcm_cache_.find(key); if(it!=pcm_cache_.end()) sample=it->second; else {PpfSample raw; if(!reader_.load_voice_zone_sample(vi,zi,raw,error)){error="Zone PCM preload failed: "+error;return false;} sample=to_resident(raw); if(!sample||sample->pcm.empty()){error="Empty resident PCM";return false;} pcm_cache_.emplace(key,sample); ++new_pcm;} dst.push_back({z,sample}); ++count;}
    return true;
}
bool StylePpfAudioRuntime::prepare(std::string& error){
    error.clear();
    voices_.clear();
    pcm_cache_.clear();
    active_slots_.clear();
    active_slots_.reserve(ResidentSampler::kMaxVoices * 2);
    realtime_events_.clear();
    realtime_event_frames_.clear();
    realtime_seen_.clear();
    realtime_seen_.reserve(64);
    realtime_active_ = false;

    std::set<std::size_t> unique;
    if (installed_catalog_ != nullptr) {
        InstalledStyleVoiceRouter router;
        std::vector<InstalledVoiceResolution> rs;
        if (!router.scan(style_, *installed_catalog_, rs, error)) return false;
        for (const auto& r : rs) {
            if (!r.voice) continue;
            if (r.voice->format != InstalledVoiceFormat::PPF ||
                !r.voice->installed_address_valid) {
                error = "Installed PPF catalog returned an invalid installed Voice address";
                return false;
            }
            if (r.voice->source_index >= reader_.voices().size()) {
                error = "Installed PPF catalog source index is outside PPF Voice table";
                return false;
            }
            unique.insert(r.voice->source_index);
        }
    } else {
        StyleVoiceRouter router;
        std::vector<StyleVoiceResolution> rs;
        if(!router.scan(style_,bank_,rs,error))return false;
        for(const auto& r:rs)if(r.voice)unique.insert(r.voice->voice_index);
    }

    if(unique.empty()){error="No matched PPF Voice calls";return false;}
    std::size_t zc=0,pc=0;
    for(auto vi:unique)if(!preload_voice(vi,zc,pc,error))return false;
    return true;
}
bool StylePpfAudioRuntime::resolve_runtime_voice(std::uint8_t channel,
                                                   std::uint8_t msb,
                                                   std::uint8_t lsb,
                                                   std::uint8_t program,
                                                   const PpfVoiceDescriptor*& voice,
                                                   std::string& error,
                                                   InstalledVoiceResolution* mapping) const {
    voice = nullptr;
    if (mapping) *mapping = {};
    if (channel >= 16u) return true;

    if (installed_catalog_ != nullptr) {
        StyleVoiceCall call{};
        call.channel = channel;
        call.msb = static_cast<std::uint8_t>(msb & 0x7Fu);
        call.lsb = static_cast<std::uint8_t>(lsb & 0x7Fu);
        call.program = static_cast<std::uint8_t>(program & 0x7Fu);
        InstalledVoiceResolution resolved{};
        if (!installed_catalog_->resolve_style_call(call, resolved, error)) return false;
        if (!resolved.voice) return true;
        if (resolved.voice->format != InstalledVoiceFormat::PPF ||
            !resolved.voice->installed_address_valid) {
            error = "Runtime Voice resolution returned an invalid installed PPF Voice address";
            return false;
        }
        if (resolved.voice->source_index >= reader_.voices().size()) {
            error = "Runtime Voice resolution points outside PPF Voice table";
            return false;
        }
        voice = &reader_.voices()[resolved.voice->source_index];
        if (mapping) *mapping = resolved;
        return true;
    }

    voice = bank_.resolve(channel, msb, lsb, program);
    return true;
}

bool StylePpfAudioRuntime::consume_output_event(const ArrangerOutputEvent& e,std::array<std::uint8_t,16>& msb,std::array<std::uint8_t,16>& lsb,std::array<std::uint8_t,16>& program,std::vector<std::size_t>& seen,StylePpfAudioStats& stats,std::string& error){
    const auto ch=(std::uint8_t)(e.status&0x0F); if(ch>=16)return true; const auto cmd=e.status&0xF0;
    if(cmd==0xB0&&(e.data1==0||e.data1==32)){ if(e.data1==0)msb[ch]=e.data2&127;else lsb[ch]=e.data2&127; ++stats.voice_setup_events; return true; }
    if(cmd==0xC0){
        program[ch]=e.data1&127;
        ++stats.voice_setup_events;
        const PpfVoiceDescriptor* v=nullptr;
        InstalledVoiceResolution mapping{};
        if(!resolve_runtime_voice(ch,msb[ch],lsb[ch],program[ch],v,error,&mapping)) return false;
        if(v){
            if (installed_catalog_ != nullptr) ++stats.installed_catalog_voice_resolutions;
            if(std::find(seen.begin(),seen.end(),v->voice_index)==seen.end()){seen.push_back(v->voice_index);++stats.matched_voice_changes;}
        }
        return true;
    }
    const bool on=cmd==0x90&&e.data2>0, off=cmd==0x80||(cmd==0x90&&e.data2==0); if(!on&&!off)return true;
    if(on){
        ++stats.note_ons;
        const PpfVoiceDescriptor* v=nullptr;
        InstalledVoiceResolution mapping{};
        if(!resolve_runtime_voice(ch,msb[ch],lsb[ch],program[ch],v,error,&mapping)) return false;
        if(!v){++stats.notes_without_voice; return true;}
        if(installed_catalog_ != nullptr) ++stats.installed_catalog_note_resolutions;
        ++stats.resolved_note_ons;
        const auto* z=choose_zone(v->voice_index,e.data1,e.data2); if(!z){++stats.notes_without_zone;return true;}
        std::size_t slot=ResidentSampler::kMaxVoices;
        for(std::size_t i=0;i<ResidentSampler::kMaxVoices;++i)if(!sampler_.voice_active(i)){slot=i;break;}
        if(slot==ResidentSampler::kMaxVoices){++stats.sampler_note_on_failures;return true;}
        const auto& zz=z->zone; const bool loop=!zz.one_shot&&zz.loop_end_frame>zz.loop_start_frame+1;
        if(!sampler_.note_on_at_slot(slot,z->sample,e.data1,e.data2,zone_gain(zz,0.362f),zone_pan(zz),zone_pitch_ratio(zz,e.data1),(std::size_t)std::max(0,zz.loop_start_frame),(std::size_t)std::max(0,zz.loop_end_frame),loop,ch)){++stats.sampler_note_on_failures;return true;}
        active_slots_[{ch,e.data1}]=slot; return true;
    }
    ++stats.note_offs; const auto it=active_slots_.find({ch,e.data1}); if(it!=active_slots_.end()){++stats.resolved_note_offs; sampler_.note_off_slot(it->second);active_slots_.erase(it);} return true;
}
bool StylePpfAudioRuntime::render_ticks(std::uint32_t end_tick,int output_rate,std::vector<float>& out,StylePpfAudioStats& stats,std::string& error){
    if(output_rate<=0||end_tick==0){error="Invalid render target";return false;} if(voices_.empty()&&!prepare(error))return false; stats={}; stats.style_events=style_.events().size(); for(const auto& kv:voices_)stats.zone_preloaded+=kv.second.size(); stats.unique_pcm_loaded=pcm_cache_.size(); out.clear(); sampler_.all_notes_off(); if(!engine_.running()){engine_.set_acmp(true);engine_.set_chord(0,0);engine_.set_transpose(0);if(!engine_.start(error))return false;} std::vector<ArrangerOutputEvent> evs; if(!engine_.advance_to(end_tick,evs,error))return false; stats.output_events=evs.size(); const double bpm=std::clamp(style_.summary().tempo_bpm,30.0,300.0); const double fpt=(double)output_rate*60.0/(bpm*(double)std::max<std::uint16_t>(1,style_.summary().division)); std::array<std::uint8_t,16> msb{},lsb{},program{}; std::vector<std::size_t> seen; std::uint32_t last=0; std::vector<float> scratch(256*2,0.0f);
    for(const auto& e:evs){ const std::size_t nframes=(std::size_t)std::llround((double)(e.global_tick-last)*fpt); std::size_t rem=nframes; while(rem){const std::size_t n=std::min<std::size_t>(rem,256);std::fill(scratch.begin(),scratch.end(),0.0f);sampler_.render(scratch.data(),n,output_rate);out.insert(out.end(),scratch.begin(),scratch.begin()+n*2);stats.rendered_frames+=n;rem-=n;} if(!consume_output_event(e,msb,lsb,program,seen,stats,error))return false; last=e.global_tick; }
    std::size_t tail=(std::size_t)std::llround((double)(end_tick-last)*fpt); while(tail){const std::size_t n=std::min<std::size_t>(tail,256);std::fill(scratch.begin(),scratch.end(),0.0f);sampler_.render(scratch.data(),n,output_rate);out.insert(out.end(),scratch.begin(),scratch.begin()+n*2);stats.rendered_frames+=n;tail-=n;}
    stats.unique_matched_voices=seen.size(); for(float x:out){if(!std::isfinite(x)){++stats.nonfinite_samples;continue;} if(x!=0.0f)++stats.nonzero_samples; stats.peak=std::max(stats.peak,std::fabs(x));} return stats.rendered_frames>0&&stats.nonfinite_samples==0;
}
bool StylePpfAudioRuntime::start_realtime(std::uint32_t end_tick,
                                          int output_rate,
                                          std::string& error) {
    error.clear();
    if (output_rate <= 0 || end_tick == 0) {
        error = "Invalid realtime render target";
        return false;
    }
    if (voices_.empty() && !prepare(error)) return false;

    sampler_.all_notes_off();
    active_slots_.clear();
    active_slots_.reserve(ResidentSampler::kMaxVoices * 2);
    realtime_seen_.clear();
    std::fill(realtime_msb_.begin(), realtime_msb_.end(), 0);
    std::fill(realtime_lsb_.begin(), realtime_lsb_.end(), 0);
    std::fill(realtime_program_.begin(), realtime_program_.end(), 0);
    realtime_stats_ = {};
    realtime_event_index_ = 0;
    realtime_rendered_frames_ = 0;
    realtime_end_frame_ = 0;
    realtime_output_rate_ = output_rate;

    engine_.set_acmp(true);
    engine_.set_chord(0, 0);
    engine_.set_transpose(0);
    if (!engine_.start(error)) return false;

    realtime_events_.clear();
    if (!engine_.advance_to(end_tick, realtime_events_, error)) return false;

    const double bpm = std::clamp(style_.summary().tempo_bpm, 30.0, 300.0);
    const std::uint16_t div = std::max<std::uint16_t>(1, style_.summary().division);
    realtime_frames_per_tick_ = static_cast<double>(output_rate) * 60.0 /
                                (bpm * static_cast<double>(div));
    if (!(std::isfinite(realtime_frames_per_tick_) && realtime_frames_per_tick_ > 0.0)) {
        error = "Invalid realtime frame/tick conversion";
        return false;
    }

    realtime_event_frames_.clear();
    realtime_event_frames_.reserve(realtime_events_.size());
    std::uint32_t last_tick = 0;
    std::uint64_t frame_cursor = 0;
    for (const auto& e : realtime_events_) {
        const auto delta_frames = static_cast<std::uint64_t>(std::llround(
            static_cast<double>(e.global_tick - last_tick) * realtime_frames_per_tick_));
        frame_cursor += delta_frames;
        realtime_event_frames_.push_back(frame_cursor);
        last_tick = e.global_tick;
    }
    realtime_end_frame_ = frame_cursor + static_cast<std::uint64_t>(std::llround(
        static_cast<double>(end_tick - last_tick) * realtime_frames_per_tick_));

    realtime_stats_.style_events = style_.events().size();
    realtime_stats_.output_events = realtime_events_.size();
    for (const auto& kv : voices_) realtime_stats_.zone_preloaded += kv.second.size();
    realtime_stats_.unique_pcm_loaded = pcm_cache_.size();
    realtime_active_ = true;

    // Resolve all tick-zero setup events before the first audio frame, matching the
    // ordering of render_ticks().
    while (realtime_event_index_ < realtime_events_.size() &&
           realtime_event_frames_[realtime_event_index_] == 0) {
        if (!consume_output_event(realtime_events_[realtime_event_index_],
                                  realtime_msb_, realtime_lsb_, realtime_program_,
                                  realtime_seen_, realtime_stats_, error)) {
            realtime_active_ = false;
            return false;
        }
        ++realtime_event_index_;
    }
    return true;
}

bool StylePpfAudioRuntime::render_realtime(float* out_stereo,
                                           std::size_t frames,
                                           int output_rate,
                                           std::string& error) {
    if (!out_stereo || frames == 0) return true;
    if (!realtime_active_) {
        std::fill(out_stereo, out_stereo + frames * 2, 0.0f);
        return true;
    }
    if (output_rate != realtime_output_rate_) {
        std::fill(out_stereo, out_stereo + frames * 2, 0.0f);
        error = "Realtime output sample rate changed after initialization";
        return false;
    }

    std::size_t produced = 0;
    while (produced < frames) {
        while (realtime_event_index_ < realtime_events_.size() &&
               realtime_event_frames_[realtime_event_index_] <= realtime_rendered_frames_) {
            if (!consume_output_event(realtime_events_[realtime_event_index_],
                                      realtime_msb_, realtime_lsb_, realtime_program_,
                                      realtime_seen_, realtime_stats_, error)) {
                realtime_active_ = false;
                std::fill(out_stereo + produced * 2,
                          out_stereo + frames * 2, 0.0f);
                return false;
            }
            ++realtime_event_index_;
        }

        std::size_t segment = frames - produced;
        if (realtime_event_index_ < realtime_events_.size()) {
            const auto next_frame = realtime_event_frames_[realtime_event_index_];
            if (next_frame > realtime_rendered_frames_) {
                const auto until = next_frame - realtime_rendered_frames_;
                segment = std::min<std::size_t>(segment,
                    until > static_cast<std::uint64_t>(segment)
                        ? segment
                        : static_cast<std::size_t>(until));
            }
        } else if (realtime_end_frame_ > realtime_rendered_frames_) {
            const auto until = realtime_end_frame_ - realtime_rendered_frames_;
            segment = std::min<std::size_t>(segment,
                until > static_cast<std::uint64_t>(segment)
                    ? segment
                    : static_cast<std::size_t>(until));
        } else {
            std::fill(out_stereo + produced * 2, out_stereo + frames * 2, 0.0f);
            realtime_rendered_frames_ += (frames - produced);
            realtime_stats_.rendered_frames += (frames - produced);
            produced = frames;
            realtime_active_ = false;
            break;
        }

        if (segment == 0) continue;

        sampler_.render(out_stereo + produced * 2, segment, output_rate);
        realtime_rendered_frames_ += segment;
        realtime_stats_.rendered_frames += segment;
        produced += segment;
    }

    if (realtime_rendered_frames_ >= realtime_end_frame_) realtime_active_ = false;
    return true;
}

}
