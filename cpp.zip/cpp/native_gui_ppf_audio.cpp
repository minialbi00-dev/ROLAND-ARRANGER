#include "native_gui_ppf_audio.hpp"
#include "installed_style_voice_router.hpp"

#include <algorithm>
#include <chrono>
#include <cmath>
#include <cstring>
#include <cctype>
#include <limits>
#include <filesystem>
#include <cstdlib>
#include <fstream>
#include <unordered_set>
#include <unordered_map>

#ifdef _WIN32
#ifndef NOMINMAX
#define NOMINMAX
#endif
#include <windows.h>
#include <mmdeviceapi.h>
#include <audioclient.h>
#include <wrl/client.h>
#endif

namespace arranger {

    namespace {
        constexpr std::size_t kPpfRhythm1 = PpfInstalledVoiceBank::kRhythm1Channel;
        constexpr std::size_t kPpfRhythm2 = PpfInstalledVoiceBank::kRhythm2Channel;

#ifdef _WIN32
        using Microsoft::WRL::ComPtr;
        const GUID kIEEEFloatSubFormat =
        { 0x00000003,0x0000,0x0010,{0x80,0x00,0x00,0xaa,0x00,0x38,0x9b,0x71} };

        void module_anchor() noexcept {}

        bool hr_error(HRESULT hr, const char* where, std::string& error) {
            char buf[64]{};
            std::snprintf(buf, sizeof(buf), "0x%08lX", static_cast<unsigned long>(hr));
            error = std::string(where) + " failed (HRESULT " + buf + ")";
            return false;
        }
#endif
    }

#ifdef _WIN32
    struct NativeGuiPpfAudio::WasapiState {
        ComPtr<IMMDevice> device;
        ComPtr<IAudioClient> client;
        ComPtr<IAudioRenderClient> render;
        WAVEFORMATEX* mix_format = nullptr;
        HANDLE event = nullptr;
        UINT32 buffer_frames = 0;
        int channels = 2;
        bool float32 = false;
        bool started = false;
        std::vector<float> scratch;

        ~WasapiState() {
            if (started && client) client->Stop();
            if (event) CloseHandle(event);
            event = nullptr;
            render.Reset();
            client.Reset();
            device.Reset();
            if (mix_format) CoTaskMemFree(mix_format);
            mix_format = nullptr;
        }
    };
#endif

    NativeGuiPpfAudio::NativeGuiPpfAudio()
        : ppf_note_engine_(ppf_runtime_, sampler_) {
        for (auto& row : active_slots_) row.fill(-1);
        pending_.reserve(kPendingCapacity);
    }

    NativeGuiPpfAudio::~NativeGuiPpfAudio() { stop(); }

    void NativeGuiPpfAudio::set_audio_device_id(const std::string& device_id) noexcept {
        audio_device_id_ = device_id;
    }

    std::string NativeGuiPpfAudio::audio_device_id() const {
        return audio_device_id_;
    }

    bool NativeGuiPpfAudio::load_soundfont(const std::string& path, std::string& error) {
        error.clear();
        if (active_.load(std::memory_order_acquire)) {
            error = "Stop playback before loading a SoundFont";
            return false;
        }
        if (path.empty()) {
            error = "SoundFont path is empty";
            return false;
        }
        return soundfont_.load(path, error);
    }

    bool NativeGuiPpfAudio::ensure_soundfont(std::string& error) {
        if (soundfont_.loaded()) return true;

        std::vector<std::filesystem::path> candidates;
        if (const char* env = std::getenv("YAMAHA_ARRANGER_SF2"); env && *env) {
            candidates.emplace_back(env);
        }

#ifdef _WIN32
        HMODULE module = nullptr;
        if (GetModuleHandleExA(GET_MODULE_HANDLE_EX_FLAG_FROM_ADDRESS |
            GET_MODULE_HANDLE_EX_FLAG_UNCHANGED_REFCOUNT,
            reinterpret_cast<LPCSTR>(&module_anchor), &module)) {
            char buf[MAX_PATH]{};
            const DWORD n = GetModuleFileNameA(module, buf, MAX_PATH);
            if (n > 0 && n < MAX_PATH) {
                const auto dir = std::filesystem::path(std::string(buf, n)).parent_path();
                candidates.push_back(dir / "GMGSx.sf2");
                candidates.push_back(dir / "gui" / "GMGSx.sf2");
            }
        }
        char exe_buf[MAX_PATH]{};
        const DWORD exe_n = GetModuleFileNameA(nullptr, exe_buf, MAX_PATH);
        if (exe_n > 0 && exe_n < MAX_PATH) {
            const auto dir = std::filesystem::path(std::string(exe_buf, exe_n)).parent_path();
            candidates.push_back(dir / "GMGSx.sf2");
            candidates.push_back(dir / "gui" / "GMGSx.sf2");
        }
#endif
        candidates.emplace_back("GMGSx.sf2");
        candidates.emplace_back(std::filesystem::path("gui") / "GMGSx.sf2");

        std::error_code ec;
        std::string last_error;
        for (const auto& path : candidates) {
            if (path.empty() || !std::filesystem::exists(path, ec) || ec) { ec.clear(); continue; }
            std::string load_error;
            if (soundfont_.load(path.string(), load_error)) {
                return true;
            }
            last_error = load_error;
        }
        if (!last_error.empty()) {
            error = "bundled GM/XG SoundFont failed to load: " + last_error;
            return false;
        }
        return !ppf_banks_.empty();
    }

    void NativeGuiPpfAudio::reset_transport() noexcept {
        sampler_.all_notes_off();
        ppf_note_engine_.reset();
        for (auto& row : active_slots_) row.fill(-1);
        msb_.fill(0);
        lsb_.fill(0);
        program_.fill(0);
        pending_.clear();
        const auto h = queue_.head.load(std::memory_order_acquire);
        queue_.tail.store(h, std::memory_order_release);
        anchor_tick_.store(0, std::memory_order_release);
        anchor_frame_.store(rendered_frames_.load(std::memory_order_acquire), std::memory_order_release);
    }

    std::size_t NativeGuiPpfAudio::installed_ppf_bank_count() const noexcept {
        return ppf_banks_.size();
    }

    bool NativeGuiPpfAudio::has_audio_source() const noexcept {
        return !ppf_banks_.empty() || soundfont_.loaded();
    }

    ResidentSamplePtr NativeGuiPpfAudio::to_resident(const PpfSample& src) {
        auto r = std::make_shared<ResidentSample>();
        r->uid_full = src.uid;
        r->sample_rate = src.sample_rate > 0 ? src.sample_rate : 44100;
        r->channels = (src.channels == 2) ? 2 : 1;
        r->pcm.resize(src.pcm.size());
        for (std::size_t i = 0; i < src.pcm.size(); ++i)
            r->pcm[i] = static_cast<float>(src.pcm[i]) / 32768.0f;
        return r;
    }

    namespace {
        std::string upper_token(std::string s) {
            for (auto& c : s) c = static_cast<char>(std::toupper(static_cast<unsigned char>(c)));
            return s;
        }

        bool is_left_side(const VoiceZone& z) {
            const auto p = upper_token(z.sample_position);
            return p == "L" || p == "LEFT" || p == "STEREO_L" || p == "MONO_LEFT" ||
                p.find("LEFT") != std::string::npos || (!p.empty() && p.back() == 'L' && p != "MONO");
        }

        bool is_right_side(const VoiceZone& z) {
            const auto p = upper_token(z.sample_position);
            return p == "R" || p == "RIGHT" || p == "STEREO_R" || p == "MONO_RIGHT" ||
                p.find("RIGHT") != std::string::npos || (!p.empty() && p.back() == 'R' && p != "MONO");
        }
    } // namespace

    float NativeGuiPpfAudio::zone_gain(const VoiceZone& z) noexcept {
        double g = 1.0;
        if (z.volume < 0.0) g = std::pow(10.0, std::clamp(z.volume, -60.0, 0.0) / 20.0);
        return static_cast<float>(std::clamp(g, 0.0, 1.0));
    }

    float NativeGuiPpfAudio::zone_pan(const VoiceZone& z) noexcept {
        double p = z.pan;
        if (std::fabs(p) > 1.0) p /= 64.0;
        return static_cast<float>(std::clamp(p, -1.0, 1.0));
    }

    double NativeGuiPpfAudio::zone_pitch_ratio(const VoiceZone& z, int note) noexcept {
        const double scale = z.fixed_pitch
            ? 0.0
            : std::clamp(static_cast<double>(z.pitch_scaling_sens) / 100.0, 0.0, 1.0);
        const double keyboard_delta = static_cast<double>(note - z.root_note) * scale;
        const double semis = keyboard_delta +
            static_cast<double>(z.tune_coarse) + z.tune_fine / 100.0 +
            static_cast<double>(z.element_note_shift) +
            static_cast<double>(z.element_tune_coarse) +
            z.element_tune_fine / 100.0;
        const double ratio = std::pow(2.0, semis / 12.0);
        return std::isfinite(ratio) && ratio > 0.0 ? ratio : 1.0;
    }

    NativeGuiPpfAudio::PpfRuntimeBank* NativeGuiPpfAudio::find_runtime_bank(std::size_t bank_id) noexcept {
        for (auto& bank : ppf_banks_) if (bank.bank_id == bank_id) return &bank;
        return nullptr;
    }

    const NativeGuiPpfAudio::PpfRuntimeBank* NativeGuiPpfAudio::find_runtime_bank(std::size_t bank_id) const noexcept {
        for (const auto& bank : ppf_banks_) if (bank.bank_id == bank_id) return &bank;
        return nullptr;
    }

    bool NativeGuiPpfAudio::prepare_voice(const InstalledVoiceRecord& voice, std::string& error) {
        if (voice.format != InstalledVoiceFormat::PPF) return true;
        const auto* bank = find_runtime_bank(voice.bank_id);
        if (!bank || !bank->reader) {
            error = "Installed PPF bank is not resident: bank_id=" + std::to_string(voice.bank_id);
            return false;
        }
        if (voice.source_index >= bank->reader->voices().size()) {
            error = "Installed PPF Voice index out of range";
            return false;
        }

        const auto* existing_voice = ppf_runtime_.find_voice(voice.bank_id, voice.source_index);
        if (existing_voice && !existing_voice->empty()) return true;

        const auto& descriptor = bank->reader->voices()[voice.source_index];
        const auto& all_zones = bank->reader->voice_zones();
        if (descriptor.voice_type == "EKB_LEGACY") return true;
        PpfRuntimeVoice runtime_voice;
        runtime_voice.bank_id = voice.bank_id;
        runtime_voice.source_index = voice.source_index;
        runtime_voice.zones.reserve(descriptor.zone_count);

        struct PairKey {
            int wf, kb, lo, hi, vlo, vhi, root;
            bool operator==(const PairKey& o) const noexcept {
                return wf == o.wf && kb == o.kb && lo == o.lo && hi == o.hi && vlo == o.vlo && vhi == o.vhi && root == o.root;
            }
        };
        struct PairHash {
            std::size_t operator()(const PairKey& k) const noexcept {
                std::size_t h = static_cast<std::size_t>(k.wf + 1);
                h = h * 1315423911u + static_cast<std::size_t>(k.kb + 1);
                h = h * 1315423911u + static_cast<std::size_t>(k.lo + 1);
                h = h * 1315423911u + static_cast<std::size_t>(k.hi + 1);
                h = h * 1315423911u + static_cast<std::size_t>(k.vlo + 1);
                h = h * 1315423911u + static_cast<std::size_t>(k.vhi + 1);
                h = h * 1315423911u + static_cast<std::size_t>(k.root + 1);
                return h;
            }
        };
        std::unordered_map<PairKey, std::size_t, PairHash> right_zone_by_key;
        right_zone_by_key.reserve(descriptor.zone_count);
        for (std::size_t zi = 0; zi < descriptor.zone_count; ++zi) {
            const auto& z = all_zones[descriptor.first_zone_index + zi];
            if (!is_right_side(z)) continue;
            const PairKey k{ static_cast<int>(z.waveform_index), static_cast<int>(z.keybank_index), z.key_lo, z.key_hi, z.velocity_lo, z.velocity_hi, z.root_note };
            right_zone_by_key.emplace(k, zi);
        }

        for (std::size_t zi = 0; zi < descriptor.zone_count; ++zi) {
            const auto& zone = all_zones[descriptor.first_zone_index + zi];
            if (is_right_side(zone)) continue;

            ResidentSamplePtr sample;
            std::string cache_key = std::to_string(voice.bank_id) + "|" +
                zone.sample_uid + "|" + std::to_string(zone.sample_rate);

            std::size_t partner_zi = descriptor.zone_count;
            if (is_left_side(zone)) {
                const PairKey k{ static_cast<int>(zone.waveform_index), static_cast<int>(zone.keybank_index),
                                zone.key_lo, zone.key_hi, zone.velocity_lo, zone.velocity_hi, zone.root_note };
                const auto pit = right_zone_by_key.find(k);
                if (pit != right_zone_by_key.end()) {
                    partner_zi = pit->second;
                    const auto& right_zone = all_zones[descriptor.first_zone_index + partner_zi];
                    cache_key += "|STEREO|" + right_zone.sample_uid;
                }
            }

            auto cached = pcm_cache_.find(cache_key);
            if (cached != pcm_cache_.end()) {
                sample = cached->second;
            }
            else {
                PpfSample raw;
                if (!bank->reader->load_voice_zone_sample(voice.source_index, zi, raw, error)) {
                    error = "Zone PCM preload failed: " + error;
                    return false;
                }

                if (partner_zi < descriptor.zone_count) {
                    const auto& right_zone = all_zones[descriptor.first_zone_index + partner_zi];
                    PpfSample right;
                    if (!bank->reader->load_voice_zone_sample(voice.source_index, partner_zi, right, error)) {
                        error = "Stereo RIGHT PCM preload failed: " + error;
                        return false;
                    }
                    const std::size_t frames = std::min(raw.pcm.size(), right.pcm.size());
                    auto stereo = std::make_shared<ResidentSample>();
                    stereo->uid_full = raw.uid + "|" + right.uid;
                    stereo->sample_rate = raw.sample_rate > 0 ? raw.sample_rate : right.sample_rate;
                    stereo->channels = 2;
                    stereo->pcm.resize(frames * 2u);
                    for (std::size_t i = 0; i < frames; ++i) {
                        stereo->pcm[i * 2u] = static_cast<float>(raw.pcm[i]) / 32768.0f;
                        stereo->pcm[i * 2u + 1u] = static_cast<float>(right.pcm[i]) / 32768.0f;
                    }
                    sample = stereo;
                }
                else {
                    sample = to_resident(raw);
                }

                if (!sample || sample->pcm.empty()) {
                    error = "Empty resident PCM";
                    return false;
                }
                pcm_cache_.emplace(cache_key, sample);
                resident_pcm_bytes_.fetch_add(
                    static_cast<std::uint64_t>(sample->pcm.size() * sizeof(float)),
                    std::memory_order_relaxed);
                unique_pcm_count_.fetch_add(1, std::memory_order_relaxed);
            }

            runtime_voice.zones.push_back({ zone, sample });
        }
        const std::size_t resident_zone_count = runtime_voice.zone_count();
        if (!ppf_runtime_.upsert_voice(std::move(runtime_voice), error)) return false;
        resident_zone_count_.fetch_add(static_cast<std::uint32_t>(resident_zone_count), std::memory_order_relaxed);
        return true;
    }

    const PpfRuntimeZone* NativeGuiPpfAudio::choose_zone(
        std::size_t bank_id, std::size_t voice_index, int note, int velocity) const noexcept {
        return ppf_runtime_.resolve(bank_id, voice_index, note, velocity);
    }

    bool NativeGuiPpfAudio::prepare_style(const YamahaStyleRuntime& style, std::string& error) {
        if (active_.load(std::memory_order_acquire)) {
            error = "cannot mutate native PPF residency while audio is running";
            return false;
        }
        if (ppf_banks_.empty()) return true;
        InstalledStyleVoiceRouter router;
        std::vector<InstalledVoiceResolution> resolutions;
        if (!router.scan(style, catalog_, resolutions, error)) return false;

        for (const auto& r : resolutions) {
            if (!r.voice || r.voice->format != InstalledVoiceFormat::PPF) continue;
            if (!prepare_voice(*r.voice, error)) return false;
        }
        return true;
    }

    bool NativeGuiPpfAudio::install_ppf_bank(const std::string& ppf_path,
        InstalledVoiceAddress installed_base,
        const YamahaStyleRuntime& style,
        std::string& error) {
        if (active_.load(std::memory_order_acquire)) {
            error = "PPF Voice banks cannot be installed while native audio is running";
            return false;
        }
        if (ppf_path.empty()) { error = "PPF path is empty"; return false; }

        auto reader = std::make_shared<PpfReader>();
        if (!reader->open(ppf_path, error)) return false;
        PpfInstalledVoiceBank bank;
        if (!bank.install(*reader, error)) return false;

        if (installed_base.msb == 0xFFu && installed_base.lsb == 0xFFu) {
            std::uint8_t source_msb = 0, source_lsb = 0;
            if (!reader->source_bank_slot(source_msb, source_lsb, error)) return false;
            installed_base = { source_msb, source_lsb, 0 };
        }
        else if (installed_base.msb == 0xFFu || installed_base.lsb == 0xFFu) {
            error = "PPF install requires both MSB and LSB, or both 255 to preserve the PPF source slot";
            return false;
        }

        std::size_t bank_id = 0;
        if (!catalog_.install_ppf(*reader, ppf_path, installed_base, error, &bank_id)) return false;

        try {
            ppf_banks_.reserve(ppf_banks_.size() + 1u);
            ppf_banks_.push_back(PpfRuntimeBank{ bank_id, ppf_path, installed_base, std::move(reader), std::move(bank) });
        }
        catch (...) {
            (void)catalog_.remove_bank(bank_id);
            error = "not enough RAM while creating resident PPF bank";
            return false;
        }

        const auto installed_voice_count = static_cast<std::uint32_t>(ppf_banks_.back().reader->voices().size());
        ppf_voice_count_.fetch_add(installed_voice_count, std::memory_order_release);
        ppf_bank_count_.fetch_add(1u, std::memory_order_release);

        std::string first_residency_error;
        std::size_t failed_voice_count = 0;
        for (const auto& v : catalog_.bank_voice_records(bank_id)) {
            std::string voice_error;
            if (!prepare_voice(v, voice_error)) {
                ++failed_voice_count;
                if (first_residency_error.empty()) first_residency_error = voice_error;
                ppf_runtime_.remove_voice(bank_id, v.source_index);
            }
        }
        const std::string residency_warning = failed_voice_count
            ? ("PPF installed with partial Voice residency: " + std::to_string(failed_voice_count) +
                " Voice(s) could not be preloaded" +
                (first_residency_error.empty() ? std::string() : " (" + first_residency_error + ")"))
            : std::string();
        std::size_t live_zones = 0;
        std::uint64_t live_bytes = 0;
        std::unordered_set<const ResidentSample*> live_samples;
        ppf_runtime_.for_each_voice([&](const PpfRuntimeVoice& voice) {
            live_zones += voice.zone_count();
            for (const auto& zone : voice.zones) if (zone.sample) live_samples.insert(zone.sample.get());
            });
        for (auto it = pcm_cache_.begin(); it != pcm_cache_.end();) {
            if (!it->second || !live_samples.count(it->second.get())) it = pcm_cache_.erase(it);
            else { live_bytes += static_cast<std::uint64_t>(it->second->pcm.size() * sizeof(float)); ++it; }
        }
        resident_zone_count_.store(static_cast<std::uint32_t>(live_zones), std::memory_order_release);
        unique_pcm_count_.store(static_cast<std::uint32_t>(pcm_cache_.size()), std::memory_order_release);
        resident_pcm_bytes_.store(live_bytes, std::memory_order_release);
        if (!prepare_style(style, error)) {
            ppf_banks_.pop_back();
            (void)catalog_.remove_bank(bank_id);
            ppf_voice_count_.fetch_sub(installed_voice_count, std::memory_order_release);
            ppf_bank_count_.fetch_sub(1u, std::memory_order_release);
            return false;
        }
        if (!residency_warning.empty()) error = residency_warning;
        else error.clear();
        return true;
    }

    bool NativeGuiPpfAudio::install_ppf_bank_audio_only(const std::string& ppf_path,
        InstalledVoiceAddress installed_base,
        std::string& error) {
        if (active_.load(std::memory_order_acquire)) {
            error = "PPF Voice banks cannot be installed while native audio is running";
            return false;
        }
        if (ppf_path.empty()) { error = "PPF path is empty"; return false; }

        auto reader = std::make_shared<PpfReader>();
        if (!reader->open(ppf_path, error)) return false;
        PpfInstalledVoiceBank bank;
        if (!bank.install(*reader, error)) return false;

        if (installed_base.msb == 0xFFu && installed_base.lsb == 0xFFu) {
            std::uint8_t source_msb = 0;
            std::uint8_t source_lsb = 0;
            if (!reader->source_bank_slot(source_msb, source_lsb, error)) return false;
            installed_base = { source_msb, source_lsb, 0 };
        }
        else if (installed_base.msb == 0xFFu || installed_base.lsb == 0xFFu) {
            error = "PPF install requires both MSB and LSB to be explicit, or both 255 to preserve the PPF source slot";
            return false;
        }

        std::size_t bank_id = 0;
        if (!catalog_.install_ppf(*reader, ppf_path, installed_base, error, &bank_id)) return false;

        try {
            ppf_banks_.reserve(ppf_banks_.size() + 1u);
            ppf_banks_.push_back(PpfRuntimeBank{ bank_id, ppf_path, installed_base, std::move(reader), std::move(bank) });
        }
        catch (...) {
            (void)catalog_.remove_bank(bank_id);
            error = "not enough RAM while creating resident PPF bank";
            return false;
        }

        const auto installed_voice_count = static_cast<std::uint32_t>(ppf_banks_.back().reader->voices().size());
        ppf_voice_count_.fetch_add(installed_voice_count, std::memory_order_release);
        ppf_bank_count_.fetch_add(1u, std::memory_order_release);

        std::string first_residency_error;
        std::size_t failed_voice_count = 0;
        for (const auto& v : catalog_.bank_voice_records(bank_id)) {
            std::string voice_error;
            if (!prepare_voice(v, voice_error)) {
                ++failed_voice_count;
                if (first_residency_error.empty()) first_residency_error = voice_error;
                ppf_runtime_.remove_voice(bank_id, v.source_index);
            }
        }
        std::size_t live_zones = 0;
        std::uint64_t live_bytes = 0;
        std::unordered_set<const ResidentSample*> live_samples;
        ppf_runtime_.for_each_voice([&](const PpfRuntimeVoice& voice) {
            live_zones += voice.zone_count();
            for (const auto& zone : voice.zones) if (zone.sample) live_samples.insert(zone.sample.get());
            });
        for (auto it = pcm_cache_.begin(); it != pcm_cache_.end();) {
            if (!it->second || !live_samples.count(it->second.get())) it = pcm_cache_.erase(it);
            else { live_bytes += static_cast<std::uint64_t>(it->second->pcm.size() * sizeof(float)); ++it; }
        }
        resident_zone_count_.store(static_cast<std::uint32_t>(live_zones), std::memory_order_release);
        unique_pcm_count_.store(static_cast<std::uint32_t>(pcm_cache_.size()), std::memory_order_release);
        resident_pcm_bytes_.store(live_bytes, std::memory_order_release);
        if (failed_voice_count) {
            error = "PPF installed with partial Voice residency: " + std::to_string(failed_voice_count) +
                " Voice(s) could not be preloaded" +
                (first_residency_error.empty() ? std::string() : " (" + first_residency_error + ")");
        }
        else {
            error.clear();
        }
        return true;
    }

    bool NativeGuiPpfAudio::uninstall_ppf_bank(std::size_t bank_id, std::string& error) {
        error.clear();
        if (active_.load(std::memory_order_acquire)) {
            error = "PPF Voice banks cannot be uninstalled while native audio is running";
            return false;
        }

        auto bit = std::find_if(ppf_banks_.begin(), ppf_banks_.end(),
            [bank_id](const PpfRuntimeBank& b) { return b.bank_id == bank_id; });
        if (bit == ppf_banks_.end()) {
            error = "PPF bank not found: bank_id=" + std::to_string(bank_id);
            return false;
        }

        reset_transport();
        const std::size_t removed_voice_count = ppf_runtime_.remove_bank(bank_id);

        if (!catalog_.remove_bank(bank_id)) {
            error = "PPF catalog bank removal failed: bank_id=" + std::to_string(bank_id);
            return false;
        }
        ppf_banks_.erase(bit);

        std::unordered_set<const ResidentSample*> live_samples;
        live_samples.reserve(pcm_cache_.size());
        ppf_runtime_.for_each_voice([&](const PpfRuntimeVoice& voice) {
            for (const auto& zone : voice.zones) {
                if (zone.sample) live_samples.insert(zone.sample.get());
            }
            });

        std::uint64_t resident_bytes = 0;
        for (auto it = pcm_cache_.begin(); it != pcm_cache_.end();) {
            if (!it->second || !live_samples.count(it->second.get())) {
                it = pcm_cache_.erase(it);
            }
            else {
                resident_bytes += static_cast<std::uint64_t>(it->second->pcm.size() * sizeof(float));
                ++it;
            }
        }

        const std::size_t resident_zones = ppf_runtime_.zone_count();
        std::size_t total_voices = 0;
        for (const auto& bank : ppf_banks_) {
            if (bank.reader) total_voices += bank.reader->voices().size();
        }

        ppf_voice_count_.store(static_cast<std::uint32_t>(total_voices), std::memory_order_release);
        ppf_bank_count_.store(static_cast<std::uint32_t>(ppf_banks_.size()), std::memory_order_release);
        resident_zone_count_.store(static_cast<std::uint32_t>(resident_zones), std::memory_order_release);
        unique_pcm_count_.store(static_cast<std::uint32_t>(pcm_cache_.size()), std::memory_order_release);
        resident_pcm_bytes_.store(resident_bytes, std::memory_order_release);
        (void)removed_voice_count;
        return true;
    }

    std::vector<NativeGuiPpfBankInfo> NativeGuiPpfAudio::installed_ppf_banks() const {
        std::vector<NativeGuiPpfBankInfo> out;
        out.reserve(ppf_banks_.size());
        for (const auto& bank : ppf_banks_) {
            NativeGuiPpfBankInfo info;
            info.bank_id = bank.bank_id;
            info.path = bank.path;
            info.voice_count = bank.reader ? bank.reader->voices().size() : 0u;
            info.msb = 63;
            info.lsb = 62;
            if (bank.reader) {
                for (const auto& v : bank.reader->voices()) {
                    if (v.msb == 62u || v.msb == 63u) {
                        info.msb = v.msb;
                        info.lsb = bank.installed_base.lsb;
                        break;
                    }
                }
            }
            out.push_back(std::move(info));
        }
        return out;
    }

    std::vector<NativeGuiPpfVoiceInfo> NativeGuiPpfAudio::installed_ppf_voices() const {
        std::vector<NativeGuiPpfVoiceInfo> out;
        const auto& records = catalog_.voices();
        out.reserve(records.size());
        for (const auto& record : records) {
            if (record.format != InstalledVoiceFormat::PPF) continue;
            NativeGuiPpfVoiceInfo info;
            info.bank_id = record.bank_id;
            info.source_index = record.source_index;
            info.title = record.title;
            info.source_path = record.source_path;
            info.source_address = record.source_address;
            info.installed_address = record.installed_address;
            info.source_address_valid = record.source_address_valid;
            info.installed_address_valid = record.installed_address_valid;
            info.zone_count = record.zone_count;
            if (const auto* bank = find_runtime_bank(record.bank_id); bank && bank->reader) {
                const auto& descriptors = bank->reader->voices();
                if (record.source_index < descriptors.size()) info.voice_type = descriptors[record.source_index].voice_type;
            }
            const auto* resident = ppf_runtime_.find_voice(record.bank_id, record.source_index);
            info.resident_zone_count = resident ? resident->zone_count() : 0u;
            out.push_back(std::move(info));
        }
        return out;
    }

    int NativeGuiPpfAudio::preload_style_voice(const StyleVoiceCall& call, std::string& error) {
        InstalledVoiceResolution resolution;
        std::string resolve_error;
        if (!catalog_.resolve_style_call(call, resolution, resolve_error)) {
            error = resolve_error.empty() ? "invalid Style Voice call" : resolve_error;
            return -1;
        }
        if (!resolution.voice || resolution.voice->format != InstalledVoiceFormat::PPF) return 0;

        const auto* resident_voice = ppf_runtime_.find_voice(resolution.voice->bank_id, resolution.voice->source_index);
        if (resident_voice && !resident_voice->empty()) return 1;

        if (active_.load(std::memory_order_acquire)) {
            error = "cannot add missing PPF Voice residency while native audio is running";
            return -1;
        }
        if (!prepare_voice(*resolution.voice, error)) return -1;
        return 1;
    }

    bool NativeGuiPpfAudio::configure(const std::string& ppf_path,
        const YamahaStyleRuntime& style,
        std::string& error) {
        stop();
        ppf_runtime_.clear();
        pcm_cache_.clear();
        ppf_banks_.clear();
        catalog_.clear();
        ppf_voice_count_.store(0, std::memory_order_release);
        ppf_bank_count_.store(0, std::memory_order_release);
        resident_zone_count_.store(0, std::memory_order_release);
        unique_pcm_count_.store(0, std::memory_order_release);
        resident_pcm_bytes_.store(0, std::memory_order_release);
        return install_ppf_bank(ppf_path, InstalledVoiceAddress{ 0xFF, 0xFF, 0 }, style, error);
    }

    bool NativeGuiPpfAudio::push(const NativeGuiAudioEvent& e) noexcept {
        const auto h = queue_.head.load(std::memory_order_relaxed);
        const auto t = queue_.tail.load(std::memory_order_acquire);
        if (h - t >= kQueueCapacity) return false;
        queue_.data[h % kQueueCapacity] = e;
        queue_.head.store(h + 1, std::memory_order_release);
        return true;
    }

    bool NativeGuiPpfAudio::pop(NativeGuiAudioEvent& e) noexcept {
        const auto t = queue_.tail.load(std::memory_order_relaxed);
        const auto h = queue_.head.load(std::memory_order_acquire);
        if (t == h) return false;
        e = queue_.data[t % kQueueCapacity];
        queue_.tail.store(t + 1, std::memory_order_release);
        return true;
    }

    bool NativeGuiPpfAudio::enqueue(const ArrangerOutputEvent& event) noexcept {
        if (!active_.load(std::memory_order_acquire)) return true;
        NativeGuiAudioEvent e{ event.global_tick, event.status, event.data1, event.data2 };
        if (!push(e)) {
            dropped_events_.fetch_add(1, std::memory_order_relaxed);
            return false;
        }
        return true;
    }

    void NativeGuiPpfAudio::reanchor(std::uint32_t tick) noexcept {
        anchor_tick_.store(tick, std::memory_order_release);
        anchor_frame_.store(rendered_frames_.load(std::memory_order_acquire), std::memory_order_release);
    }

    void NativeGuiPpfAudio::set_timing(double bpm, std::uint16_t division) noexcept {
        if (std::isfinite(bpm)) bpm_.store(std::clamp(bpm, 30.0, 300.0), std::memory_order_release);
        division_.store(std::max<std::uint16_t>(1, division), std::memory_order_release);
    }

    bool NativeGuiPpfAudio::handle_event(const NativeGuiAudioEvent& event) noexcept {
        const std::uint8_t ch = static_cast<std::uint8_t>(event.status & 0x0Fu);
        const std::uint8_t cmd = static_cast<std::uint8_t>(event.status & 0xF0u);
        if (ch >= 16) return true;

        if (cmd == 0xB0u) {
            if (event.data1 == 0u) msb_[ch] = static_cast<std::uint8_t>(event.data2 & 0x7Fu);
            else if (event.data1 == 32u) lsb_[ch] = static_cast<std::uint8_t>(event.data2 & 0x7Fu);
            else if (ppf_note_engine_.control_change(ch, event.data1, event.data2)) return true;
            return true;
        }
        if (cmd == 0xE0u) {
            if (ppf_note_engine_.pitch_bend(ch, event.data1, event.data2)) return true;
            return true;
        }
        if (cmd == 0xC0u) {
            program_[ch] = static_cast<std::uint8_t>(event.data1 & 0x7Fu);
            return true;
        }
        if (cmd != 0x90u && cmd != 0x80u) return true;

        const bool note_on = cmd == 0x90u && event.data2 > 0;
        const std::uint8_t note = static_cast<std::uint8_t>(event.data1 & 0x7Fu);
        const std::uint8_t velocity = static_cast<std::uint8_t>(event.data2 & 0x7Fu);

        if (note_on) {
            StyleVoiceCall call{};
            call.tick = event.tick;
            call.channel = ch;
            call.msb = msb_[ch];
            call.lsb = lsb_[ch];
            call.program = program_[ch];
            InstalledVoiceResolution resolution;
            std::string error;
            bool ppf_resolved = false;
            if (catalog_.resolve_style_call(call, resolution, error) && resolution.voice &&
                resolution.voice->format == InstalledVoiceFormat::PPF) {
                ppf_resolved = true;
                return ppf_note_engine_.note_on(PpfNoteRequest{
                    resolution.voice->bank_id, resolution.voice->source_index, ch, note, velocity });
            }
            if (ppf_resolved) return true;
            if (!ppf_banks_.empty()) return true;

            if (soundfont_.loaded()) {
                const std::uint16_t bank = (ch == 9u) ? 128u :
                    static_cast<std::uint16_t>((static_cast<std::uint16_t>(msb_[ch]) << 7) | lsb_[ch]);
                const auto* z = soundfont_.choose(bank, program_[ch], note, velocity);
                if (!z || !z->sample) return true;
                const int root = z->root_override >= 0 ? z->root_override : note;
                const double semis = static_cast<double>(note - root) +
                    static_cast<double>(z->coarse_tune) + static_cast<double>(z->fine_tune) / 100.0;
                const double pitch = std::pow(2.0, semis / 12.0);
                const float gain = static_cast<float>(std::pow(10.0, -static_cast<double>(z->attenuation_tenthdB) / 200.0));
                const float pan = std::clamp(static_cast<float>(z->pan_tenths_percent) / 500.0f, -1.0f, 1.0f);
                const std::size_t slot = sampler_.find_reclaimable_slot();
                if (slot == kMaxVoices) return false;
                if (sampler_.voice_active(slot)) {
                    const auto old_part = sampler_.voice_part_index(slot);
                    const auto old_note = sampler_.voice_note(slot);
                    if (old_part < 16u && active_slots_[old_part][old_note] == static_cast<std::int64_t>(slot))
                        active_slots_[old_part][old_note] = -1;
                }
                if (!sampler_.note_on_at_slot(slot, z->sample, note, velocity, gain, pan, pitch,
                    z->loop_start_frame, z->loop_end_frame, z->loop, ch)) return false;
                active_slots_[ch][note] = static_cast<std::int64_t>(slot);
                soundfont_fallback_notes_.fetch_add(1, std::memory_order_relaxed);
            }
        }
        else {
            if (ppf_note_engine_.note_off(ch, note)) return true;
            const auto slot = active_slots_[ch][note];
            if (slot >= 0) {
                if (sampler_.voice_receive_note_off(static_cast<std::size_t>(slot))) {
                    if (sampler_.voice_sustain_held(static_cast<std::size_t>(slot))) sampler_.defer_note_off_slot(static_cast<std::size_t>(slot));
                    else sampler_.note_off_slot(static_cast<std::size_t>(slot));
                    active_slots_[ch][note] = -1;
                }
            }
            else {
                sampler_.note_off(note);
            }
        }
        return true;
    }

    bool NativeGuiPpfAudio::render_audio(float* out_stereo, std::size_t frames, int output_rate) noexcept {
        if (!out_stereo || frames == 0) return true;
        std::fill_n(out_stereo, frames * 2, 0.0f);

        const double bpm = std::clamp(bpm_.load(std::memory_order_acquire), 30.0, 300.0);
        const double fpt = static_cast<double>(output_rate) * 60.0 /
            (bpm * static_cast<double>(std::max<std::uint16_t>(1, division_.load(std::memory_order_acquire))));
        const std::uint64_t base_frame = rendered_frames_.load(std::memory_order_relaxed);
        const std::uint64_t end_frame = base_frame + frames;
        const std::uint32_t anchor_tick = anchor_tick_.load(std::memory_order_acquire);
        const std::uint64_t anchor_frame = anchor_frame_.load(std::memory_order_acquire);

        NativeGuiAudioEvent e{};
        while (pending_.size() < kPendingCapacity && pop(e)) pending_.push_back(e);

        std::size_t produced = 0;
        while (produced < frames) {
            if (!pending_.empty()) {
                const double delta_ticks = static_cast<double>(pending_.front().tick) - static_cast<double>(anchor_tick);
                const auto target = static_cast<std::int64_t>(std::llround(static_cast<double>(anchor_frame) + delta_ticks * fpt));
                const auto current = static_cast<std::int64_t>(base_frame + produced);
                if (target <= current) {
                    if (!handle_event(pending_.front())) return false;
                    pending_.erase(pending_.begin());
                    events_processed_.fetch_add(1, std::memory_order_relaxed);
                    continue;
                }
                const std::size_t until = static_cast<std::size_t>(std::min<std::uint64_t>(
                    static_cast<std::uint64_t>(target - current), frames - produced));
                if (until > 0) {
                    sampler_.render(out_stereo + produced * 2, until, output_rate);
                    produced += until;
                    continue;
                }
            }
            sampler_.render(out_stereo + produced * 2, frames - produced, output_rate);
            produced = frames;
        }

        constexpr float kMasterGain = 0.25f;
        for (std::size_t i = 0; i < frames * 2; ++i) {
            float& s = out_stereo[i];
            if (!std::isfinite(s)) { s = 0.0f; continue; }
            s *= kMasterGain;
            s = std::clamp(s, -1.0f, 1.0f);
        }

        std::uint64_t nz = 0;
        std::uint64_t nf = 0;
        std::uint64_t peak_m = 0;
        for (std::size_t i = 0; i < frames * 2; ++i) {
            const float v = out_stereo[i];
            if (!std::isfinite(v)) { ++nf; continue; }
            if (v != 0.0f) ++nz;
            peak_m = std::max<std::uint64_t>(peak_m, static_cast<std::uint64_t>(std::llround(std::fabs(v) * 1000.0f)));
        }
        nonzero_samples_.fetch_add(nz, std::memory_order_relaxed);
        nonfinite_samples_.fetch_add(nf, std::memory_order_relaxed);
        std::uint64_t cur = nonzero_peak_milli_.load(std::memory_order_relaxed);
        while (cur < peak_m && !nonzero_peak_milli_.compare_exchange_weak(cur, peak_m,
            std::memory_order_release,
            std::memory_order_relaxed)) {
        }
        rendered_frames_.fetch_add(frames, std::memory_order_relaxed);
        active_voices_.store(static_cast<std::uint32_t>(sampler_.active_voice_count()), std::memory_order_release);
        (void)end_frame;
        return true;
    }

#ifdef _WIN32
    bool NativeGuiPpfAudio::open_wasapi(double bpm, std::uint16_t division, std::string& error) {
        wasapi_ = std::make_unique<WasapiState>();
        HRESULT hr = CoInitializeEx(nullptr, COINIT_MULTITHREADED);
        const bool com_owner = SUCCEEDED(hr);
        if (FAILED(hr) && hr != RPC_E_CHANGED_MODE) return hr_error(hr, "CoInitializeEx", error);

        auto finish = [&](bool ok) {
            if (com_owner) CoUninitialize();
            return ok;
            };

        do {
            ComPtr<IMMDeviceEnumerator> en;
            hr = CoCreateInstance(__uuidof(MMDeviceEnumerator), nullptr, CLSCTX_ALL,
                IID_PPV_ARGS(en.GetAddressOf()));
            if (FAILED(hr)) return finish(hr_error(hr, "CoCreateInstance MMDeviceEnumerator", error));
            std::string requested_device = audio_device_id_;
            if (requested_device.empty()) {
                if (const char* env = std::getenv("YAMAHA_WASAPI_DEVICE_ID"); env && *env) requested_device = env;
            }
            if (!requested_device.empty()) {
                int needed = MultiByteToWideChar(CP_UTF8, 0, requested_device.c_str(), -1, nullptr, 0);
                if (needed <= 0) return finish(hr_error(E_INVALIDARG, "audio device UTF-8 conversion", error));
                std::wstring wide(static_cast<std::size_t>(needed), L'\0');
                if (MultiByteToWideChar(CP_UTF8, 0, requested_device.c_str(), -1, wide.data(), needed) <= 0)
                    return finish(hr_error(E_INVALIDARG, "audio device UTF-8 conversion", error));
                hr = en->GetDevice(wide.c_str(), wasapi_->device.GetAddressOf());
                if (FAILED(hr)) return finish(hr_error(hr, "IMMDeviceEnumerator::GetDevice", error));
            }
            else {
                hr = en->GetDefaultAudioEndpoint(eRender, eConsole, wasapi_->device.GetAddressOf());
                if (FAILED(hr)) return finish(hr_error(hr, "GetDefaultAudioEndpoint", error));
            }
            hr = wasapi_->device->Activate(__uuidof(IAudioClient), CLSCTX_ALL, nullptr,
                reinterpret_cast<void**>(wasapi_->client.GetAddressOf()));
            if (FAILED(hr)) return finish(hr_error(hr, "Activate IAudioClient", error));
            hr = wasapi_->client->GetMixFormat(&wasapi_->mix_format);
            if (FAILED(hr)) return finish(hr_error(hr, "GetMixFormat", error));
            output_rate_.store(wasapi_->mix_format->nSamplesPerSec, std::memory_order_release);
            wasapi_->channels = wasapi_->mix_format->nChannels;
            wasapi_->float32 = (wasapi_->mix_format->wFormatTag == WAVE_FORMAT_IEEE_FLOAT) ||
                (wasapi_->mix_format->wFormatTag == WAVE_FORMAT_EXTENSIBLE &&
                    reinterpret_cast<WAVEFORMATEXTENSIBLE*>(wasapi_->mix_format)->SubFormat == kIEEEFloatSubFormat);
            if (!wasapi_->float32 && !(wasapi_->mix_format->wFormatTag == WAVE_FORMAT_PCM && wasapi_->mix_format->wBitsPerSample == 16)) {
                error = "unsupported WASAPI shared-mode mix format";
                return finish(false);
            }
            constexpr REFERENCE_TIME buffer_hns = 100000;
            hr = wasapi_->client->Initialize(AUDCLNT_SHAREMODE_SHARED,
                AUDCLNT_STREAMFLAGS_EVENTCALLBACK,
                buffer_hns, 0, wasapi_->mix_format, nullptr);
            if (FAILED(hr)) return finish(hr_error(hr, "IAudioClient::Initialize", error));
            hr = wasapi_->client->GetBufferSize(&wasapi_->buffer_frames);
            if (FAILED(hr)) return finish(hr_error(hr, "GetBufferSize", error));
            buffer_frames_.store(wasapi_->buffer_frames, std::memory_order_release);
            wasapi_->scratch.resize(static_cast<std::size_t>(wasapi_->buffer_frames) * 2u);
            wasapi_->event = CreateEvent(nullptr, FALSE, FALSE, nullptr);
            if (!wasapi_->event) { error = "CreateEvent failed"; return finish(false); }
            hr = wasapi_->client->SetEventHandle(wasapi_->event);
            if (FAILED(hr)) return finish(hr_error(hr, "SetEventHandle", error));
            hr = wasapi_->client->GetService(IID_PPV_ARGS(wasapi_->render.GetAddressOf()));
            if (FAILED(hr)) return finish(hr_error(hr, "GetService IAudioRenderClient", error));
            set_timing(bpm, division);
            active_.store(true, std::memory_order_release);
            stop_requested_.store(false, std::memory_order_release);
            wasapi_->started = false;
            return finish(true);
        } while (false);
        return finish(false);
    }
#endif

    bool NativeGuiPpfAudio::start(double bpm, std::uint16_t division, std::string& error) {
        if (active_.load(std::memory_order_acquire)) return true;
        if (!ensure_soundfont(error) && ppf_banks_.empty()) return false;
        set_timing(bpm, division);
        rendered_frames_.store(0, std::memory_order_release);
        anchor_tick_.store(0, std::memory_order_release);
        anchor_frame_.store(0, std::memory_order_release);
        nonzero_samples_.store(0, std::memory_order_release);
        nonfinite_samples_.store(0, std::memory_order_release);
        render_deadline_misses_.store(0, std::memory_order_release);
        dropped_events_.store(0, std::memory_order_release);
        events_processed_.store(0, std::memory_order_release);
        max_render_us_.store(0, std::memory_order_release);
        soundfont_fallback_notes_.store(0, std::memory_order_release);
        reset_transport();
        active_voices_.store(0, std::memory_order_release);
#ifdef _WIN32
        if (!open_wasapi(bpm, division, error)) return false;
        audio_thread_ = std::thread([this] { audio_thread_main(); });
        return true;
#elif defined(__ANDROID__)
        oboe::AudioStreamBuilder builder;
        builder.setDirection(oboe::Direction::Output)
            // =======================================================================
            // OBAT ANTI KRESEK 1: Matikan LowLatency agar CPU tidak dijajah
            // =======================================================================
            ->setPerformanceMode(oboe::PerformanceMode::None)
            ->setSharingMode(oboe::SharingMode::Shared)
            ->setFormat(oboe::AudioFormat::Float)
            ->setChannelCount(oboe::ChannelCount::Stereo)
            ->setDataCallback(this);

        const oboe::Result open_result = builder.openStream(android_stream_);
        if (open_result != oboe::Result::OK || !android_stream_) {
            error = std::string("Oboe could not open Android audio output: ") +
                oboe::convertToText(open_result);
            android_stream_.reset();
            return false;
        }

        // =======================================================================
        // OBAT ANTI KRESEK 2: Perbesar kapasitas Buffer 4X LIPAT!
        // Ini memberikan "napas panjang" untuk CPU saat merender polyphony padat.
        // =======================================================================
        int burst_size = android_stream_->getFramesPerBurst();
        android_stream_->setBufferSizeInFrames(burst_size * 4);

        const int sample_rate = android_stream_->getSampleRate();
        if (sample_rate <= 0 || android_stream_->getChannelCount() != 2 ||
            android_stream_->getFormat() != oboe::AudioFormat::Float) {
            error = "Android audio stream did not provide stereo float PCM";
            android_stream_->close();
            android_stream_.reset();
            return false;
        }
        output_rate_.store(static_cast<std::uint32_t>(sample_rate), std::memory_order_release);
        buffer_frames_.store(static_cast<std::uint32_t>(std::max(0, android_stream_->getBufferSizeInFrames())),
            std::memory_order_release);
        set_timing(bpm, division);
        active_.store(true, std::memory_order_release);
        stop_requested_.store(false, std::memory_order_release);
        const oboe::Result start_result = android_stream_->requestStart();
        if (start_result != oboe::Result::OK) {
            error = std::string("Oboe could not start Android audio output: ") +
                oboe::convertToText(start_result);
            active_.store(false, std::memory_order_release);
            android_stream_->close();
            android_stream_.reset();
            return false;
        }
        return true;
#else
        error = "Audio output is supported only on Windows and Android in this build";
        return false;
#endif
    }

#ifdef __ANDROID__
    oboe::DataCallbackResult NativeGuiPpfAudio::onAudioReady(
        oboe::AudioStream* stream, void* audio_data, std::int32_t num_frames) {
        if (!stream || !audio_data || num_frames <= 0 ||
            stop_requested_.load(std::memory_order_acquire)) {
            if (audio_data && num_frames > 0)
                std::fill_n(static_cast<float*>(audio_data), static_cast<std::size_t>(num_frames) * 2u, 0.0f);
            return oboe::DataCallbackResult::Stop;
        }
        const bool ok = render_audio(static_cast<float*>(audio_data),
            static_cast<std::size_t>(num_frames),
            stream->getSampleRate());
        return ok ? oboe::DataCallbackResult::Continue : oboe::DataCallbackResult::Stop;
    }
#endif

    void NativeGuiPpfAudio::audio_thread_main() {
#ifdef _WIN32
        HRESULT start_hr = wasapi_->client->Start();
        if (FAILED(start_hr)) {
            active_.store(false, std::memory_order_release);
            return;
        }
        wasapi_->started = true;
        while (!stop_requested_.load(std::memory_order_acquire)) {
            const DWORD wait = WaitForSingleObject(wasapi_->event, 1000);
            if (wait != WAIT_OBJECT_0) continue;
            UINT32 padding = 0;
            HRESULT hr = wasapi_->client->GetCurrentPadding(&padding);
            if (FAILED(hr)) break;
            const UINT32 frames = wasapi_->buffer_frames > padding ? wasapi_->buffer_frames - padding : 0;
            if (!frames) continue;
            BYTE* data = nullptr;
            hr = wasapi_->render->GetBuffer(frames, &data);
            if (FAILED(hr)) break;
            const auto t0 = std::chrono::steady_clock::now();
            const bool ok = render_audio(wasapi_->scratch.data(), frames, static_cast<int>(output_rate_.load(std::memory_order_acquire)));
            const auto t1 = std::chrono::steady_clock::now();
            const auto us = static_cast<std::uint64_t>(std::chrono::duration_cast<std::chrono::microseconds>(t1 - t0).count());
            auto cur = max_render_us_.load(std::memory_order_relaxed);
            while (cur < us && !max_render_us_.compare_exchange_weak(cur, us,
                std::memory_order_release,
                std::memory_order_relaxed)) {
            }
            const double budget_us = 1000000.0 * static_cast<double>(frames) /
                static_cast<double>(std::max<std::uint32_t>(1, output_rate_.load(std::memory_order_acquire)));
            if (static_cast<double>(us) > budget_us) render_deadline_misses_.fetch_add(1, std::memory_order_relaxed);
            if (!ok) {
                wasapi_->render->ReleaseBuffer(frames, AUDCLNT_BUFFERFLAGS_SILENT);
                break;
            }
            if (wasapi_->float32) {
                float* out = reinterpret_cast<float*>(data);
                for (UINT32 i = 0; i < frames; ++i) {
                    const float l = wasapi_->scratch[static_cast<std::size_t>(i) * 2];
                    const float r = wasapi_->scratch[static_cast<std::size_t>(i) * 2 + 1];
                    for (int c = 0; c < wasapi_->channels; ++c)
                        out[static_cast<std::size_t>(i) * wasapi_->channels + c] = (c == 0 ? l : r);
                }
            }
            else {
                auto* out = reinterpret_cast<std::int16_t*>(data);
                for (UINT32 i = 0; i < frames; ++i) {
                    const float l = wasapi_->scratch[static_cast<std::size_t>(i) * 2];
                    const float r = wasapi_->scratch[static_cast<std::size_t>(i) * 2 + 1];
                    for (int c = 0; c < wasapi_->channels; ++c) {
                        const float s = (c == 0 ? l : r);
                        out[static_cast<std::size_t>(i) * wasapi_->channels + c] =
                            static_cast<std::int16_t>(std::clamp(s, -1.0f, 1.0f) * 32767.0f);
                    }
                }
            }
            if (FAILED(wasapi_->render->ReleaseBuffer(frames, 0))) break;
        }
#endif
        active_.store(false, std::memory_order_release);
    }

    void NativeGuiPpfAudio::close_wasapi() noexcept {
#ifdef _WIN32
        wasapi_.reset();
#endif
    }

    void NativeGuiPpfAudio::stop() noexcept {
        stop_requested_.store(true, std::memory_order_release);
#ifdef _WIN32
        if (wasapi_ && wasapi_->event) SetEvent(wasapi_->event);
#endif
        if (audio_thread_.joinable()) audio_thread_.join();
#ifdef __ANDROID__
        if (android_stream_) {
            (void)android_stream_->requestStop();
            (void)android_stream_->close();
            android_stream_.reset();
        }
#endif
        close_wasapi();
        active_.store(false, std::memory_order_release);
        sampler_.all_notes_off();
    }

    NativeGuiAudioMetrics NativeGuiPpfAudio::metrics() const noexcept {
        NativeGuiAudioMetrics m;
        m.ppf_voice_count = ppf_voice_count_.load(std::memory_order_acquire);
        m.ppf_bank_count = ppf_bank_count_.load(std::memory_order_acquire);
        m.resident_zone_count = resident_zone_count_.load(std::memory_order_acquire);
        m.unique_pcm_count = unique_pcm_count_.load(std::memory_order_acquire);
        m.resident_pcm_bytes = resident_pcm_bytes_.load(std::memory_order_acquire);
        m.active_voices = active_voices_.load(std::memory_order_acquire);
        m.rendered_frames = rendered_frames_.load(std::memory_order_acquire);
        m.nonzero_samples = nonzero_samples_.load(std::memory_order_acquire);
        m.nonfinite_samples = nonfinite_samples_.load(std::memory_order_acquire);
        m.render_deadline_misses = render_deadline_misses_.load(std::memory_order_acquire);
        m.dropped_events = dropped_events_.load(std::memory_order_acquire);
        m.events_processed = events_processed_.load(std::memory_order_acquire);
        m.max_render_us = max_render_us_.load(std::memory_order_acquire);
        m.output_rate = output_rate_.load(std::memory_order_acquire);
        m.buffer_frames = buffer_frames_.load(std::memory_order_acquire);
        if (m.output_rate) m.buffer_latency_ms = 1000.0 * static_cast<double>(m.buffer_frames) / static_cast<double>(m.output_rate);
        m.peak = static_cast<float>(nonzero_peak_milli_.load(std::memory_order_acquire)) / 1000.0f;
        m.active = active_.load(std::memory_order_acquire);
        m.soundfont_loaded = soundfont_.loaded();
        m.soundfont_zone_count = soundfont_.zone_count();
        m.soundfont_sample_count = soundfont_.sample_count();
        m.soundfont_fallback_notes = soundfont_fallback_notes_.load(std::memory_order_acquire);
        return m;
    }

} // namespace arranger