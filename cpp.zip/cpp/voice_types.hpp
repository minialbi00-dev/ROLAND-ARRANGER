#pragma once
#include <cstdint>
#include <memory>
#include <string>
#include <vector>

namespace arranger {
struct ResidentSample {
    // Stable, full source identity for PPF/YEP-backed samples.
    // This is authoritative; uid_numeric is only a compact compatibility key.
    std::string uid_full;
    std::uint64_t uid_numeric = 0;
    int sample_rate = 44100;
    int channels = 1;
    // Interleaved float PCM. channels=1 => mono frames; channels=2 => LRLR...
    std::vector<float> pcm;
    // Sample-level loop metadata is carried by the selected VoiceZone in V0.13.
};
using ResidentSamplePtr = std::shared_ptr<const ResidentSample>;
}
