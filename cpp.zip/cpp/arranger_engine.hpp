#pragma once

#include "yamaha_style_runtime.hpp"

#include <cstdint>
#include <string>
#include <unordered_map>
#include <utility>
#include <vector>

namespace arranger {

struct ArrangerOutputEvent {
    std::uint32_t global_tick = 0;
    std::uint8_t status = 0;
    std::uint8_t data1 = 0;
    std::uint8_t data2 = 0;
    std::uint16_t track = 0;
    std::string section;
};

struct ArrangerSectionState {
    std::string name;
    std::uint32_t start_tick = 0;
    std::uint32_t span = 1;
    std::size_t index = 0;
    std::uint32_t phase = 0;
    bool one_shot = false;
    bool one_shot_done = false;
    std::int64_t last_raw = -1;
    std::uint32_t fill_end = 0;
};

class CppArrangerEngine {
public:
    explicit CppArrangerEngine(const YamahaStyleRuntime& style);
    void set_acmp(bool enabled) noexcept { acmp_enabled_ = enabled; }
    void set_chord(std::uint8_t root_pc, std::uint8_t chord_type, std::uint8_t bass_pc = 0, bool bass_valid = false) noexcept;
    void set_transpose(int semitones) noexcept;
    bool start(std::string& error);
    void stop() noexcept;
    bool queue_main(const std::string& name, std::string& error);
    bool queue_fill(const std::string& name, std::string& error);
    bool queue_intro(const std::string& name, std::string& error);
    bool queue_ending(const std::string& name, std::string& error);
    bool advance_to(std::uint32_t global_tick, std::vector<ArrangerOutputEvent>& out, std::string& error);
    bool running() const noexcept { return running_; }
    bool acmp_enabled() const noexcept { return acmp_enabled_; }
    int transpose() const noexcept { return transpose_; }
    std::uint32_t current_tick() const noexcept { return current_tick_; }
    const std::string& current_section() const noexcept { return current_section_; }
    const std::string& active_main() const noexcept { return active_main_; }
    std::uint32_t bar_ticks() const noexcept { return bar_ticks_; }
    std::uint16_t division() const noexcept { return division_; }

private:
    const YamahaStyleRuntime& style_;
    std::uint16_t division_ = 480;
    std::uint8_t numerator_ = 4;
    std::uint8_t denominator_ = 4;
    std::uint32_t bar_ticks_ = 1920;
    std::string active_main_;
    std::string current_section_;
    std::string intro_return_main_;
    std::string pending_main_;
    std::string pending_fill_;
    std::string pending_ending_;
    std::string fill_destination_;
    bool running_ = false;
    bool acmp_enabled_ = false;
    int transpose_ = 0;
    std::uint8_t chord_root_pc_ = 0;
    std::uint8_t chord_type_ = 0;
    std::uint8_t chord_bass_pc_ = 0;
    bool chord_bass_valid_ = false;
    std::unordered_map<int, std::uint8_t> voice_msb_;
    std::unordered_map<int, std::uint8_t> voice_lsb_;
    std::unordered_map<int, std::uint8_t> voice_program_;
    ArrangerSectionState main_state_{};
    ArrangerSectionState fill_state_{};
    bool has_fill_ = false;
    std::uint32_t current_tick_ = 0;
    bool scheduler_initialized_ = false;
    bool ending_completed_ = false;
    std::unordered_map<std::uint64_t, std::uint8_t> acmp_note_map_;

    static std::string normalize_section(const std::string& name);
    static bool is_note_on(const YamahaStyleMidiEvent& e) noexcept;
    static bool is_note_off(const YamahaStyleMidiEvent& e) noexcept;
    static bool is_rhythm_role(const std::string& role);
    const YamahaStyleCasmRule* find_rule(const std::string& section, std::uint8_t source_ch) const noexcept;
    bool is_rhythm_event(const YamahaStyleMidiEvent& e, const std::string& section) const;
    std::uint8_t logical_channel(const YamahaStyleMidiEvent& e, const std::string& section) const noexcept;
    ArrangerSectionState load_state(const std::string& name, std::uint32_t start_tick, std::uint32_t phase) const;
    // filter_mode: 0=all, 1=rhythm-only, 2=melodic-only, 3=suppress-all.
    void process_state(ArrangerSectionState& state, std::uint32_t until_tick, std::uint8_t filter_mode, std::vector<ArrangerOutputEvent>& out);
    void emit_event(const YamahaStyleMidiEvent& e, const std::string& section, std::uint32_t global_tick, std::vector<ArrangerOutputEvent>& out);
    std::string fill_destination_for(const std::string& fill) const;
    bool section_exists(const std::string& name) const noexcept;
};

} // namespace arranger
