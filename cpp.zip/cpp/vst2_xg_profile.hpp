#pragma once

#include "vst2_legacy_abi.hpp"

#include <array>
#include <cstddef>
#include <cstdint>
#include <cstring>

namespace xgprofile {

// Yamaha XG System On: resets the tone generator into XG mode.
// Documented sequence: F0 43 10 4C 00 00 7E 00 F7.
constexpr std::array<std::uint8_t, 9> kXgSystemOn = {
    0xF0, 0x43, 0x10, 0x4C, 0x00, 0x00, 0x7E, 0x00, 0xF7
};

constexpr std::array<std::uint8_t, 6> kGmSystemOn = {
    0xF0, 0x7E, 0x7F, 0x09, 0x01, 0xF7
};

inline void fill_sysex_event(vst2mini::VstSysExEvent& event,
                             char* storage,
                             std::size_t storage_size,
                             const std::uint8_t* bytes,
                             std::size_t byte_count,
                             vst2mini::VstInt32 delta_frames = 0) noexcept {
    std::memset(&event, 0, sizeof(event));
    event.type = vst2mini::kVstSysExType;
    event.byteSize = sizeof(event);
    event.deltaFrames = delta_frames;
    const std::size_t n = (bytes && storage && storage_size > 0)
        ? (byte_count < storage_size ? byte_count : storage_size)
        : 0;
    if (n > 0) {
        std::memcpy(storage, bytes, n);
        event.dumpBytes = static_cast<vst2mini::VstInt32>(n);
        event.sysexDump = storage;
    }
}

} // namespace xgprofile
