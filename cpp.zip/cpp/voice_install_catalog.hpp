#pragma once
#include "ppf_reader.hpp"
#include "ppf_voice_bank.hpp"
#include "style_voice_router.hpp"
#include "yep_reader.hpp"
#include <cstddef>
#include <cstdint>
#include <string>
#include <vector>

namespace arranger {

enum class InstalledVoiceFormat { PPF, YEP };

struct InstalledVoiceAddress {
    std::uint8_t msb = 0;
    std::uint8_t lsb = 0;
    std::uint8_t program = 0;
};

struct YepInstallMapping {
    std::size_t voice_index = 0;
    InstalledVoiceAddress address{63, 62, 0};
};

struct InstalledBankRecord {
    std::size_t bank_id = 0;
    InstalledVoiceFormat format = InstalledVoiceFormat::PPF;
    std::string title;
    std::string source_path;
    InstalledVoiceAddress installed_base{63, 62, 0};
    std::size_t voice_count = 0;
};

struct InstalledVoiceRecord {
    InstalledVoiceFormat format = InstalledVoiceFormat::PPF;
    std::size_t bank_id = 0;
    std::size_t source_index = 0;
    std::string title;
    std::string source_identity;
    std::string source_path;
    InstalledVoiceAddress source_address{};
    InstalledVoiceAddress installed_address{};
    bool source_address_valid = false;
    bool installed_address_valid = false;
    std::size_t zone_count = 0;
};

struct InstalledVoiceResolution {
    StyleVoiceCall call{};
    const InstalledVoiceRecord* voice = nullptr;
    // The incoming Style address can be expressed either in the installed
    // namespace (e.g. 63/62/PC) or as the original PPF source address
    // (e.g. 62/3/PC). In both cases the resolved Voice carries the canonical
    // installed address below. This makes source->installed translation
    // explicit without mutating the PPF source descriptor.
    InstalledVoiceAddress installed_address{};
    bool installed_address_valid = false;
    bool mapped_to_installed = false;
    bool installed_exact = false;
    bool source_exact = false;
};

class InstalledVoiceCatalog {
public:
    void clear() noexcept;

    // Product path: append a manually installed PPF bank. The caller supplies
    // the installed Yamaha-style MSB/LSB slot; this is never hardwired to one
    // PPF file or silently replaced by a new installation.
    bool install_ppf(const PpfReader& reader,
                     const std::string& source_path,
                     InstalledVoiceAddress installed_base,
                     std::string& error,
                     std::size_t* out_bank_id = nullptr);

    // Compatibility helper for existing V0.60 probes. It installs one bank in
    // the legacy test slot, but the GUI/product layer does not auto-call it.
    bool install_ppf(const PpfReader& reader, std::string& error);

    bool install_yep(const YepReader& reader,
                     const std::vector<YepInstallMapping>& mappings,
                     const std::string& source_path,
                     std::string& error,
                     std::size_t* out_bank_id = nullptr);

    bool install_yep(const YepReader& reader,
                     const std::vector<YepInstallMapping>& mappings,
                     std::string& error);

    std::size_t bank_count() const noexcept { return banks_.size(); }
    std::size_t ppf_bank_count() const noexcept;
    // Roll back one previously installed bank by id. Product code uses this
    // only when a later residency step fails after catalog commit.
    bool remove_bank(std::size_t bank_id) noexcept;
    const std::vector<InstalledBankRecord>& banks() const noexcept { return banks_; }
    const std::vector<InstalledVoiceRecord>& voices() const noexcept { return voices_; }

    const InstalledVoiceRecord* find_installed(const InstalledVoiceAddress& address) const noexcept;
    std::vector<InstalledVoiceRecord> bank_voice_records(std::size_t bank_id) const;
    const InstalledVoiceRecord* find_source(const InstalledVoiceAddress& address) const noexcept;
    const InstalledVoiceRecord* find_bank_voice(std::size_t bank_id, std::size_t source_index) const noexcept;

    bool resolve_style_call(const StyleVoiceCall& call,
                            InstalledVoiceResolution& out,
                            std::string& error) const;

private:
    std::vector<InstalledBankRecord> banks_;
    std::vector<InstalledVoiceRecord> voices_;
    std::size_t next_bank_id_ = 1;

    static bool address_equal(const InstalledVoiceAddress& a,
                              const InstalledVoiceAddress& b) noexcept;
    static std::string ppf_identity(const PpfVoiceDescriptor& v);
    static std::string yep_identity(const YepVoiceDescriptor& v);
    bool has_installed_address_conflict(const InstalledVoiceAddress& address) const noexcept;
};

} // namespace arranger
