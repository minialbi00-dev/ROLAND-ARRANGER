#pragma once

#include <cstddef>
#include <cstdint>

namespace arranger::casm {

struct Slot {
    std::uint8_t ntr = 0;
    std::uint8_t ntt = 0;
    std::uint8_t high_key = 127;
    std::uint8_t note_lo = 0;
    std::uint8_t note_hi = 127;
    std::uint8_t rtr = 0;
};

struct Rule {
    std::uint8_t source_root = 0;
    std::uint8_t source_type = 0;
    std::uint8_t destination_channel = 0;
    const Slot* slots = nullptr;
    std::size_t slot_count = 0;
};

// Exact behavioral port of the locked Python YamahaChordMapper.transform().
// Bass parameters are accepted for ABI symmetry but are intentionally not
// used because the locked Python path does not use them in this transform.
bool transform_note(const Rule& rule,
                    std::uint8_t input_note,
                    std::uint8_t chord_root_pc,
                    std::uint8_t chord_type,
                    std::uint8_t chord_bass_pc,
                    bool chord_bass_valid,
                    std::uint8_t& output_note) noexcept;

} // namespace arranger::casm
