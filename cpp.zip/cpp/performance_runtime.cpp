#include "performance_runtime.hpp"

#include <algorithm>
#include <array>
#include <set>
#include <string>

namespace arranger {

namespace {

// The arranger engine currently consumes seven transformation families.
// Fingering detection can still recognize richer Yamaha chord names, while
// family_type keeps the existing CASM/NTT path stable:
// 0 major, 1 minor, 2 dominant 7, 3 major 7, 4 minor 7, 5 diminished, 6 augmented.
struct ChordPattern {
    const char* suffix;
    int family_type;
    std::array<int, 6> required{};
    std::size_t required_count = 0;
    std::array<int, 3> optional{};
    std::size_t optional_count = 0;
    int priority = 0;
};

// PSR-SX920 Reference Manual / Data List: notes in parentheses are optional.
// 1+5 / 1+8 are handled as explicit two-note shortcuts because Yamaha lists
// them separately from the typed three-or-more-note chord table.
constexpr std::array<ChordPattern, 36> kChordPatterns = {{
    // Yamaha PSR-SX920 Reference Manual p.9. Notes in parentheses are optional.
    // Recognition notes are encoded exactly as the manual's fingering formula;
    // Normal Voicing is NOT used as the recognition rule.
    {"",          0, {{0,4,7,0,0,0}},             3, {{}},               0, 10}, // 1+3+5
    {"6",         0, {{0,7,9,0,0,0}},             3, {{4}},              1, 26}, // 1+(3)+5+6
    {"M7",        3, {{0,4,11,0,0,0}},            3, {{7}},              1, 34}, // 1+3+(5)+7
    {"M7(b5)",    3, {{0,4,6,11,0,0}},          4, {{}},               0, 35}, // 1+3+b5+7
    {"M7(#11)",   3, {{0,4,6,7,11,0}},          5, {{2}},              1, 43}, // 1+(9)+3+#4+5+7
    {"add9",      0, {{0,2,4,7,0,0}},            4, {{}},               0, 38}, // 1+9+3+5
    {"M7(9)",      3, {{0,2,4,11,0,0}},          4, {{7}},              1, 41}, // 1+9+3+(5)+7
    {"6(9)",       0, {{0,2,4,9,0,0}},           4, {{7}},              1, 40}, // 1+9+3+(5)+6
    {"b5",        0, {{0,4,6,0,0,0}},             3, {{}},               0, 29}, // 1+3+b5
    {"aug",       6, {{0,4,8,0,0,0}},             3, {{}},               0, 30}, // 1+3+#5
    {"7aug",      2, {{0,4,8,10,0,0}},           4, {{}},               0, 38}, // 1+3+#5+b7
    {"M7aug",     3, {{0,8,11,0,0,0}},            3, {{4}},              0, 39}, // 1+(3)+#5+7
    {"m",         1, {{0,3,7,0,0,0}},             3, {{}},               1, 11}, // 1+b3+5
    {"m6",        1, {{0,3,7,9,0,0}},            4, {{}},               0, 27}, // 1+b3+5+6
    {"m7",        4, {{0,3,10,0,0,0}},            3, {{7}},              1, 33}, // 1+b3+(5)+b7
    {"m7(b5)",    4, {{0,3,6,10,0,0}},          4, {{}},               0, 36}, // 1+b3+b5+b7
    {"m add9",      1, {{0,2,3,7,0,0}},          4, {{}},               0, 31}, // 1+9+b3+5
    {"m7(9)",     4, {{0,2,3,10,0,0}},           4, {{7}},              0, 42}, // 1+9+b3+(5)+b7
    {"m7(11)",    4, {{0,3,5,7,0,0}},            4, {{2,10}},            0, 44}, // 1+(9)+b3+4+5+(b7)
    {"mM7(b5)",   3, {{0,3,6,11,0,0}},           4, {{}},               0, 37}, // 1+b3+b5+7
    {"mM7",       3, {{0,3,11,0,0,0}},            3, {{7}},              0, 40}, // 1+b3+(5)+7
    {"mM7(9)",    3, {{0,2,3,11,0,0}},           4, {{7}},              0, 45}, // 1+9+b3+(5)+7
    {"dim",       5, {{0,3,6,0,0,0}},             3, {{}},               0, 30}, // 1+b3+b5
    {"dim7",      5, {{0,3,6,9,0,0}},            4, {{}},               0, 37}, // 1+b3+b5+bb7
    {"7",         2, {{0,4,10,0,0,0}},            3, {{7}},              1, 32}, // 1+3+(5)+b7
    {"7sus4",     2, {{0,5,7,10,0,0}},          4, {{}},               0, 35}, // 1+4+5+b7
    {"7(9)",      2, {{0,2,4,10,0,0}},           4, {{7}},              0, 40}, // 1+9+3+(5)+b7
    {"7(#11)",    2, {{0,4,6,7,10,0}},          5, {{2}},              0, 45}, // 1+(9)+3+#11+5+b7
    {"7(13)",     2, {{0,4,9,10,0,0}},           4, {{7}},              0, 39}, // 1+3+(5)+13+b7
    {"7(b5)",     2, {{0,4,6,10,0,0}},           4, {{}},               0, 38}, // 1+3+b5+b7
    {"7(b9)",     2, {{0,1,4,10,0,0}},           4, {{7}},              0, 40}, // 1+b9+3+(5)+b7
    {"7(b13)",    2, {{0,4,7,8,10,0}},           5, {{}},               0, 45}, // 1+3+5+b13+b7
    {"7(#9)",     2, {{0,3,4,10,0,0}},           4, {{7}},              0, 45}, // 1+#9+3+(5)+b7
    {"sus4",      0, {{0,5,7,0,0,0}},             3, {{}},               0, 28}, // 1+4+5
    {"sus2",      0, {{0,2,7,0,0,0}},             3, {{}},               0, 28}, // 1+2+5
    {"Cancel",    0, {{0,1,2,0,0,0}},             3, {{}},              60}, // 1+b2+2
}};

constexpr std::array<const char*, 12> kNames = {
    "C", "C#", "D", "Eb", "E", "F", "F#", "G", "Ab", "A", "Bb", "B"
};

// Smart Chord tables from the PSR-SX920 Reference Manual. The selected key
// supplies the tonic; each pressed degree is converted to the listed chord.
struct SmartSpec {
    int root_offset = -1;       // semitone offset from the Smart Chord key.
    int family_type = 0;
    const char* suffix = "";
    bool slash_pressed_as_bass = false;
};

constexpr std::array<SmartSpec, 12> kSmartMajorStandard = {{
    {0,0,"",false}, {1,5,"dim",false}, {2,1,"m",false}, {3,0,"",false},
    {4,1,"m",false}, {5,0,"",false}, {6,5,"dim",false}, {7,2,"7",false},
    {8,5,"dim",false}, {9,1,"m",false}, {10,0,"",false}, {7,2,"7",true}
}};
constexpr std::array<SmartSpec, 12> kSmartMajorPop = {{
    {0,0,"add9",false}, {1,5,"dim7",false}, {2,4,"m7",false}, {3,5,"dim7",false},
    {4,4,"m7",false}, {5,3,"M7",false}, {6,5,"dim",false}, {7,2,"7",false},
    {8,5,"dim",false}, {9,4,"m7",false}, {10,0,"",false}, {7,2,"7",true}
}};
constexpr std::array<SmartSpec, 12> kSmartMajorJazz = {{
    {0,3,"M7(9)",false}, {1,5,"dim7",false}, {2,4,"m7(9)",false}, {3,5,"dim7",false},
    {4,4,"m7",false}, {5,0,"6(9)",false}, {6,5,"dim7",false}, {7,2,"7(9)",false},
    {8,5,"dim",false}, {9,4,"m7(11)",false}, {10,2,"7",false}, {11,4,"m7b5",false}
}};
constexpr std::array<SmartSpec, 12> kSmartMajorDance = {{
    {0,0,"",false}, {1,5,"dim",false}, {2,1,"m",false}, {3,0,"",false},
    {4,1,"m",false}, {5,0,"",false}, {6,5,"dim",false}, {7,0,"",false},
    {8,5,"dim",false}, {9,1,"m",false}, {10,0,"",false}, {7,0,"",true}
}};
constexpr std::array<SmartSpec, 12> kSmartMajorBasic = {{
    {0,0,"",false}, {1,5,"dim",false}, {2,1,"m",false}, {3,0,"",false},
    {4,0,"1+5",false}, {5,0,"1+5",false}, {6,5,"dim",false}, {7,2,"7",false},
    {8,5,"dim",false}, {9,0,"",false}, {10,0,"",false}, {7,2,"7",true}
}};

constexpr std::array<SmartSpec, 12> kSmartMinorStandard = {{
    {0,1,"m",false}, {1,0,"",false}, {2,4,"m7b5",false}, {3,0,"",false},
    {4,5,"dim",false}, {5,1,"m",false}, {6,5,"dim7",false}, {7,2,"7",false},
    {8,0,"",false}, {9,5,"dim",false}, {10,2,"7",false}, {7,2,"7",true}
}};
constexpr std::array<SmartSpec, 12> kSmartMinorPop = {{
    {0,4,"m7",false}, {1,0,"",false}, {10,0,"",true}, {3,0,"",false},
    {4,5,"dim7",false}, {5,4,"m7",false}, {6,5,"dim7",false}, {7,2,"7",false},
    {8,3,"M7",false}, {9,5,"dim",false}, {10,2,"7",false}, {7,2,"7",true}
}};
constexpr std::array<SmartSpec, 12> kSmartMinorJazz = {{
    {0,1,"m add9",false}, {1,2,"7",false}, {2,4,"m7b5",false}, {3,3,"M7(9)",false},
    {4,5,"dim7",false}, {5,4,"m7(9)",false}, {6,5,"dim7",false}, {7,2,"7",false},
    {8,3,"M7(9)",false}, {9,4,"m7b5",false}, {10,2,"7(9)",false}, {11,2,"7",false}
}};
constexpr std::array<SmartSpec, 12> kSmartMinorDance = {{
    {0,1,"m",false}, {1,0,"",false}, {2,1,"m",false}, {3,1,"m",false},
    {4,1,"m",false}, {5,1,"m",false}, {6,1,"m",false}, {7,1,"m",false},
    {8,1,"m",false}, {9,1,"m",false}, {10,1,"m",false}, {11,0,"",false}
}};
constexpr std::array<SmartSpec, 12> kSmartMinorBasic = {{
    {0,1,"m",false}, {1,0,"",false}, {2,4,"m7b5",false}, {3,0,"",false},
    {4,5,"dim7",false}, {5,1,"m",false}, {6,5,"dim7",false}, {7,0,"1+5",false},
    {8,0,"",false}, {9,5,"dim",false}, {10,2,"7",false}, {7,2,"7",true}
}};

template <typename T>
const T& smart_table(std::uint8_t smart_type, bool minor) noexcept {
    static const std::array<const T*, 5> major_tables = {{
        &kSmartMajorStandard, &kSmartMajorPop, &kSmartMajorJazz,
        &kSmartMajorDance, &kSmartMajorBasic
    }};
    static const std::array<const T*, 5> minor_tables = {{
        &kSmartMinorStandard, &kSmartMinorPop, &kSmartMinorJazz,
        &kSmartMinorDance, &kSmartMinorBasic
    }};
    const auto idx = std::min<std::size_t>(smart_type, 4u);
    return *(minor ? minor_tables[idx] : major_tables[idx]);
}

constexpr std::array<int, 7> kMajorScale = {{0,2,4,5,7,9,11}};
constexpr std::array<int, 7> kMinorNaturalScale = {{0,2,3,5,7,8,10}};

int normalize_pc_local(int pc) noexcept {
    pc %= 12;
    if (pc < 0) pc += 12;
    return pc;
}

enum class InversionConstraint : std::uint8_t {
    Any = 0,
    RootPositionOnly = 1,
    ExceptFirstInversion = 2,
    ExceptSecondInversion = 3,
};

InversionConstraint inversion_constraint_for_suffix(const char* suffix) noexcept {
    const std::string s = suffix ? std::string(suffix) : std::string();
    if (s == "6" || s == "6(9)" || s == "aug" || s == "m6" ||
        s == "dim7" || s == "sus4" || s == "sus2")
        return InversionConstraint::RootPositionOnly;
    if (s == "m7" || s == "m7(b5)" || s == "m7(9)" || s == "m7(11)")
        return InversionConstraint::ExceptFirstInversion;
    if (s == "b5")
        return InversionConstraint::ExceptSecondInversion;
    return InversionConstraint::Any;
}

bool inversion_allowed(const char* suffix, int root_pc, const std::vector<std::uint8_t>& notes) noexcept {
    const auto rule = inversion_constraint_for_suffix(suffix);
    if (rule == InversionConstraint::Any || notes.empty()) return true;
    const int lowest_interval = normalize_pc_local(static_cast<int>(notes.front()) - root_pc);
    switch (rule) {
        case InversionConstraint::RootPositionOnly:
            return lowest_interval == 0;
        case InversionConstraint::ExceptFirstInversion:
            return lowest_interval != 3; // b3 in the bass = 1st inversion for m7-family shapes
        case InversionConstraint::ExceptSecondInversion:
            return lowest_interval != 6; // b5 in the bass = 2nd inversion for the b5 triad
        default:
            return true;
    }
}

int degree_index_for_pc(int pc, int key_pc, bool minor) noexcept {
    const auto& scale = minor ? kMinorNaturalScale : kMajorScale;
    const int rel = normalize_pc_local(pc - key_pc);
    for (int i = 0; i < static_cast<int>(scale.size()); ++i) {
        if (scale[static_cast<std::size_t>(i)] == rel) return i;
    }
    return -1;
}

int scale_pc(int key_pc, int degree, bool minor) noexcept {
    const auto& scale = minor ? kMinorNaturalScale : kMajorScale;
    if (degree < 0) degree = 0;
    degree %= static_cast<int>(scale.size());
    return normalize_pc_local(key_pc + scale[static_cast<std::size_t>(degree)]);
}

} // namespace

int PerformanceRuntime::normalize_pc(int pc) noexcept { return normalize_pc_local(pc); }

std::string PerformanceRuntime::note_name(std::uint8_t note) {
    return std::string(kNames[note % 12]) + std::to_string(static_cast<int>(note) / 12 - 1);
}

const char* PerformanceRuntime::suffix_for_type(int type) noexcept {
    static constexpr std::array<const char*, 7> suffix = {"", "m", "7", "maj7", "m7", "dim", "aug"};
    const auto idx = std::clamp(type, 0, static_cast<int>(suffix.size() - 1));
    return suffix[static_cast<std::size_t>(idx)];
}

int PerformanceRuntime::chord_type_for_suffix(const std::string& suffix) noexcept {
    if (suffix == "m") return 1;
    if (suffix == "7" || suffix == "7(9)" || suffix == "7(b9)" || suffix == "7(#9)" || suffix == "7(#11)" || suffix == "7(13)" || suffix == "7(b13)" || suffix == "7sus4" || suffix == "7aug" || suffix == "7(b5)" || suffix == "7b5") return 2;
    if (suffix == "maj7" || suffix == "M7" || suffix == "M7(b5)" || suffix == "M7b5" || suffix == "M7(#11)" || suffix == "M7(9)" || suffix == "M7aug") return 3;
    if (suffix == "m7" || suffix == "m7(b5)" || suffix == "m7b5" || suffix == "m7(9)" || suffix == "m7(11)" || suffix == "mM7" || suffix == "mM7(b5)" || suffix == "mM7b5" || suffix == "mM7(9)") return 4;
    if (suffix == "dim" || suffix == "dim7") return 5;
    if (suffix == "aug") return 6;
    return 0;
}

const char* PerformanceRuntime::chord_name_for(std::uint8_t root_pc, std::uint8_t chord_type) noexcept {
    static thread_local std::string label;
    label = std::string(kNames[root_pc % 12]) + suffix_for_type(chord_type);
    return label.c_str();
}

const char* PerformanceRuntime::finger_mode_name(std::uint8_t mode) noexcept {
    static constexpr std::array<const char*, 9> names = {{
        "Single Finger", "Fingered", "Fingered On Bass", "Multi Finger",
        "AI Fingered", "Full Keyboard", "AI Full Keyboard", "Smart Chord",
        "Fingered 1/2"
    }};
    const auto idx = std::min<std::size_t>(mode, names.size() - 1);
    return names[idx];
}

const char* PerformanceRuntime::smart_chord_type_name(std::uint8_t type) noexcept {
    static constexpr std::array<const char*, 5> names = {{
        "Standard", "Pop", "Jazz", "Dance", "Basic"
    }};
    return names[std::min<std::size_t>(type, names.size() - 1)];
}

bool PerformanceRuntime::is_black_pc(int pc) noexcept {
    switch (normalize_pc_local(pc)) {
        case 1: case 3: case 6: case 8: case 10: return true;
        default: return false;
    }
}

bool PerformanceRuntime::is_white_pc(int pc) noexcept { return !is_black_pc(pc); }

int PerformanceRuntime::nearest_left_key(int root_note, bool black_key) noexcept {
    if (root_note <= 0) return -1;
    for (int n = root_note - 1; n >= 0 && n >= root_note - 12; --n) {
        if ((black_key && is_black_pc(n)) || (!black_key && is_white_pc(n))) return n;
    }
    return -1;
}

void PerformanceRuntime::reset() noexcept {
    held_.clear();
    state_ = PerformanceRuntimeState{};
    state_.finger_mode = static_cast<std::uint8_t>(PerformanceFingerMode::Fingered);
    state_.split_point = 42; // F#1 (MIDI 42 in Yamaha key naming; Yamaha C3 = MIDI 60).
    state_.smart_chord_key_pc = 0;
    state_.smart_chord_type = 0;
    state_.chord_name = "C";
    have_last_chord_ = false;
    last_root_pc_ = 0;
    last_chord_type_ = 0;
    last_chord_name_ = "C";
}

void PerformanceRuntime::set_transpose(int semitones) noexcept { state_.transpose = std::clamp(semitones, -12, 12); }

void PerformanceRuntime::set_chord(std::uint8_t root_pc, std::uint8_t chord_type, const std::string& chord_name) noexcept {
    state_.chord_root_pc = static_cast<std::uint8_t>(root_pc % 12u);
    state_.chord_type = static_cast<std::uint8_t>(std::min<unsigned>(chord_type, 6u));
    state_.chord_name = chord_name.empty()
        ? (std::string(kNames[state_.chord_root_pc]) + suffix_for_type(state_.chord_type))
        : chord_name;
    state_.chord_bass_valid = true;
    state_.chord_bass_pc = state_.chord_root_pc;
    have_last_chord_ = true;
    last_root_pc_ = state_.chord_root_pc;
    last_chord_type_ = state_.chord_type;
    last_chord_name_ = state_.chord_name;
}

void PerformanceRuntime::set_finger_mode(std::uint8_t mode) noexcept {
    const auto next = static_cast<std::uint8_t>(std::min<unsigned>(mode, 8u));
    const bool changed = state_.finger_mode != next;
    state_.finger_mode = next;

    // A real arranger does not erase the previously confirmed harmony merely
    // because the player changes the fingering policy. Preserve that chord as
    // AI context, but force the *new* policy to re-evaluate the currently held
    // notes. This prevents a stale answer from the old mode from masquerading
    // as a successful recognition in the new mode.
    (void)changed;
    recompute_chord(false);
}

void PerformanceRuntime::set_split_point(int note) noexcept {
    state_.split_point = static_cast<std::uint8_t>(std::clamp(note, 0, 127));
    recompute_chord();
}

void PerformanceRuntime::set_smart_chord_key(int root_pc) noexcept {
    state_.smart_chord_key_pc = static_cast<std::uint8_t>(normalize_pc_local(root_pc));
    recompute_chord();
}

void PerformanceRuntime::set_smart_chord_type(std::uint8_t type) noexcept {
    state_.smart_chord_type = static_cast<std::uint8_t>(std::min<unsigned>(type, 4u));
    recompute_chord();
}

void PerformanceRuntime::set_smart_chord_minor(bool minor) noexcept {
    state_.smart_chord_minor = minor;
    recompute_chord();
}

void PerformanceRuntime::feed_midi(std::uint8_t status, std::uint8_t data1, std::uint8_t data2) noexcept {
    const std::uint8_t cmd = status & 0xF0u;
    if (cmd == 0x90u && data2 != 0u) note_on(data1 & 0x7Fu, data2 & 0x7Fu);
    else if (cmd == 0x80u || (cmd == 0x90u && data2 == 0u)) note_off(data1 & 0x7Fu);
}

void PerformanceRuntime::note_on(std::uint8_t note, std::uint8_t velocity) noexcept {
    if (!state_.note_gate || velocity == 0) return;
    held_.insert(note & 0x7Fu);
    ++state_.note_on_count;
    recompute_chord();
}

void PerformanceRuntime::note_off(std::uint8_t note) noexcept {
    const auto erased = held_.erase(note & 0x7Fu);
    if (erased) ++state_.note_off_count;
    recompute_chord();
}

void PerformanceRuntime::clear_notes() noexcept {
    held_.clear();
    recompute_chord();
}

std::vector<std::uint8_t> PerformanceRuntime::notes_in_detection_area() const {
    std::vector<std::uint8_t> notes;
    const auto mode = static_cast<PerformanceFingerMode>(state_.finger_mode);
    const bool full_keyboard = mode == PerformanceFingerMode::FullKeyboard ||
                               mode == PerformanceFingerMode::AIFullKeyboard;
    notes.reserve(held_.size());
    for (const auto note : held_) {
        if (full_keyboard || static_cast<int>(note) <= static_cast<int>(state_.split_point)) notes.push_back(note);
    }
    return notes;
}

PerformanceRuntime::DetectedChord PerformanceRuntime::detect_single_finger(const std::vector<std::uint8_t>& notes) const noexcept {
    DetectedChord out;
    if (notes.empty() || notes.size() > 3) return out;

    // Yamaha Single Finger is physical-key based: root alone = major;
    // root + white key immediately to its left = 7;
    // root + black key immediately to its left = minor;
    // root + both = minor 7.
    const int root_note = notes.back();
    const int root_pc = root_note % 12;
    const int black_left = nearest_left_key(root_note, true);
    const int white_left = nearest_left_key(root_note, false);
    const bool black_is_left = black_left >= 0;
    const bool white_is_left = white_left >= 0;

    if (notes.size() == 1) {
        out.valid = true;
        out.root_pc = root_pc;
        out.type = 0;
        out.name = std::string(kNames[root_pc]);
        out.bass_note = root_note;
        return out;
    }

    if (notes.size() == 2) {
        if (notes.front() == black_left && black_is_left) {
            out.valid = true; out.root_pc = root_pc; out.type = 1;
        } else if (notes.front() == white_left && white_is_left) {
            out.valid = true; out.root_pc = root_pc; out.type = 2;
        }
    } else if (notes.size() == 3) {
        const bool first_black = notes[0] == black_left && black_is_left;
        const bool second_white = notes[1] == white_left && white_is_left;
        if (first_black && second_white) {
            out.valid = true; out.root_pc = root_pc; out.type = 4;
        }
    }

    if (out.valid) {
        out.name = std::string(kNames[out.root_pc]) + suffix_for_type(out.type);
        out.bass_note = notes.front();
    }
    return out;
}

PerformanceRuntime::DetectedChord PerformanceRuntime::detect_fingered(const std::vector<std::uint8_t>& notes, bool allow_melody_extras, bool suppress_extended) const noexcept {
    DetectedChord best;
    if (notes.empty()) return best;

    // Yamaha Fingered recognizes the explicit 1+8 and 1+5 shortcuts.
    // They are directional: the root is the lower note, not whichever pitch
    // class happens to be first in an arbitrary inversion.
    if (notes.size() == 2) {
        const int lo = notes.front();
        const int hi = notes.back();
        if ((hi - lo) == 12) {
            best.valid = true; best.root_pc = lo % 12; best.type = 0;
            best.name = std::string(kNames[best.root_pc]) + "1+8";
            best.bass_note = lo; return best;
        }
        if ((hi - lo) == 7) {
            best.valid = true; best.root_pc = lo % 12; best.type = 0;
            best.name = std::string(kNames[best.root_pc]) + "1+5";
            best.bass_note = lo; return best;
        }
    }

    std::set<int> pcs;
    for (const auto note : notes) pcs.insert(static_cast<int>(note) % 12);

    // Chord Cancel is exactly 1+b2+2.  All three notes are required.
    if (notes.size() == 3) {
        for (const int candidate_root : pcs) {
            const int b2 = normalize_pc_local(candidate_root + 1);
            const int d2 = normalize_pc_local(candidate_root + 2);
            if (pcs.count(candidate_root) && pcs.count(b2) && pcs.count(d2)) {
                best.valid = true;
                best.root_pc = candidate_root;
                best.type = 0;
                best.name = "Cancel";
                best.bass_note = notes.front();
                return best;
            }
        }
    }

    bool have = false;
    int best_score = -100000;
    int best_extra = 999;
    int best_required = -1;
    int best_priority = -1;
    int best_root = 0;
    int best_type = 0;
    const char* best_suffix = "";

    for (const int candidate_root : pcs) {
        std::set<int> rel;
        for (const int pc : pcs) rel.insert(normalize_pc_local(pc - candidate_root));

        for (const auto& pattern : kChordPatterns) {
            if (suppress_extended) {
                const std::string sx(pattern.suffix);
                if (sx.find("9") != std::string::npos || sx.find("11") != std::string::npos || sx.find("13") != std::string::npos) continue;
            }
            // Full Keyboard treats high notes as possible melody extras. Do
            // not reinterpret a complete major/minor/7th shape containing a
            // third as sus2/sus4 merely because that third is above the split.
            const std::string ps(pattern.suffix);
            if (allow_melody_extras && (ps == "sus2" || ps == "7sus4")) {
                const int third = (ps == "sus2") ? 4 : 4;
                const int minor_third = 3;
                if (rel.count(third) || rel.count(minor_third)) continue;
            }
            bool required_ok = true;
            for (std::size_t i = 0; i < pattern.required_count; ++i) {
                if (!rel.count(pattern.required[i])) { required_ok = false; break; }
            }
            if (!required_ok) continue;
            // Yamaha Data List has explicit inversion restrictions for several
            // chord types (for example C6 is root-position-only; m7 excludes
            // first inversion; b5 excludes second inversion). Apply those
            // restrictions before scoring candidates, otherwise a perfectly
            // valid inversion can be mislabeled as a different chord.
            if (!inversion_allowed(pattern.suffix, candidate_root, notes)) continue;

            int extras = 0;
            int optional_present = 0;
            bool illegal = false;
            for (const int x : rel) {
                bool covered = false;
                for (std::size_t i = 0; i < pattern.required_count; ++i) if (pattern.required[i] == x) { covered = true; break; }
                if (!covered) {
                    for (std::size_t i = 0; i < pattern.optional_count; ++i) if (pattern.optional[i] == x) { covered = true; ++optional_present; break; }
                }
                if (!covered) { ++extras; if (!allow_melody_extras) illegal = true; }
            }
            if (illegal) continue;

            // A strict Fingered recognition should not accept an arbitrary
            // subset of a richer chord when a more specific pattern matches.
            // Root must be selected by the chord formula, not by the lowest
            // physical key. Fingered On Bass applies the lowest key only after
            // the chord root/type has been determined. For Full Keyboard this
            // is essential because the lowest key may be a separate bass note.
            const int root_is_lowest_bonus = (!allow_melody_extras &&
                                               candidate_root == static_cast<int>(notes.front()) % 12)
                ? 70 : 0;
            const int score = pattern.required_count * 100
                            + optional_present * 20
                            + pattern.priority
                            + root_is_lowest_bonus
                            - extras * (allow_melody_extras ? 60 : 100);
            const bool better = !have || score > best_score ||
                (score == best_score && extras < best_extra) ||
                (score == best_score && extras == best_extra &&
                 static_cast<int>(pattern.required_count) > best_required) ||
                (score == best_score && extras == best_extra &&
                 static_cast<int>(pattern.required_count) == best_required &&
                 pattern.priority > best_priority) ||
                (score == best_score && extras == best_extra &&
                 static_cast<int>(pattern.required_count) == best_required &&
                 pattern.priority == best_priority && candidate_root < best_root);
            if (!better) continue;

            have = true;
            best_score = score;
            best_extra = extras;
            best_required = static_cast<int>(pattern.required_count);
            best_priority = pattern.priority;
            best_root = candidate_root;
            best_type = pattern.family_type;
            best_suffix = pattern.suffix;
        }
    }

    if (!have) return best;
    best.valid = true;
    best.root_pc = best_root;
    best.type = best_type;
    best.name = std::string(kNames[best_root]) + best_suffix;
    best.bass_note = notes.front();
    return best;
}

PerformanceRuntime::DetectedChord PerformanceRuntime::detect_smart_chord(const std::vector<std::uint8_t>& notes) const noexcept {
    DetectedChord out;
    if (notes.empty()) return out;

    // Yamaha Smart Chord is a one-key degree trigger. The uppermost pressed
    // key is used as the trigger while the table determines actual chord root,
    // quality, and (for "V on VII") bass note.
    const int pressed_pc = notes.back() % 12;
    const bool minor_key = state_.smart_chord_minor;
    const auto& table = smart_table<std::array<SmartSpec,12>>(state_.smart_chord_type, minor_key);
    const int rel = normalize_pc_local(pressed_pc - state_.smart_chord_key_pc);
    const SmartSpec spec = table[static_cast<std::size_t>(rel)];

    const int chord_root = normalize_pc_local(state_.smart_chord_key_pc + spec.root_offset);

    out.valid = true;
    out.root_pc = chord_root;
    out.type = spec.family_type;
    out.name = std::string(kNames[chord_root]);
    if (spec.suffix && *spec.suffix) out.name += spec.suffix;

    // Yamaha Smart Chord normally resolves the actual chord root as its bass.
    // For table entries explicitly marked "V on VII" / "bVII on II", the
    // pressed degree is the slash-bass note.
    const int bass_pc = spec.slash_pressed_as_bass ? pressed_pc : chord_root;
    if (spec.slash_pressed_as_bass) {
        out.name += "/" + std::string(kNames[bass_pc]);
    }
    out.bass_note = bass_pc;
    return out;
}

PerformanceRuntime::DetectedChord PerformanceRuntime::infer_ai(const std::vector<std::uint8_t>& notes, const DetectedChord& strict) const noexcept {
    if (notes.empty()) return strict;

    // Yamaha AI modes are Fingered / Full Keyboard plus context-aware
    // recognition for fewer than three notes. They must not fall back to
    // Single Finger rules.
    if (notes.size() >= 3 || strict.valid) return strict;

    DetectedChord out;
    out.valid = true;

    if (have_last_chord_) {
        const int prev_root = normalize_pc_local(last_root_pc_);

        // Use only the core family tones for context. Optional extensions and
        // alternate chord variants must not make an unrelated single note look
        // like a member of the previous chord.
        static constexpr std::array<std::array<int, 4>, 7> core = {{
            {{0,4,7, -1}},    // Major
            {{0,3,7, -1}},    // Minor
            {{0,4,7,10}},     // 7
            {{0,4,7,11}},     // M7
            {{0,3,7,10}},     // m7
            {{0,3,6, -1}},    // dim
            {{0,4,8, -1}}     // aug
        }};
        const int family = std::clamp(last_chord_type_, 0, 6);
        std::set<int> previous_core;
        for (int interval : core[static_cast<std::size_t>(family)]) {
            if (interval >= 0) previous_core.insert(normalize_pc_local(prev_root + interval));
        }

        bool subset = !previous_core.empty();
        for (const auto note : notes) {
            if (!previous_core.count(static_cast<int>(note) % 12)) {
                subset = false;
                break;
            }
        }
        if (subset) {
            out.root_pc = prev_root;
            out.type = last_chord_type_;
            out.name = last_chord_name_;
            out.bass_note = notes.front();
            return out;
        }

        // Holding the previous root is the strongest direct cue.
        for (const auto note : notes) {
            if (static_cast<int>(note) % 12 == prev_root) {
                out.root_pc = prev_root;
                out.type = last_chord_type_;
                out.name = last_chord_name_;
                out.bass_note = notes.front();
                return out;
            }
        }
    }

    // With a confirmed previous chord, a lone new key is treated as the new
    // chord root while preserving the previous chord quality. This is the
    // useful contextual part of Yamaha's AI description: the previous chord
    // supplies the missing quality information rather than a raw interval
    // heuristic deciding Major/Minor on its own.
    if (have_last_chord_) {
        out.valid = true;
        out.root_pc = static_cast<int>(notes.back()) % 12;
        out.type = last_chord_type_;
        out.name = std::string(kNames[out.root_pc]) + suffix_for_type(out.type);
        out.bass_note = notes.front();
        return out;
    }

    // No prior context: fewer than three notes are not sufficient for a safe
    // AI inference. Do not invent a chord.
    out.valid = false;
    return out;
}

void PerformanceRuntime::apply_detected(const DetectedChord& detected, bool bass_aware) noexcept {
    if (!detected.valid) return;
    state_.chord_root_pc = static_cast<std::uint8_t>(normalize_pc_local(detected.root_pc));
    state_.chord_type = static_cast<std::uint8_t>(std::clamp(detected.type, 0, 6));
    state_.chord_name = detected.name;
    state_.chord_bass_valid = detected.bass_note >= 0;
    state_.chord_bass_pc = static_cast<std::uint8_t>(detected.bass_note >= 0 ? detected.bass_note % 12 : 0);

    // In Fingered mode the root is the bass. In Fingered On Bass / compatibility
    // mode 1/2, the lowest pressed chord-section note is authoritative.
    if (!bass_aware) state_.chord_bass_pc = state_.chord_root_pc;

    have_last_chord_ = true;
    last_root_pc_ = state_.chord_root_pc;
    last_chord_type_ = state_.chord_type;
    last_chord_name_ = state_.chord_name;
}

void PerformanceRuntime::keep_previous_or_major(const std::vector<std::uint8_t>& notes) noexcept {
    if (notes.empty()) {
        state_.chord_root_pc = 0;
        state_.chord_type = 0;
        state_.chord_name = "C";
        state_.chord_bass_valid = false;
        state_.chord_bass_pc = 0;
        return;
    }

    if (have_last_chord_) {
        state_.chord_root_pc = static_cast<std::uint8_t>(last_root_pc_);
        state_.chord_type = static_cast<std::uint8_t>(last_chord_type_);
        state_.chord_name = last_chord_name_;
        state_.chord_bass_valid = true;
        state_.chord_bass_pc = static_cast<std::uint8_t>(notes.front() % 12);
        return;
    }

    // Strict modes must not create a chord/context from an incomplete first
    // voicing. Otherwise the first key can poison the recognition of the
    // actual chord when the remaining keys are added.
    state_.chord_root_pc = 0;
    state_.chord_type = 0;
    state_.chord_name = "No Chord";
    state_.chord_bass_valid = true;
    state_.chord_bass_pc = static_cast<std::uint8_t>(notes.front() % 12);
}

void PerformanceRuntime::recompute_chord(bool preserve_previous_on_invalid) noexcept {
    const auto notes = notes_in_detection_area();
    state_.held_notes = notes;
    state_.chord_bass_valid = !notes.empty();
    state_.chord_bass_pc = notes.empty() ? 0 : static_cast<std::uint8_t>(notes.front() % 12);

    if (notes.empty()) {
        state_.chord_root_pc = 0;
        state_.chord_type = 0;
        state_.chord_name = "C";
        state_.chord_bass_valid = false;
        state_.chord_bass_pc = 0;
        return;
    }

    const auto mode = static_cast<PerformanceFingerMode>(state_.finger_mode);
    DetectedChord detected;
    switch (mode) {
        case PerformanceFingerMode::SingleFinger:
            detected = detect_single_finger(notes);
            break;
        case PerformanceFingerMode::Fingered:
            detected = detect_fingered(notes, false);
            break;
        case PerformanceFingerMode::FingeredOnBass:
            detected = detect_fingered(notes, false);
            break;
        case PerformanceFingerMode::MultiFinger:
            // Yamaha Multi Finger accepts either Fingered or Single Finger.
            // Try the full Fingered vocabulary first so a real 1+5/1+8 or
            // typed chord is never swallowed by the simpler Single Finger
            // interpretation. Fall back to Single Finger only if the full
            // chord is not recognized.
            detected = detect_fingered(notes, false);
            if (!detected.valid) detected = detect_single_finger(notes);
            break;
        case PerformanceFingerMode::AIFingered:
            detected = detect_fingered(notes, false);
            detected = infer_ai(notes, detected);
            break;
        case PerformanceFingerMode::FullKeyboard:
            detected = detect_fingered(notes, true, false);
            break;
        case PerformanceFingerMode::AIFullKeyboard:
            detected = detect_fingered(notes, true, false);
            detected = infer_ai(notes, detected);
            if (detected.valid) {
                const std::string sx = detected.name;
                const bool extended = sx.find("9") != std::string::npos ||
                                      sx.find("11") != std::string::npos ||
                                      sx.find("13") != std::string::npos;
                if (extended) {
                    // Yamaha explicitly states that 9th/11th/13th chords
                    // cannot be played in AI Full Keyboard. Keep the same
                    // root and downgrade only the forbidden extension to the
                    // corresponding base family instead of choosing a
                    // different chord from an alternate root candidate.
                    detected.name = std::string(kNames[normalize_pc_local(detected.root_pc)]) +
                                    suffix_for_type(detected.type);
                }
            }
            break;
        case PerformanceFingerMode::SmartChord:
            detected = detect_smart_chord(notes);
            break;
        case PerformanceFingerMode::Fingered12:
            detected = detect_fingered(notes, false);
            break;
    }

    if (detected.valid) {
        apply_detected(detected,
            mode == PerformanceFingerMode::FingeredOnBass || mode == PerformanceFingerMode::Fingered12 || mode == PerformanceFingerMode::SmartChord);
    } else if (mode == PerformanceFingerMode::AIFingered || mode == PerformanceFingerMode::AIFullKeyboard) {
        apply_detected(infer_ai(notes, detected), false);
    } else {
        if (preserve_previous_on_invalid) {
            keep_previous_or_major(notes);
        } else {
            // No chord is valid under the newly selected strict fingering.
            // Do not leak the previous mode's answer into the new mode.
            state_.chord_root_pc = static_cast<std::uint8_t>(notes.back() % 12);
            state_.chord_type = 0;
            state_.chord_name = "No Chord";
            state_.chord_bass_valid = true;
            state_.chord_bass_pc = static_cast<std::uint8_t>(notes.front() % 12);
        }
    }
}

} // namespace arranger
