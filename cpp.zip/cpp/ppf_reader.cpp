#include "ppf_reader.hpp"
#include <fstream>
#include <iterator>
#include <limits>
#include <new>
#include <cmath>
#include <algorithm>
#include <cstdlib>
#include <string_view>
#include <cctype>


namespace arranger {

std::uint32_t PpfReader::be32(const std::uint8_t* p) noexcept {
    return (static_cast<std::uint32_t>(p[0]) << 24) |
           (static_cast<std::uint32_t>(p[1]) << 16) |
           (static_cast<std::uint32_t>(p[2]) << 8) |
           static_cast<std::uint32_t>(p[3]);
}

bool PpfReader::find_tag4(const std::vector<std::uint8_t>& data,
                          std::size_t begin,
                          std::size_t end,
                          const char tag[4],
                          std::size_t& position) noexcept {
    if (begin > end || end > data.size() || end - begin < 4) return false;
    for (std::size_t p = begin; p + 4 <= end; ++p) {
        if (data[p] == static_cast<std::uint8_t>(tag[0]) &&
            data[p + 1] == static_cast<std::uint8_t>(tag[1]) &&
            data[p + 2] == static_cast<std::uint8_t>(tag[2]) &&
            data[p + 3] == static_cast<std::uint8_t>(tag[3])) {
            position = p;
            return true;
        }
    }
    return false;
}

bool PpfReader::find_field(const std::vector<std::uint8_t>& data,
                           std::size_t begin,
                           std::size_t end,
                           const char tag[4],
                           std::size_t& payload_offset,
                           std::size_t& payload_size) noexcept {
    if (begin > end || end > data.size()) return false;
    std::size_t scan = begin;
    while (scan <= end && end - scan >= 4) {
        std::size_t found = 0;
        // IMPORTANT: do not pass `scan` as both an input and an output
        // argument. That creates an unsequenced read/write of the same
        // scalar object and is undefined behavior in C++.
        if (!find_tag4(data, scan, end, tag, found)) return false;
        scan = found;
        if (scan > end || end - scan < 8) return false;
        const std::uint32_t n = be32(data.data() + scan + 4);
        const std::uint64_t payload_end = static_cast<std::uint64_t>(scan) + 8ull + n;
        if (payload_end <= end) {
            payload_offset = scan + 8;
            payload_size = static_cast<std::size_t>(n);
            return true;
        }
        if (scan == std::numeric_limits<std::size_t>::max()) return false;
        ++scan;
    }
    return false;
}

bool PpfReader::extract_field(const std::vector<std::uint8_t>& blob,
                              const char tag[4],
                              std::vector<std::uint8_t>& payload) {
    std::size_t offset = 0;
    std::size_t size = 0;
    if (!find_field(blob, 0, blob.size(), tag, offset, size)) return false;
    try {
        payload.assign(blob.begin() + static_cast<std::ptrdiff_t>(offset),
                       blob.begin() + static_cast<std::ptrdiff_t>(offset + size));
        return true;
    } catch (const std::bad_alloc&) {
        payload.clear();
        return false;
    }
}

std::string PpfReader::bytes_to_string(const std::vector<std::uint8_t>& v) {
    return bytes_to_string(v, 0, v.size());
}

std::string PpfReader::bytes_to_string(const std::vector<std::uint8_t>& v,
                                       std::size_t offset,
                                       std::size_t length) {
    if (offset > v.size() || length > v.size() - offset) return {};
    std::string s;
    s.reserve(length);
    for (std::size_t i = 0; i < length; ++i) {
        const auto c = v[offset + i];
        if (c == 0) break;
        s.push_back(static_cast<char>(c));
    }
    return s;
}

namespace {

std::string normalize_extension_text(const std::string& input) {
    std::string out;
    out.reserve(input.size());
    for (unsigned char c : input) {
        if (std::isspace(c) || c == '\0') continue;
        out.push_back(static_cast<char>(std::tolower(c)));
    }
    return out;
}

bool find_utf16_xml_start(const std::vector<std::uint8_t>& blob, bool& little_endian, std::size_t& start) noexcept {
    little_endian = true;
    start = 0;
    const std::size_t limit = std::min<std::size_t>(blob.size(), 4096u);
    for (std::size_t i = 0; i + 1 < limit; ++i) {
        if (blob[i] == static_cast<std::uint8_t>('<') && blob[i + 1] == 0) {
            little_endian = true;
            start = i;
            return true;
        }
        if (blob[i] == 0 && blob[i + 1] == static_cast<std::uint8_t>('<')) {
            little_endian = false;
            start = i;
            return true;
        }
    }
    return false;
}

std::vector<std::uint8_t> make_xml_search_blob(const std::vector<std::uint8_t>& blob) {
    bool little = true;
    std::size_t start = 0;
    if (!find_utf16_xml_start(blob, little, start)) return blob;

    // Transcode only the XML region. The surrounding PPF binary fields remain
    // untouched and continue to be parsed with the native BLOB helpers.
    std::string utf8;
    utf8.reserve((blob.size() - start) / 2u);
    for (std::size_t i = start; i + 1 < blob.size(); i += 2) {
        const std::uint16_t u = little
            ? static_cast<std::uint16_t>(blob[i] | (static_cast<std::uint16_t>(blob[i + 1]) << 8))
            : static_cast<std::uint16_t>((static_cast<std::uint16_t>(blob[i]) << 8) | blob[i + 1]);
        if (u == 0) continue;
        if (u < 0x80) {
            utf8.push_back(static_cast<char>(u));
        } else if (u < 0x800) {
            utf8.push_back(static_cast<char>(0xC0u | (u >> 6)));
            utf8.push_back(static_cast<char>(0x80u | (u & 0x3Fu)));
        } else {
            utf8.push_back(static_cast<char>(0xE0u | (u >> 12)));
            utf8.push_back(static_cast<char>(0x80u | ((u >> 6) & 0x3Fu)));
            utf8.push_back(static_cast<char>(0x80u | (u & 0x3Fu)));
        }
    }
    return std::vector<std::uint8_t>(utf8.begin(), utf8.end());
}

} // namespace

bool PpfReader::extract_xml_tag(const std::vector<std::uint8_t>& blob,
                                const char* tag,
                                std::string& value,
                                std::size_t start) {
    if (!tag || !*tag) return false;
    bool utf16_little = true;
    std::size_t utf16_start = 0;
    if (find_utf16_xml_start(blob, utf16_little, utf16_start)) {
        (void)utf16_little;
        (void)utf16_start;
        const auto xml_blob = make_xml_search_blob(blob);
        return extract_xml_tag(xml_blob, tag, value, start);
    }
    const std::string open = std::string("<") + tag + ">";
    const std::string close = std::string("</") + tag + ">";
    if (open.empty() || close.empty() || start >= blob.size()) return false;

    auto find_bytes = [&](std::size_t from, const std::string& needle, std::size_t& found) noexcept -> bool {
        if (from > blob.size() || needle.empty() || needle.size() > blob.size() - from) return false;
        const std::size_t last = blob.size() - needle.size();
        for (std::size_t pos = from; pos <= last; ++pos) {
            bool match = true;
            for (std::size_t j = 0; j < needle.size(); ++j) {
                if (blob[pos + j] != static_cast<std::uint8_t>(needle[j])) {
                    match = false;
                    break;
                }
            }
            if (match) {
                found = pos;
                return true;
            }
        }
        return false;
    };

    std::size_t open_pos = 0;
    if (!find_bytes(start, open, open_pos)) return false;
    const std::size_t value_begin = open_pos + open.size();
    if (value_begin > blob.size()) return false;

    std::size_t close_pos = 0;
    if (!find_bytes(value_begin, close, close_pos)) return false;
    if (close_pos < value_begin) return false;

    value.assign(reinterpret_cast<const char*>(blob.data() + value_begin),
                 close_pos - value_begin);
    return true;
}

int PpfReader::parse_int_tag(const std::vector<std::uint8_t>& blob,
                             const char* tag,
                             int fallback) {
    std::string value;
    if (!extract_xml_tag(blob, tag, value)) return fallback;
    try {
        std::size_t used = 0;
        const long x = std::stol(value, &used);
        if (used == 0) return fallback;
        if (x < std::numeric_limits<int>::min() || x > std::numeric_limits<int>::max()) return fallback;
        return static_cast<int>(x);
    } catch (...) {
        return fallback;
    }
}


void PpfReader::close() noexcept {
    std::vector<std::uint8_t>().swap(file_data_);
    std::vector<AudioEntry>().swap(audio_);
    decltype(audio_index_by_uid_)().swap(audio_index_by_uid_);
    std::vector<VoiceEntry>().swap(voices_);
    std::vector<PpfVoiceDescriptor>().swap(voice_descriptors_);
    std::vector<VoiceZone>().swap(voice_zones_);
    summary_ = {};
}

const PpfReader::AudioEntry* PpfReader::find_audio(const std::string& uid) const {
    const auto it = audio_index_by_uid_.find(uid);
    if (it == audio_index_by_uid_.end()) return nullptr;
    const std::size_t index = it->second;
    if (index >= audio_.size()) return nullptr;
    return &audio_[index];
}



double PpfReader::parse_double_tag(const std::vector<std::uint8_t>& blob,
                                   const char* tag,
                                   double fallback) {
    std::string value;
    if (!extract_xml_tag(blob, tag, value)) return fallback;
    const char* first = value.c_str();
    char* end = nullptr;
    const double d = std::strtod(first, &end);
    if (end == first || !std::isfinite(d)) return fallback;
    return d;
}

int PpfReader::parse_midi_note_text(const std::string& value, int fallback) noexcept {
    if (value.empty()) return fallback;
    try {
        std::size_t used = 0;
        const long numeric = std::stol(value, &used);
        if (used == value.size()) return static_cast<int>(std::max<long>(0, std::min<long>(127, numeric)));
    } catch (...) {}
    if (value.size() < 2) return fallback;
    const char n = static_cast<char>(value[0] >= 'a' && value[0] <= 'g' ? value[0] - ('a' - 'A') : value[0]);
    int base = -1;
    switch (n) {
        case 'C': base = 0; break; case 'D': base = 2; break; case 'E': base = 4; break;
        case 'F': base = 5; break; case 'G': base = 7; break; case 'A': base = 9; break; case 'B': base = 11; break;
        default: return fallback;
    }
    std::size_t pos = 1;
    int accidental = 0;
    if (pos < value.size() && (value[pos] == '#' || value[pos] == 'b')) {
        accidental = value[pos] == '#' ? 1 : -1;
        ++pos;
    }
    try {
        const int octave = std::stoi(value.substr(pos));
        return std::max(0, std::min(127, (octave + 2) * 12 + base + accidental));
    } catch (...) {
        return fallback;
    }
}

bool PpfReader::extract_attribute_from_open_tag(const std::vector<std::uint8_t>& blob,
                                                std::size_t open_pos,
                                                std::size_t open_end,
                                                const char* name,
                                                std::string& value) {
    value.clear();
    if (!name || open_pos >= open_end || open_end > blob.size()) return false;
    const std::string needle = std::string(name) + "=";
    for (std::size_t p = open_pos; p + needle.size() <= open_end; ++p) {
        bool match = true;
        for (std::size_t j = 0; j < needle.size(); ++j) {
            if (blob[p + j] != static_cast<std::uint8_t>(needle[j])) { match = false; break; }
        }
        if (!match) continue;
        const std::size_t q = p + needle.size();
        if (q >= open_end || (blob[q] != '"' && blob[q] != '\'')) continue;
        const std::uint8_t quote = blob[q];
        const std::size_t begin = q + 1;
        std::size_t end = begin;
        while (end < open_end && blob[end] != quote) ++end;
        if (end >= open_end) return false;
        value.assign(reinterpret_cast<const char*>(blob.data() + begin), end - begin);
        return true;
    }
    return false;
}

void PpfReader::parse_voice_zones_from_blob(const std::vector<std::uint8_t>& blob,
                                            std::size_t voice_index,
                                            const std::string& title,
                                            std::vector<VoiceZone>& out) {
    struct ElementPitch {
        int lo = 0;
        int hi = 127;
        int note_shift = 0;
        int tune_coarse = 0;
        double tune_fine = 0.0;
        int pitch_scaling_sens = 100;
        int pitch_scaling_center_note = 60;
        int alternate_group = 0;
        bool receive_note_off = true;
        bool receive_note_on = true;
        bool release_only_aeg = false;
        double amplitude_release_rate = 1.0;
    };
    std::unordered_map<int, ElementPitch> element_by_number;

    auto bounded_find = [](const std::vector<std::uint8_t>& data, std::size_t from, std::size_t limit,
                           const std::string& needle, std::size_t& found) noexcept -> bool {
        if (from > limit || limit > data.size() || needle.empty() || needle.size() > limit - from) return false;
        const std::size_t last = limit - needle.size();
        for (std::size_t pos = from; pos <= last; ++pos) {
            bool ok = true;
            for (std::size_t j = 0; j < needle.size(); ++j) if (data[pos+j] != static_cast<std::uint8_t>(needle[j])) { ok = false; break; }
            if (ok) { found = pos; return true; }
        }
        return false;
    };

    std::size_t scan = 0;
    while (true) {
        std::size_t op = 0;
        if (!bounded_find(blob, scan, blob.size(), "<voiceElement", op)) break;
        std::size_t gt = op;
        while (gt < blob.size() && blob[gt] != '>') ++gt;
        if (gt >= blob.size()) break;
        std::string end_tag = "</voiceElement>";
        std::size_t close = 0;
        (void)close;
        // Literal bounded search for the complete element block.
        std::size_t cpos = 0;
        auto find_text = [&](std::size_t from, const std::string& needle, std::size_t& found) noexcept -> bool {
            if (from > blob.size() || needle.empty() || needle.size() > blob.size() - from) return false;
            const std::size_t last = blob.size() - needle.size();
            for (std::size_t pos = from; pos <= last; ++pos) {
                bool ok = true;
                for (std::size_t j = 0; j < needle.size(); ++j) if (blob[pos+j] != static_cast<std::uint8_t>(needle[j])) { ok = false; break; }
                if (ok) { found = pos; return true; }
            }
            return false;
        };
        if (!find_text(op, end_tag, cpos)) break;
        std::vector<std::uint8_t> elem_blob(blob.begin() + static_cast<std::ptrdiff_t>(op),
                                            blob.begin() + static_cast<std::ptrdiff_t>(cpos + end_tag.size()));
        std::string lo_text, hi_text, note_shift_text, elem_center_text;
        extract_xml_tag(elem_blob, "noteLimitLo", lo_text);
        extract_xml_tag(elem_blob, "noteLimitHi", hi_text);
        ElementPitch ep;
        ep.lo = parse_midi_note_text(lo_text, 0);
        ep.hi = parse_midi_note_text(hi_text, 127);
        ep.note_shift = parse_int_tag(elem_blob, "noteShift", 0);
        if (ep.note_shift < -63) ep.note_shift = -63;
        if (ep.note_shift > 63) ep.note_shift = 63;
        // In Yamaha UVF the Element PITCH block's Note Shift/Detune fields are
        // named tuneCoarse/tuneFine. These are independent of the KeyBank's
        // sample tuning and must be accumulated at note-on.
        std::size_t pb_open = 0;
        std::size_t pb_close = 0;
        auto find_bytes = [](const std::vector<std::uint8_t>& data, std::size_t from, const std::string& needle, std::size_t& found) {
            if (needle.empty() || from >= data.size()) return false;
            const auto* b = data.data();
            const std::size_t n = data.size();
            const std::size_t m = needle.size();
            if (m > n || from > n - m) return false;
            for (std::size_t i = from; i <= n - m; ++i) {
                bool ok = true;
                for (std::size_t j = 0; j < m; ++j) {
                    if (b[i + j] != static_cast<std::uint8_t>(needle[j])) { ok = false; break; }
                }
                if (ok) { found = i; return true; }
            }
            return false;
        };
        if (find_bytes(elem_blob, 0, "<pitchBlock", pb_open) &&
            find_bytes(elem_blob, pb_open, "</pitchBlock>", pb_close)) {
            const std::size_t pb_end = pb_close + 13;
            const std::vector<std::uint8_t> pb_blob(
                elem_blob.begin() + static_cast<std::ptrdiff_t>(pb_open),
                elem_blob.begin() + static_cast<std::ptrdiff_t>(std::min(pb_end, elem_blob.size())));
            ep.tune_coarse = parse_int_tag(pb_blob, "tuneCoarse", 0);
            ep.tune_fine = parse_double_tag(pb_blob, "tuneFine", 0.0);
            ep.pitch_scaling_sens = parse_int_tag(pb_blob, "pitchScalingSens", 100);
            ep.pitch_scaling_sens = std::clamp(ep.pitch_scaling_sens, 0, 100);
            extract_xml_tag(pb_blob, "pitchScalingSensCenterNote", elem_center_text);
            ep.pitch_scaling_center_note = parse_midi_note_text(elem_center_text, 60);
        }

        // Drum-key controls live in <drumSetup> in Yamaha UVF. Keep these
        // attached to the owning VoiceElement so a KeyBank/velocity layer can
        // inherit them, while an explicit KeyBank tag may override them below.
        std::size_t ds_open = 0;
        std::size_t ds_close = 0;
        if (find_bytes(elem_blob, 0, "<drumSetup", ds_open) &&
            find_bytes(elem_blob, ds_open, "</drumSetup>", ds_close)) {
            const std::size_t ds_end = ds_close + 12;
            const std::vector<std::uint8_t> ds_blob(
                elem_blob.begin() + static_cast<std::ptrdiff_t>(ds_open),
                elem_blob.begin() + static_cast<std::ptrdiff_t>(std::min(ds_end, elem_blob.size())));
            ep.alternate_group = std::clamp(parse_int_tag(ds_blob, "alternateGroup", 0), 0, 127);
            ep.receive_note_off = parse_int_tag(ds_blob, "rcvNoteOff", 1) != 0;
            ep.receive_note_on = parse_int_tag(ds_blob, "rcvNoteOn", 1) != 0;
        }
        std::size_t osc_open = 0;
        std::size_t osc_close = 0;
        if (find_bytes(elem_blob, 0, "<oscillatorBlock", osc_open) &&
            find_bytes(elem_blob, osc_open, "</oscillatorBlock>", osc_close)) {
            const std::size_t osc_end = osc_close + 19;
            const std::vector<std::uint8_t> osc_blob(
                elem_blob.begin() + static_cast<std::ptrdiff_t>(osc_open),
                elem_blob.begin() + static_cast<std::ptrdiff_t>(std::min(osc_end, elem_blob.size())));
            ep.release_only_aeg = parse_int_tag(osc_blob, "releaseOnlyAEG", 0) != 0;
            std::string release_only_text;
            if (extract_xml_tag(osc_blob, "releaseOnlyAEG", release_only_text)) {
                ep.release_only_aeg = release_only_text == "ON" || release_only_text == "TRUE" || release_only_text == "1" ||
                                      release_only_text == "on" || release_only_text == "true";
            }
        }
        std::size_t ab_open = 0;
        std::size_t ab_close = 0;
        if (find_bytes(elem_blob, 0, "<amplitudeBlock", ab_open) &&
            find_bytes(elem_blob, ab_open, "</amplitudeBlock>", ab_close)) {
            const std::size_t ab_end = ab_close + 17;
            const std::vector<std::uint8_t> ab_blob(
                elem_blob.begin() + static_cast<std::ptrdiff_t>(ab_open),
                elem_blob.begin() + static_cast<std::ptrdiff_t>(std::min(ab_end, elem_blob.size())));
            ep.amplitude_release_rate = parse_double_tag(ab_blob, "releaseRate", 1.0);
            if (!std::isfinite(ep.amplitude_release_rate)) ep.amplitude_release_rate = 1.0;
            ep.amplitude_release_rate = std::clamp(ep.amplitude_release_rate, 0.0, 1.0);
        }
        std::string number_text;
        int element_number = static_cast<int>(element_by_number.size());
        std::size_t open_end = gt + 1;
        if (extract_attribute_from_open_tag(blob, op, open_end, "number", number_text)) {
            try { element_number = std::max(0, std::stoi(number_text)); } catch (...) {}
        }
        element_by_number[element_number] = ep;
        scan = cpos + end_tag.size();
    }

    std::size_t wf_scan = 0;
    std::size_t waveform_index = 0;
    while (true) {
        std::size_t wf_open = 0;
        if (!bounded_find(blob, wf_scan, blob.size(), "<waveform ", wf_open)) break;
        std::size_t wf_gt = 0;
        if (!bounded_find(blob, wf_open, blob.size(), ">", wf_gt)) break;
        std::size_t wf_close = 0;
        if (!bounded_find(blob, wf_gt + 1, blob.size(), "</waveform>", wf_close)) break;
        const std::size_t wf_end = wf_close + 11;
        std::string wf_number_text;
        int waveform_number = static_cast<int>(waveform_index);
        if (extract_attribute_from_open_tag(blob, wf_open, wf_gt + 1, "number", wf_number_text)) {
            try { waveform_number = std::max(0, std::stoi(wf_number_text)); } catch (...) {}
        }
        const auto eit = element_by_number.find(waveform_number);
        const ElementPitch elem = eit != element_by_number.end() ? eit->second : ElementPitch{};
        const int elem_lo = elem.lo;
        const int elem_hi = elem.hi;

        std::size_t kb_scan = wf_gt + 1;
        std::size_t keybank_index = 0;
        while (true) {
            std::size_t kb_open = 0;
            if (!bounded_find(blob, kb_scan, wf_end, "<keybank", kb_open)) break;
            std::size_t kb_gt = 0;
            if (!bounded_find(blob, kb_open, wf_end, ">", kb_gt)) break;
            std::size_t kb_close = 0;
            if (!bounded_find(blob, kb_gt + 1, wf_end, "</keybank>", kb_close)) break;
            const std::size_t kb_end = kb_close + 10;
            std::vector<std::uint8_t> kb_blob(blob.begin() + static_cast<std::ptrdiff_t>(kb_open),
                                              blob.begin() + static_cast<std::ptrdiff_t>(kb_end));
            std::string text;
            std::string voice_type_text;
            extract_xml_tag(blob, "voiceType", voice_type_text);
            const bool is_drum = voice_type_text == "DRUM_KIT";

            extract_xml_tag(kb_blob, "noteLimitLo", text);
            const int kb_key_lo = parse_midi_note_text(text, elem_lo);
            extract_xml_tag(kb_blob, "noteLimitHi", text);
            const int kb_key_hi = parse_midi_note_text(text, elem_hi);
            const int vel_lo = std::max(0, std::min(127, parse_int_tag(kb_blob, "velocityLimitLo", 1)));
            const int vel_hi = std::max(vel_lo, std::min(127, parse_int_tag(kb_blob, "velocityLimitHi", 127)));
            extract_xml_tag(kb_blob, "centerNote", text);
            const int center_note = parse_midi_note_text(text, 60);

            // Yamaha Drum Kit KeyBanks are note-addressed by their owning
            // voiceElement. A drum element whose noteLimitLo == noteLimitHi
            // must remain a single MIDI-note zone; using the KeyBank's broad
            // fallback range would make every drum sample eligible for nearly
            // every MIDI note and causes chaotic/incorrect percussion.
            const int key_lo = (is_drum && elem_lo == elem_hi) ? elem_lo : kb_key_lo;
            const int key_hi = (is_drum && elem_lo == elem_hi) ? elem_hi : kb_key_hi;
            const int root_note = (is_drum && elem_lo == elem_hi) ? elem_lo : center_note;
            // Alternate Group / Note-Off are stored at the KeyBank level when
            // present; otherwise inherit the owning Drum VoiceElement's setup.
            const int alternate_group = std::clamp(parse_int_tag(kb_blob, "alternateGroup", elem.alternate_group), 0, 127);
            const bool receive_note_off = parse_int_tag(kb_blob, "rcvNoteOff", elem.receive_note_off ? 1 : 0) != 0;
            const bool receive_note_on = parse_int_tag(kb_blob, "rcvNoteOn", elem.receive_note_on ? 1 : 0) != 0;
            const int sample_rate = std::max(1, static_cast<int>(std::llround(parse_double_tag(kb_blob, "samplingFrequency", 44100.0))));
            const double volume = parse_double_tag(kb_blob, "volume", 0.0);
            const double pan = parse_double_tag(kb_blob, "pan", 0.0);
            const int tune_coarse = parse_int_tag(kb_blob, "tuneCoarse", 0);
            const double tune_fine = parse_double_tag(kb_blob, "tuneFine", 0.0);

            std::size_t sm_scan = 0;
            while (true) {
                std::size_t sm_open = 0;
                if (!bounded_find(kb_blob, sm_scan, kb_blob.size(), "<sample ", sm_open)) break;
                std::size_t sm_gt = 0;
                if (!bounded_find(kb_blob, sm_open, kb_blob.size(), ">", sm_gt)) break;
                std::size_t sm_close = 0;
                if (!bounded_find(kb_blob, sm_gt + 1, kb_blob.size(), "</sample>", sm_close)) break;
                const std::size_t sm_end = sm_close + 9;
                std::string pos;
                extract_attribute_from_open_tag(kb_blob, sm_open, sm_gt + 1, "position", pos);
                if (pos.empty()) pos = "MONO";
                // Never reuse the previous KeyBank metadata value here. Some
                // Yamaha KeyBanks legitimately omit waveFilePath/waveFile; if
                // text is not cleared, a stale value such as centerNote=G3 is
                // incorrectly installed as a PCM UID.
                text.clear();
                const std::vector<std::uint8_t> sample_blob(
                    kb_blob.begin() + static_cast<std::ptrdiff_t>(sm_open),
                    kb_blob.begin() + static_cast<std::ptrdiff_t>(sm_end));
                extract_xml_tag(sample_blob, "waveFilePath", text);
                if (text.empty()) {
                    extract_xml_tag(sample_blob, "waveFile", text);
                }
                if (!text.empty()) {
                    // The UVF loop-point fields in this PPF are byte offsets for
                    // LINEAR16. Match the locked Python reference: convert bytes to
                    // int16 sample frames exactly once.
                    const int ls_bytes = std::max(0, parse_int_tag(sample_blob, "loopStartPoint", 0));
                    int le_bytes = parse_int_tag(sample_blob, "loopEndPoint", 0);
                    if (le_bytes <= 0) le_bytes = static_cast<int>(std::numeric_limits<int>::max());
                    std::string one_shot_text;
                    std::string fixed_pitch_text;
                    extract_xml_tag(sample_blob, "oneShot", one_shot_text);
                    extract_xml_tag(kb_blob, "fixedPitch", fixed_pitch_text);
                    const auto truthy = [](const std::string& v) noexcept {
                        return v == "ON" || v == "on" || v == "TRUE" || v == "true" || v == "1";
                    };
                    VoiceZone z;
                    z.voice_index = voice_index;
                    z.waveform_index = waveform_index;
                    z.keybank_index = keybank_index;
                    z.voice_title = title;
                    z.sample_uid = text;
                    z.sample_position = pos;
                    z.root_note = root_note;
                    z.key_lo = std::max(0, std::min(127, key_lo));
                    z.key_hi = std::max(z.key_lo, std::min(127, key_hi));
                    z.velocity_lo = vel_lo;
                    z.velocity_hi = vel_hi;
                    z.sample_rate = sample_rate;
                    z.volume = volume;
                    z.pan = pan;
                    z.tune_coarse = tune_coarse;
                    z.tune_fine = tune_fine;
                    z.element_note_shift = elem.note_shift;
                    z.element_tune_coarse = elem.tune_coarse;
                    z.element_tune_fine = elem.tune_fine;
                    z.pitch_scaling_sens = elem.pitch_scaling_sens;
                    z.pitch_scaling_center_note = elem.pitch_scaling_center_note;
                    z.loop_start_frame = ls_bytes / 2;
                    z.loop_end_frame = (le_bytes == std::numeric_limits<int>::max())
                        ? std::numeric_limits<int>::max() / 2
                        : le_bytes / 2;
                    // Yamaha Drum Kit samples are one-shot even when the
                    // individual XML sample node does not explicitly carry
                    // <oneShot>ON</oneShot>. This is required for Style
                    // percussion hits so NOTE OFF never truncates/purges the
                    // sample like a sustained melodic Voice.
                    z.one_shot = truthy(one_shot_text) || is_drum;
                    z.fixed_pitch = truthy(fixed_pitch_text);
                    z.alternate_group = static_cast<std::uint8_t>(alternate_group);
                    z.receive_note_off = receive_note_off;
                    z.receive_note_on = receive_note_on;
                    z.release_only_aeg = elem.release_only_aeg;
                    z.amplitude_release_rate = elem.amplitude_release_rate;
                    out.push_back(std::move(z));
                }
                sm_scan = sm_end;
            }
            kb_scan = kb_end;
            ++keybank_index;
        }
        wf_scan = wf_end;
        ++waveform_index;
    }
}

bool PpfReader::open_audio_only(const std::string& path, std::string& error) {
    error.clear();
    std::ifstream f(path, std::ios::binary);
    if (!f) { error = "cannot open PPF: " + path; return false; }
    f.seekg(0, std::ios::end);
    const auto end = f.tellg();
    if (end <= 0) { error = "PPF is empty"; return false; }
    const auto file_size_u64 = static_cast<unsigned long long>(end);
    if (file_size_u64 > static_cast<unsigned long long>(std::numeric_limits<std::size_t>::max()) ||
        file_size_u64 > static_cast<unsigned long long>(std::numeric_limits<std::streamsize>::max())) {
        error = "PPF too large for this process/stream"; return false;
    }
    const std::size_t file_size = static_cast<std::size_t>(file_size_u64);
    std::vector<std::uint8_t> new_data;
    try { new_data.resize(file_size); }
    catch (const std::bad_alloc&) { error = "not enough RAM to read PPF (bytes=" + std::to_string(file_size) + ")"; return false; }
    f.seekg(0, std::ios::beg);
    if (!new_data.empty()) {
        f.read(reinterpret_cast<char*>(new_data.data()), static_cast<std::streamsize>(new_data.size()));
        if (!f || f.gcount() != static_cast<std::streamsize>(new_data.size())) { error = "failed reading PPF bytes"; return false; }
    }

    std::vector<AudioEntry> new_audio;
    std::size_t p = 0;
    while (p + 8 <= new_data.size()) {
        std::size_t magic = 0;
        if (!find_tag4(new_data, p, new_data.size(), "BLOB", magic)) break;
        p = magic;
        if (p > new_data.size() - 8) break;
        const std::uint32_t n = be32(new_data.data() + p + 4);
        const std::uint64_t blob_end64 = static_cast<std::uint64_t>(p) + 8ull + n;
        if (blob_end64 > new_data.size()) { ++p; continue; }
        const std::size_t blob_end = static_cast<std::size_t>(blob_end64);

        std::size_t ext_off = 0, ext_size = 0;
        if (find_field(new_data, p, blob_end, "EEXT", ext_off, ext_size)) {
            if (bytes_to_string(new_data, ext_off, ext_size) == "APCp") {
                std::size_t uid_off = 0, uid_size = 0, ssnd = 0;
                if (find_field(new_data, p, blob_end, "EUID", uid_off, uid_size) &&
                    find_tag4(new_data, p, blob_end, "SSND", ssnd) &&
                    ssnd <= blob_end && blob_end - ssnd >= 8) {
                    const std::uint32_t ssnd_len = be32(new_data.data() + ssnd + 4);
                    const std::uint64_t raw_start64 = static_cast<std::uint64_t>(ssnd) + 16ull;
                    const std::uint64_t raw_end64 = static_cast<std::uint64_t>(ssnd) + 8ull + ssnd_len;
                    if (raw_start64 <= raw_end64 && raw_end64 <= blob_end) {
                        const std::size_t raw_start = static_cast<std::size_t>(raw_start64);
                        const std::size_t raw_end = static_cast<std::size_t>(raw_end64);
                        const std::size_t raw_bytes = raw_end - raw_start;
                        const std::string uid = bytes_to_string(new_data, uid_off, uid_size);
                        if (!uid.empty() && raw_bytes >= 2 && (raw_bytes & 1u) == 0) {
                            try { new_audio.push_back(AudioEntry{uid, raw_start, raw_bytes}); }
                            catch (const std::bad_alloc&) { error = "not enough RAM while indexing APCp entries"; return false; }
                        }
                    }
                }
            }
        }
        if (blob_end <= p) { error = "internal APCp parser made no forward progress"; return false; }
        p = blob_end;
    }
    if (new_audio.empty()) { error = "PPF contains no APCp PCM audio entries"; return false; }
    file_data_.swap(new_data);
    audio_.swap(new_audio);
    audio_index_by_uid_.clear();
    audio_index_by_uid_.reserve(audio_.size() * 2u);
    for (std::size_t i = 0; i < audio_.size(); ++i) audio_index_by_uid_.emplace(audio_[i].uid, i);
    voices_.clear();
    voice_descriptors_.clear();
    voice_zones_.clear();
    summary_.audio_count = audio_.size();
    summary_.voice_count = 0; // deliberately not parsed in audio-only mode
    summary_.voice_zone_count = 0;
    return true;
}

bool PpfReader::open(const std::string& path, std::string& error) {
    error.clear();

    std::ifstream f(path, std::ios::binary);
    if (!f) {
        error = "cannot open PPF: " + path;
        return false;
    }

    f.seekg(0, std::ios::end);
    const auto end = f.tellg();
    if (end <= 0) {
        error = "PPF is empty";
        return false;
    }

    const auto file_size_u64 = static_cast<unsigned long long>(end);
    if (file_size_u64 > static_cast<unsigned long long>(std::numeric_limits<std::size_t>::max())) {
        error = "PPF too large for this process";
        return false;
    }
    if (file_size_u64 > static_cast<unsigned long long>(std::numeric_limits<std::streamsize>::max())) {
        error = "PPF too large for stream read";
        return false;
    }

    const std::size_t file_size = static_cast<std::size_t>(file_size_u64);
    std::vector<std::uint8_t> new_data;
    try {
        new_data.resize(file_size);
    } catch (const std::bad_alloc&) {
        error = "not enough RAM to read PPF (bytes=" + std::to_string(file_size) + ")";
        return false;
    }

    f.seekg(0, std::ios::beg);
    if (!new_data.empty()) {
        f.read(reinterpret_cast<char*>(new_data.data()), static_cast<std::streamsize>(new_data.size()));
        if (!f || f.gcount() != static_cast<std::streamsize>(new_data.size())) {
            error = "failed reading PPF bytes";
            return false;
        }
    }

    std::vector<AudioEntry> new_audio;
    std::vector<VoiceEntry> new_voices;
    std::vector<PpfVoiceDescriptor> new_voice_descriptors;
    std::vector<VoiceZone> new_voice_zones;

    std::size_t p = 0;
    while (p + 8 <= new_data.size()) {
        std::size_t blob_magic = 0;
        if (!find_tag4(new_data, p, new_data.size(), "BLOB", blob_magic)) break;
        p = blob_magic;

        if (p + 8 > new_data.size()) break;
        const std::uint32_t n = be32(new_data.data() + p + 4);
        const std::uint64_t blob_end64 = static_cast<std::uint64_t>(p) + 8ull + n;
        if (blob_end64 > new_data.size()) {
            ++p;
            continue;
        }
        const std::size_t blob_end = static_cast<std::size_t>(blob_end64);

        std::size_t ext_off = 0;
        std::size_t ext_size = 0;
        if (find_field(new_data, p, blob_end, "EEXT", ext_off, ext_size)) {
            const std::string ext = normalize_extension_text(bytes_to_string(new_data, ext_off, ext_size));

            if (ext == "apcp") {
                std::size_t uid_off = 0;
                std::size_t uid_size = 0;
                std::size_t ssnd = 0;
                if (find_field(new_data, p, blob_end, "EUID", uid_off, uid_size) &&
                    find_tag4(new_data, p, blob_end, "SSND", ssnd) &&
                    ssnd + 8 <= blob_end) {
                    const std::uint32_t ssnd_len = be32(new_data.data() + ssnd + 4);
                    const std::uint64_t raw_start64 = static_cast<std::uint64_t>(ssnd) + 16ull;
                    const std::uint64_t raw_end64 = static_cast<std::uint64_t>(ssnd) + 8ull + ssnd_len;

                    if (raw_start64 <= raw_end64 && raw_end64 <= blob_end) {
                        const std::size_t raw_start = static_cast<std::size_t>(raw_start64);
                        const std::size_t raw_end = static_cast<std::size_t>(raw_end64);
                        const std::size_t raw_bytes = raw_end - raw_start;
                        const std::string uid = bytes_to_string(new_data, uid_off, uid_size);

                        if (!uid.empty() && raw_bytes >= 2 && (raw_bytes & 1u) == 0) {
                            new_audio.push_back(AudioEntry{uid, raw_start, raw_bytes});
                        }
                    }
                }
            } else if (ext == "uvf") {
                // UVF XML is metadata; only this small blob is copied. Newer
                // YEM builds have also been seen with UTF-16 XML encodings, so
                // the XML search view is normalized before zone parsing.
                std::vector<std::uint8_t> blob;
                try {
                    blob.assign(new_data.begin() + static_cast<std::ptrdiff_t>(p),
                                new_data.begin() + static_cast<std::ptrdiff_t>(blob_end));
                } catch (const std::bad_alloc&) {
                    error = "not enough RAM while reading UVF metadata";
                    return false;
                }

                const std::vector<std::uint8_t> xml_blob = make_xml_search_blob(blob);
                const auto& xml = xml_blob;

                std::vector<std::uint8_t> title_bytes;
                extract_field(blob, "ETIT", title_bytes);

                VoiceEntry v;
                v.title = bytes_to_string(title_bytes);
                extract_xml_tag(xml, "waveFilePath", v.first_sample_uid);
                if (v.first_sample_uid.empty()) {
                    extract_xml_tag(xml, "waveFile", v.first_sample_uid);
                }
                v.sample_rate = parse_int_tag(xml, "samplingFrequency", 44100);
                const std::size_t voice_index = new_voices.size();
                const std::size_t first_zone_index = new_voice_zones.size();
                parse_voice_zones_from_blob(xml, voice_index, v.title, new_voice_zones);

                PpfVoiceDescriptor d;
                d.voice_index = voice_index;
                d.title = v.title;
                d.voice_name = v.title;
                d.voice_type = "UNIVERSAL";
                extract_xml_tag(xml, "voiceType", d.voice_type);
                d.msb = static_cast<std::uint8_t>(std::clamp(parse_int_tag(xml, "voiceMsb", 0), 0, 127));
                d.lsb = static_cast<std::uint8_t>(std::clamp(parse_int_tag(xml, "voiceLsb", 0), 0, 127));
                d.program = static_cast<std::uint8_t>(std::clamp(parse_int_tag(xml, "voicePcNum", static_cast<int>(voice_index % 128)), 0, 127));
                std::string info_name;
                if (extract_xml_tag(xml, "voiceName", info_name) && !info_name.empty()) {
                    d.voice_name = info_name;
                }
                d.first_zone_index = first_zone_index;
                d.zone_count = new_voice_zones.size() - first_zone_index;
                new_voice_descriptors.push_back(std::move(d));
                new_voices.push_back(std::move(v));
            }
        }

        if (blob_end <= p) {
            error = "internal PPF parser made no forward progress";
            return false;
        }
        p = blob_end;
    }

    if (new_audio.empty()) {
        error = "PPF contains no APCp PCM audio entries";
        return false;
    }

    // Commit only after the new parse is complete. A failed open therefore does
    // not leave the object half-parsed.
    file_data_.swap(new_data);
    audio_.swap(new_audio);
    audio_index_by_uid_.clear();
    audio_index_by_uid_.reserve(audio_.size() * 2u);
    for (std::size_t i = 0; i < audio_.size(); ++i) audio_index_by_uid_.emplace(audio_[i].uid, i);
    voices_.swap(new_voices);
    voice_descriptors_.swap(new_voice_descriptors);
    voice_zones_.swap(new_voice_zones);
    summary_.audio_count = audio_.size();
    summary_.voice_count = voices_.size();
    summary_.voice_zone_count = voice_zones_.size();
    return true;
}

bool PpfReader::source_bank_slot(std::uint8_t& msb, std::uint8_t& lsb, std::string& error) const {
    error.clear();
    bool found = false;
    std::uint8_t first_lsb = 0;
    std::uint8_t first_msb = 0;
    for (const auto& v : voice_descriptors_) {
        if (v.msb != 62u && v.msb != 63u) continue;
        if (!found) {
            first_msb = v.msb;
            first_lsb = v.lsb;
            found = true;
            continue;
        }
        if (v.lsb != first_lsb) {
            error = "PPF contains multiple custom Voice bank LSB values (" +
                    std::to_string(first_lsb) + " and " + std::to_string(v.lsb) + ")";
            return false;
        }
    }
    if (!found) {
        error = "PPF contains no MSB 62/63 custom Voice descriptors; no authoritative expansion LSB is available";
        return false;
    }
    // Prefer MSB=62 as the representative pack slot when a PPF contains both
    // custom drum and custom normal Voices; individual Voice MSB values remain
    // untouched in the installed catalog.
    bool has_62 = false;
    for (const auto& v : voice_descriptors_) if (v.msb == 62u && v.lsb == first_lsb) { has_62 = true; break; }
    msb = has_62 ? 62u : first_msb;
    lsb = first_lsb;
    return true;
}

static std::int16_t read_be_i16(const std::uint8_t* p) noexcept {
    const std::uint16_t u = (static_cast<std::uint16_t>(p[0]) << 8) | p[1];
    return static_cast<std::int16_t>(u);
}

bool PpfReader::fill_sample(const AudioEntry* entry,
                            const std::string& title,
                            int rate,
                            bool from_voice,
                            PpfSample& out,
                            std::string& error) const {
    out = {};
    if (!entry || entry->pcm_bytes < 2) {
        error = "requested PPF sample is empty";
        return false;
    }
    if (entry->pcm_offset > file_data_.size() ||
        entry->pcm_bytes > file_data_.size() - entry->pcm_offset) {
        error = "requested PPF sample range is outside resident PPF bytes";
        return false;
    }
    if ((entry->pcm_bytes & 1u) != 0) {
        error = "requested PPF sample has an odd PCM byte count";
        return false;
    }

    const std::size_t frames = entry->pcm_bytes / 2;
    if (frames > std::vector<std::int16_t>().max_size()) {
        error = "PPF sample is too large for vector materialization (bytes=" +
                std::to_string(entry->pcm_bytes) + ")";
        return false;
    }
    try {
        out.uid = entry->uid;
        out.pcm.resize(frames);
    } catch (const std::bad_alloc&) {
        error = "not enough RAM to materialize PPF sample (bytes=" +
                std::to_string(entry->pcm_bytes) + ")";
        out = {};
        return false;
    }

    const auto* raw = file_data_.data() + entry->pcm_offset;
    for (std::size_t i = 0; i < frames; ++i) {
        out.pcm[i] = read_be_i16(raw + i * 2);
    }
    out.sample_rate = rate > 0 ? rate : 44100;
    out.channels = 1;
    out.from_first_voice = from_voice;
    out.voice_title = title;
    return true;
}

bool PpfReader::load_first_voice_sample(PpfSample& out, std::string& error) const {
    if (voices_.empty() || voices_[0].first_sample_uid.empty()) {
        error = "PPF has no first Voice sample reference";
        return false;
    }
    const auto* a = find_audio(voices_[0].first_sample_uid);
    return fill_sample(a, voices_[0].title, voices_[0].sample_rate, true, out, error);
}

bool PpfReader::load_first_audio_sample(PpfSample& out, std::string& error) const {
    return load_audio_sample(0, out, error);
}

bool PpfReader::load_audio_sample(std::size_t index,
                                  PpfSample& out,
                                  std::string& error) const {
    if (index >= audio_.size()) {
        error = "PPF audio index out of range: " + std::to_string(index) +
                " (count=" + std::to_string(audio_.size()) + ")";
        return false;
    }
    return fill_sample(&audio_[index], "", 44100, false, out, error);
}

bool PpfReader::load_voice_zone_sample(std::size_t voice_index,
                                       std::size_t zone_index,
                                       PpfSample& out,
                                       std::string& error) const {
    out = {};
    if (voice_index >= voice_descriptors_.size()) {
        error = "PPF Voice index out of range: " + std::to_string(voice_index) +
                " (count=" + std::to_string(voice_descriptors_.size()) + ")";
        return false;
    }
    const auto& voice = voice_descriptors_[voice_index];
    if (zone_index >= voice.zone_count) {
        error = "PPF Voice zone index out of range: Voice=" + std::to_string(voice_index) +
                " zone=" + std::to_string(zone_index) +
                " (count=" + std::to_string(voice.zone_count) + ")";
        return false;
    }
    const std::size_t global_zone = voice.first_zone_index + zone_index;
    if (global_zone >= voice_zones_.size()) {
        error = "PPF Voice zone global index outside parsed zone table";
        return false;
    }
    const auto& zone = voice_zones_[global_zone];
    if (zone.sample_uid.empty()) {
        error = "PPF Voice zone has no sample UID";
        return false;
    }
    const auto* entry = find_audio(zone.sample_uid);
    if (!entry) {
        error = "PPF Voice zone sample UID not found in APCp audio table: " + zone.sample_uid;
        return false;
    }
    return fill_sample(entry, voice.title, zone.sample_rate, true, out, error);
}

} // namespace arranger
