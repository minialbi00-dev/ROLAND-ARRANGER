#include "voice_install_catalog.hpp"
#include <algorithm>
#include <unordered_set>

namespace arranger {

void InstalledVoiceCatalog::clear() noexcept {
    voices_.clear();
    banks_.clear();
    next_bank_id_ = 1;
}

bool InstalledVoiceCatalog::address_equal(const InstalledVoiceAddress& a,
                                          const InstalledVoiceAddress& b) noexcept {
    return a.msb == b.msb && a.lsb == b.lsb && a.program == b.program;
}

std::string InstalledVoiceCatalog::ppf_identity(const PpfVoiceDescriptor& v) {
    return "PPF:" + std::to_string(v.msb) + "/" + std::to_string(v.lsb) + "/" + std::to_string(v.program);
}

std::string InstalledVoiceCatalog::yep_identity(const YepVoiceDescriptor& v) {
    return "YEP:" + std::to_string(v.source_voice_id[0]) + "/" +
           std::to_string(v.source_voice_id[1]) + "/" + std::to_string(v.source_voice_id[2]);
}

bool InstalledVoiceCatalog::has_installed_address_conflict(const InstalledVoiceAddress& address) const noexcept {
    for (const auto& v : voices_) {
        if (v.installed_address_valid && address_equal(v.installed_address, address)) return true;
    }
    return false;
}

bool InstalledVoiceCatalog::install_ppf(const PpfReader& reader,
                                        const std::string& source_path,
                                        InstalledVoiceAddress installed_base,
                                        std::string& error,
                                        std::size_t* out_bank_id) {
    error.clear();
    if (reader.voices().empty()) {
        error = "Cannot install PPF: no Voice descriptors";
        return false;
    }
    const bool preserve_source_slot = installed_base.msb == 0xFFu && installed_base.lsb == 0xFFu;
    const bool partial_source_slot = installed_base.msb == 0xFFu || installed_base.lsb == 0xFFu;
    if ((!preserve_source_slot && partial_source_slot) ||
        (!preserve_source_slot && (installed_base.msb > 127u || installed_base.lsb > 127u))) {
        error = "PPF install requires a valid MSB/LSB pair, or 255/255 to preserve the PPF source slot";
        return false;
    }
    if (reader.voices().size() > 128u) {
        error = "PPF contains more than 128 Voices; one installed bank cannot exceed MIDI Program space";
        return false;
    }

    std::uint8_t source_msb = 0;
    std::uint8_t source_lsb = 0;
    std::string slot_error;
    if (!reader.source_bank_slot(source_msb, source_lsb, slot_error)) {
        error = slot_error;
        return false;
    }
    if (preserve_source_slot) {
        // Product sentinel: use the source address encoded by the PPF. This is
        // not slot allocation; no alternative/free LSB is ever selected.
        installed_base = {source_msb, source_lsb, 0};
    } else if (installed_base.msb == 0xFFu || installed_base.lsb == 0xFFu) {
        error = "PPF install requires both MSB and LSB to be explicit, or both 255 to preserve the PPF source slot";
        return false;
    } else if (installed_base.msb != source_msb || installed_base.lsb != source_lsb) {
        error = "PPF source slot is " + std::to_string(source_msb) + "/" + std::to_string(source_lsb) +
                " but installer requested " + std::to_string(installed_base.msb) + "/" + std::to_string(installed_base.lsb) +
                "; the engine will not renumber a PPF bank";
        return false;
    }

    // Validate all addresses first, then commit the whole bank atomically.
    std::unordered_set<std::uint32_t> pending_addresses;
    pending_addresses.reserve(reader.voices().size() * 2u + 1u);
    for (const auto& v : reader.voices()) {
        InstalledVoiceAddress addr{};
        // The PPF itself is authoritative. Do not rewrite the expansion LSB
        // or Program number during installation.
        addr = {v.msb, v.lsb, v.program};
        const std::uint32_t key = (static_cast<std::uint32_t>(addr.msb) << 14) |
                                  (static_cast<std::uint32_t>(addr.lsb) << 7) |
                                  static_cast<std::uint32_t>(addr.program);
        if (!pending_addresses.insert(key).second || has_installed_address_conflict(addr)) {
            error = "PPF installed Voice address collides with an already installed Voice bank";
            return false;
        }
    }

    const std::size_t bank_id = next_bank_id_++;
    InstalledBankRecord bank;
    bank.bank_id = bank_id;
    bank.format = InstalledVoiceFormat::PPF;
    bank.title = source_path.empty() ? "PPF Voice Bank" : source_path;
    bank.source_path = source_path;
    bank.installed_base = installed_base;
    bank.voice_count = reader.voices().size();
    banks_.push_back(bank);

    try {
        voices_.reserve(voices_.size() + reader.voices().size());
        for (const auto& v : reader.voices()) {
            InstalledVoiceRecord r;
            r.format = InstalledVoiceFormat::PPF;
            r.bank_id = bank_id;
            r.source_index = v.voice_index;
            r.title = v.title.empty() ? v.voice_name : v.title;
            r.source_identity = ppf_identity(v);
            r.source_path = source_path;
            r.source_address = {v.msb, v.lsb, v.program};

            // EKB_LEGACY is carried inside the PPF as an internal/legacy Voice
            // descriptor (its WXC samples are not APCp expansion PCM). Keep the
            // descriptor in the installed catalog, but do not claim that its
            // standard Yamaha address is an installed PPF slot.
            if (v.voice_type == "EKB_LEGACY") {
                r.source_address_valid = false;
                r.installed_address_valid = false;
            } else {

            // PPF source address is also the installed address. This keeps the
            // exact YEM bank LSB and PC; no engine-side slot or PC assignment.
            r.installed_address = {v.msb, v.lsb, v.program};
            if (v.voice_type != "EKB_LEGACY") {
                r.source_address_valid = true;
                r.installed_address_valid = true;
            }
            }
            r.zone_count = v.zone_count;
            voices_.push_back(std::move(r));
        }
    } catch (...) {
        // The common failure mode here is allocation. Keep catalog state
        // coherent instead of leaving a half-installed bank visible.
        voices_.resize(voices_.size() - reader.voices().size());
        banks_.pop_back();
        --next_bank_id_;
        error = "not enough RAM while adding installed PPF Voice bank";
        return false;
    }

    if (out_bank_id) *out_bank_id = bank_id;
    return true;
}

bool InstalledVoiceCatalog::install_ppf(const PpfReader& reader, std::string& error) {
    return install_ppf(reader, "", InstalledVoiceAddress{0xFF, 0xFF, 0}, error, nullptr);
}

bool InstalledVoiceCatalog::install_yep(const YepReader& reader,
                                        const std::vector<YepInstallMapping>& mappings,
                                        const std::string& source_path,
                                        std::string& error,
                                        std::size_t* out_bank_id) {
    error.clear();
    if (reader.voices().empty()) {
        error = "Cannot install YEP: no Voice descriptors";
        return false;
    }

    std::vector<InstalledVoiceAddress> resolved(reader.voices().size());
    std::vector<bool> mapped(reader.voices().size(), false);
    for (const auto& m : mappings) {
        if (m.voice_index >= reader.voices().size()) {
            error = "YEP install map references an invalid Voice index";
            return false;
        }
        if (m.address.msb > 127 || m.address.lsb > 127 || m.address.program > 127) {
            error = "YEP install map contains an invalid MIDI address";
            return false;
        }
        if (mapped[m.voice_index]) {
            error = "YEP install map contains duplicate Voice index";
            return false;
        }
        for (const auto& prior : mappings) {
            if (&prior == &m) break;
            if (mapped[prior.voice_index] && address_equal(resolved[prior.voice_index], m.address)) {
                error = "YEP install map contains a duplicate installed MIDI address";
                return false;
            }
        }
        resolved[m.voice_index] = m.address;
        mapped[m.voice_index] = true;
    }

    for (std::size_t i = 0; i < resolved.size(); ++i) {
        if (!mapped[i]) continue;
        if (has_installed_address_conflict(resolved[i])) {
            error = "YEP installed slot collides with an already installed Voice bank";
            return false;
        }
    }

    const std::size_t bank_id = next_bank_id_++;
    InstalledBankRecord bank;
    bank.bank_id = bank_id;
    bank.format = InstalledVoiceFormat::YEP;
    bank.title = source_path.empty() ? "YEP Voice Bank" : source_path;
    bank.source_path = source_path;
    bank.voice_count = reader.voices().size();
    banks_.push_back(bank);

    const std::size_t old_size = voices_.size();
    try {
        voices_.reserve(old_size + reader.voices().size());
        for (const auto& v : reader.voices()) {
            InstalledVoiceRecord r;
            r.format = InstalledVoiceFormat::YEP;
            r.bank_id = bank_id;
            r.source_index = v.voice_index;
            r.title = v.title;
            r.source_identity = yep_identity(v);
            r.source_path = source_path;
            r.source_address_valid = false;
            r.installed_address_valid = mapped[v.voice_index];
            if (r.installed_address_valid) r.installed_address = resolved[v.voice_index];
            r.zone_count = v.zone_count;
            voices_.push_back(std::move(r));
        }
    } catch (...) {
        voices_.resize(old_size);
        banks_.pop_back();
        --next_bank_id_;
        error = "not enough RAM while adding installed YEP Voice bank";
        return false;
    }

    if (out_bank_id) *out_bank_id = bank_id;
    return true;
}

bool InstalledVoiceCatalog::install_yep(const YepReader& reader,
                                        const std::vector<YepInstallMapping>& mappings,
                                        std::string& error) {
    return install_yep(reader, mappings, "", error, nullptr);
}

std::size_t InstalledVoiceCatalog::ppf_bank_count() const noexcept {
    std::size_t n = 0;
    for (const auto& b : banks_) if (b.format == InstalledVoiceFormat::PPF) ++n;
    return n;
}

bool InstalledVoiceCatalog::remove_bank(std::size_t bank_id) noexcept {
    auto bit = std::find_if(banks_.begin(), banks_.end(),
                            [bank_id](const InstalledBankRecord& b) { return b.bank_id == bank_id; });
    if (bit == banks_.end()) return false;
    voices_.erase(std::remove_if(voices_.begin(), voices_.end(),
                                 [bank_id](const InstalledVoiceRecord& v) { return v.bank_id == bank_id; }),
                  voices_.end());
    banks_.erase(bit);
    if (bank_id + 1u == next_bank_id_) --next_bank_id_;
    return true;
}

const InstalledVoiceRecord* InstalledVoiceCatalog::find_installed(const InstalledVoiceAddress& address) const noexcept {
    for (const auto& v : voices_) {
        if (v.installed_address_valid && address_equal(v.installed_address, address)) return &v;
    }
    return nullptr;
}

std::vector<InstalledVoiceRecord> InstalledVoiceCatalog::bank_voice_records(std::size_t bank_id) const {
    std::vector<InstalledVoiceRecord> out;
    for (const auto& v : voices_) {
        if (v.bank_id == bank_id) out.push_back(v);
    }
    return out;
}

const InstalledVoiceRecord* InstalledVoiceCatalog::find_source(const InstalledVoiceAddress& address) const noexcept {
    for (const auto& v : voices_) {
        if (v.source_address_valid && address_equal(v.source_address, address)) return &v;
    }
    return nullptr;
}

const InstalledVoiceRecord* InstalledVoiceCatalog::find_bank_voice(std::size_t bank_id,
                                                                   std::size_t source_index) const noexcept {
    for (const auto& v : voices_) {
        if (v.bank_id == bank_id && v.source_index == source_index) return &v;
    }
    return nullptr;
}

bool InstalledVoiceCatalog::resolve_style_call(const StyleVoiceCall& call,
                                               InstalledVoiceResolution& out,
                                               std::string& error) const {
    out = {};
    error.clear();
    if (call.channel >= 16u) {
        error = "Style Voice call has invalid MIDI channel";
        return false;
    }

    const InstalledVoiceAddress addr{call.msb, call.lsb, call.program};

    // Installed address is the strongest identity. It must be unique.
    const InstalledVoiceRecord* exact_installed = nullptr;
    std::size_t installed_hits = 0;
    for (const auto& v : voices_) {
        if (!v.installed_address_valid || !address_equal(v.installed_address, addr)) continue;
        exact_installed = &v;
        ++installed_hits;
    }
    if (installed_hits == 1u && exact_installed) {
        out.call = call;
        out.voice = exact_installed;
        out.installed_address = exact_installed->installed_address;
        out.installed_address_valid = exact_installed->installed_address_valid;
        out.mapped_to_installed = exact_installed->installed_address_valid;
        out.installed_exact = true;
        return true;
    }
    if (installed_hits > 1u) {
        error = "Ambiguous installed Voice address";
        return true;
    }

    // Source identity is retained for Style packs that encode the source PPF
    // address rather than the installed expansion slot. It is only accepted
    // when exactly one installed voice owns that source address.
    const InstalledVoiceRecord* exact_source = nullptr;
    std::size_t source_hits = 0;
    for (const auto& v : voices_) {
        if (!v.source_address_valid || !address_equal(v.source_address, addr)) continue;
        exact_source = &v;
        ++source_hits;
    }
    if (source_hits == 1u && exact_source) {
        out.call = call;
        out.voice = exact_source;
        out.installed_address = exact_source->installed_address;
        out.installed_address_valid = exact_source->installed_address_valid;
        out.mapped_to_installed = exact_source->installed_address_valid;
        out.source_exact = true;
        return true;
    }
    if (source_hits > 1u) {
        error = "Ambiguous source Voice address across installed banks";
        return true;
    }

    // Preserve the proven safety rule: MSB+Program aliasing is allowed only
    // when exactly one installed source Voice owns that combination and that
    // combination itself exposes only one source LSB.
    const InstalledVoiceRecord* candidate = nullptr;
    std::uint8_t candidate_lsb = 0;
    std::size_t count = 0;
    for (const auto& v : voices_) {
        if (!v.source_address_valid) continue;
        if (v.source_address.msb != addr.msb || v.source_address.program != addr.program) continue;
        if (!candidate) {
            candidate = &v;
            candidate_lsb = v.source_address.lsb;
        } else if (candidate_lsb != v.source_address.lsb) {
            return true; // ambiguous by design; no fallback
        }
        ++count;
    }
    if (count == 1u && candidate) {
        out.call = call;
        out.voice = candidate;
        out.installed_address = candidate->installed_address;
        out.installed_address_valid = candidate->installed_address_valid;
        out.mapped_to_installed = candidate->installed_address_valid;
    }
    return true;
}

} // namespace arranger
