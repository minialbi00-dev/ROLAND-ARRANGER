#pragma once

#include <stddef.h>
#include <stdint.h>

#ifdef _WIN32
#define YAC_EXPORT extern "C" __declspec(dllexport)
#define YAC_CALL __cdecl
#else
#define YAC_EXPORT extern "C"
#define YAC_CALL
#endif

#ifdef __cplusplus
extern "C" {
#endif

typedef struct YacArrangerEvent {
    uint32_t global_tick;
    uint8_t status;
    uint8_t data1;
    uint8_t data2;
    uint16_t track;
} YacArrangerEvent;

typedef struct YacArrangerState {
    uint8_t running;
    uint8_t acmp_enabled;
    int16_t transpose;
    uint16_t division;
    uint8_t numerator;
    uint8_t denominator;
    uint32_t bar_ticks;
    uint32_t transport_tick;
    double bpm;
    char current_section[64];
    char active_main[64];
} YacArrangerState;

YAC_EXPORT void* YAC_CALL yac_arranger_create(char* error_buf, size_t error_cap);
YAC_EXPORT void YAC_CALL yac_arranger_destroy(void* handle);

YAC_EXPORT int YAC_CALL yac_arranger_load_style(void* handle,
                                                const char* style_path,
                                                char* error_buf,
                                                size_t error_cap);
YAC_EXPORT int YAC_CALL yac_arranger_start(void* handle,
                                          char* error_buf,
                                          size_t error_cap);
YAC_EXPORT void YAC_CALL yac_arranger_stop(void* handle);
YAC_EXPORT int YAC_CALL yac_arranger_running(void* handle);

YAC_EXPORT int YAC_CALL yac_arranger_queue_main(void* handle,
                                                const char* name,
                                                char* error_buf,
                                                size_t error_cap);
YAC_EXPORT int YAC_CALL yac_arranger_queue_fill(void* handle,
                                                const char* name,
                                                char* error_buf,
                                                size_t error_cap);
YAC_EXPORT int YAC_CALL yac_arranger_queue_intro(void* handle,
                                                 const char* name,
                                                 char* error_buf,
                                                 size_t error_cap);
YAC_EXPORT int YAC_CALL yac_arranger_queue_ending(void* handle,
                                                  const char* name,
                                                  char* error_buf,
                                                  size_t error_cap);

YAC_EXPORT void YAC_CALL yac_arranger_set_acmp(void* handle, int enabled);
YAC_EXPORT void YAC_CALL yac_arranger_set_chord(void* handle,
                                                uint8_t root_pc,
                                                uint8_t chord_type);
YAC_EXPORT void YAC_CALL yac_arranger_set_transpose(void* handle, int semitones);
YAC_EXPORT void YAC_CALL yac_arranger_set_tempo(void* handle, double bpm);
YAC_EXPORT void YAC_CALL yac_arranger_set_finger_mode(void* handle, uint8_t mode);
YAC_EXPORT void YAC_CALL yac_arranger_set_split_point(void* handle, int note);
YAC_EXPORT void YAC_CALL yac_arranger_set_smart_chord_key(void* handle, int root_pc);
YAC_EXPORT void YAC_CALL yac_arranger_set_smart_chord_type(void* handle, uint8_t type);
YAC_EXPORT void YAC_CALL yac_arranger_set_smart_chord_minor(void* handle, int minor);
YAC_EXPORT void YAC_CALL yac_arranger_clear_performance_notes(void* handle);
YAC_EXPORT void YAC_CALL yac_arranger_midi_input(void* handle, uint8_t status, uint8_t data1, uint8_t data2);

// Performance/chord state is owned by the native C++ runtime.
typedef struct YacPerformanceState {
    uint8_t acmp_enabled;
    uint8_t note_gate;
    uint8_t finger_mode;
    int16_t transpose;
    uint8_t chord_root_pc;
    uint8_t chord_type;
    char chord_name[32];
    uint8_t held_notes[128];
    uint16_t held_note_count;
    uint64_t note_on_count;
    uint64_t note_off_count;
    uint8_t chord_bass_pc;
    uint8_t chord_bass_valid;
    uint8_t split_point;
    uint8_t smart_chord_key_pc;
    uint8_t smart_chord_type;
} YacPerformanceState;

YAC_EXPORT int YAC_CALL yac_arranger_get_performance_state(void* handle, YacPerformanceState* out_state);

YAC_EXPORT int YAC_CALL yac_arranger_advance_to(void* handle,
                                                uint32_t global_tick,
                                                YacArrangerEvent* out_events,
                                                size_t out_capacity,
                                                size_t* out_count,
                                                char* error_buf,
                                                size_t error_cap);
YAC_EXPORT int YAC_CALL yac_arranger_get_state(void* handle, YacArrangerState* out_state);

#ifdef __cplusplus
}
#endif
