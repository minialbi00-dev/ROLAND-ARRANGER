#include "soundfont_bank.hpp"

#include <algorithm>
#include <cmath>
#include <cstddef>
#include <cstdint>
#include <cstring>
#include <fstream>
#include <limits>
#include <new>

namespace arranger {
namespace {

std::uint16_t le16(const std::uint8_t* p) noexcept {
    return static_cast<std::uint16_t>(p[0] | (static_cast<std::uint16_t>(p[1]) << 8));
}
std::int16_t sle16(const std::uint8_t* p) noexcept { return static_cast<std::int16_t>(le16(p)); }
std::uint32_t le32(const std::uint8_t* p) noexcept {
    return static_cast<std::uint32_t>(p[0]) |
           (static_cast<std::uint32_t>(p[1]) << 8) |
           (static_cast<std::uint32_t>(p[2]) << 16) |
           (static_cast<std::uint32_t>(p[3]) << 24);
}

struct GenSet {
    int key_lo = 0, key_hi = 127;
    int vel_lo = 1, vel_hi = 127;
    int coarse = 0;
    int fine = 0;
    int atten = 0;
    int pan = 0;
    int root = -1;
    bool root_set = false;
    bool loop = false;
    int sample_id = -1;
    bool sample_set = false;
};

void apply_gen(GenSet& g, std::uint16_t op, std::int16_t amount) noexcept {
    const int v = static_cast<int>(amount);
    switch (op) {
        case 43: { // keyRange
            const int lo = amount & 0xFF;
            const int hi = (static_cast<std::uint16_t>(amount) >> 8) & 0xFF;
            g.key_lo = std::max(g.key_lo, std::min(127, lo));
            g.key_hi = std::min(g.key_hi, std::min(127, hi));
            break;
        }
        case 44: { // velRange
            const int lo = amount & 0xFF;
            const int hi = (static_cast<std::uint16_t>(amount) >> 8) & 0xFF;
            g.vel_lo = std::max(g.vel_lo, std::max(1, lo));
            g.vel_hi = std::min(g.vel_hi, std::min(127, hi));
            break;
        }
        case 48: g.atten = std::clamp(g.atten + v, 0, 14400); break; // 0.1 dB
        case 51: g.coarse = std::clamp(g.coarse + v, -120, 120); break;
        case 52: g.fine = std::clamp(g.fine + v, -12000, 12000); break;
        case 53: g.sample_id = std::max(0, v); g.sample_set = true; break;
        case 54: g.loop = (static_cast<std::uint16_t>(amount) & 0x3u) == 1u; break;
        case 17: g.pan = std::clamp(g.pan + v, -500, 500); break;
        case 58: if (v >= 0 && v <= 127) { g.root = v; g.root_set = true; } break;
        default: break;
    }
}

struct Pbag { std::uint16_t gen = 0; };
struct Ibag { std::uint16_t gen = 0; };

struct Shdr {
    std::uint32_t start = 0, end = 0, loop_start = 0, loop_end = 0, rate = 44100;
    std::uint8_t original_pitch = 60;
    std::int8_t pitch_correction = 0;
    std::uint16_t link = 0, type = 1;
};

bool read_file(const std::string& path, std::vector<std::uint8_t>& out, std::string& error) {
    std::ifstream f(path, std::ios::binary);
    if (!f) { error = "cannot open SF2: " + path; return false; }
    f.seekg(0, std::ios::end);
    const auto end = f.tellg();
    if (end <= 0) { error = "SF2 is empty"; return false; }
    if (static_cast<unsigned long long>(end) > std::numeric_limits<std::size_t>::max()) {
        error = "SF2 is too large for this process"; return false;
    }
    out.resize(static_cast<std::size_t>(end));
    f.seekg(0, std::ios::beg);
    if (!out.empty()) {
        f.read(reinterpret_cast<char*>(out.data()), static_cast<std::streamsize>(out.size()));
        if (!f || static_cast<std::size_t>(f.gcount()) != out.size()) {
            error = "failed reading SF2 bytes";
            return false;
        }
    }
    return true;
}

struct Chunk { std::size_t data = 0, end = 0; };

bool find_child_list(const std::vector<std::uint8_t>& b,
                     std::size_t begin, std::size_t end,
                     const char* list_type, Chunk& out) {
    std::size_t p = begin;
    while (p + 12 <= end) {
        const std::uint32_t n = le32(b.data() + p + 4);
        const std::size_t body = p + 8;
        const std::size_t chunk_end = body + static_cast<std::size_t>(n);
        if (chunk_end > end) return false;
        if (std::memcmp(b.data() + p, "LIST", 4) == 0 && n >= 4 &&
            std::memcmp(b.data() + body, list_type, 4) == 0) {
            out = {body + 4, chunk_end};
            return true;
        }
        p = chunk_end + (n & 1u);
    }
    return false;
}

bool find_subchunk(const std::vector<std::uint8_t>& b,
                   std::size_t begin, std::size_t end,
                   const char tag[4], Chunk& out) {
    std::size_t p = begin;
    while (p + 8 <= end) {
        const std::uint32_t n = le32(b.data() + p + 4);
        const std::size_t data = p + 8;
        const std::size_t chunk_end = data + static_cast<std::size_t>(n);
        if (chunk_end > end) return false;
        if (std::memcmp(b.data() + p, tag, 4) == 0) { out = {data, chunk_end}; return true; }
        p = chunk_end + (n & 1u);
    }
    return false;
}

bool parse_pdta(const std::vector<std::uint8_t>& b, const Chunk& pdta,
                std::vector<std::uint8_t>& phdr,
                std::vector<std::uint8_t>& pbag,
                std::vector<std::uint8_t>& pgen,
                std::vector<std::uint8_t>& inst,
                std::vector<std::uint8_t>& ibag,
                std::vector<std::uint8_t>& igen,
                std::vector<std::uint8_t>& shdr,
                std::string& error) {
    struct Ref { const char* tag; std::vector<std::uint8_t>* dst; } refs[] = {
        {"phdr", &phdr}, {"pbag", &pbag}, {"pgen", &pgen}, {"inst", &inst},
        {"ibag", &ibag}, {"igen", &igen}, {"shdr", &shdr}
    };
    for (const auto& r : refs) {
        Chunk c;
        if (!find_subchunk(b, pdta.data, pdta.end, r.tag, c)) {
            error = std::string("SF2 pdta missing ") + r.tag;
            return false;
        }
        r.dst->assign(b.begin() + static_cast<std::ptrdiff_t>(c.data),
                      b.begin() + static_cast<std::ptrdiff_t>(c.end));
    }
    return true;
}

GenSet read_gen_range(const std::vector<std::uint8_t>& raw, std::size_t record_begin, std::size_t record_end) {
    GenSet g;
    const std::size_t bytes = raw.size();
    const std::size_t start = std::min(record_begin * 4u, bytes);
    const std::size_t end = std::min(record_end * 4u, bytes);
    for (std::size_t p = start; p + 4 <= end; p += 4) {
        apply_gen(g, le16(raw.data() + p), sle16(raw.data() + p + 2));
    }
    return g;
}

GenSet merge_gen(const GenSet& a, const GenSet& b) {
    GenSet g = a;
    g.key_lo = std::max(a.key_lo, b.key_lo); g.key_hi = std::min(a.key_hi, b.key_hi);
    g.vel_lo = std::max(a.vel_lo, b.vel_lo); g.vel_hi = std::min(a.vel_hi, b.vel_hi);
    g.coarse = std::clamp(a.coarse + b.coarse, -120, 120);
    g.fine = std::clamp(a.fine + b.fine, -12000, 12000);
    g.atten = std::clamp(a.atten + b.atten, 0, 14400);
    g.pan = std::clamp(a.pan + b.pan, -500, 500);
    if (b.root_set) { g.root = b.root; g.root_set = true; }
    if (b.sample_set) { g.sample_id = b.sample_id; g.sample_set = true; }
    g.loop = a.loop || b.loop;
    return g;
}

bool valid_record_count(std::size_t bytes, std::size_t record_size, std::size_t min_records = 1) {
    return record_size > 0 && bytes >= min_records * record_size && (bytes % record_size) == 0;
}

} // namespace

bool SoundFontBank::load(const std::string& path, std::string& error) {
    error.clear();
    loaded_ = false; zone_count_ = 0; samples_.clear(); zones_.clear(); path_.clear();

    std::vector<std::uint8_t> b;
    if (!read_file(path, b, error)) return false;
    if (b.size() < 12 || std::memcmp(b.data(), "RIFF", 4) != 0 || std::memcmp(b.data() + 8, "sfbk", 4) != 0) {
        error = "not a RIFF SoundFont 2 file";
        return false;
    }

    Chunk sdta, pdta;
    if (!find_child_list(b, 12, b.size(), "sdta", sdta) || !find_child_list(b, 12, b.size(), "pdta", pdta)) {
        error = "SF2 missing sdta/pdta LIST";
        return false;
    }
    Chunk smpl;
    if (!find_subchunk(b, sdta.data, sdta.end, "smpl", smpl) || smpl.end <= smpl.data || ((smpl.end - smpl.data) % 2u) != 0) {
        error = "SF2 missing valid smpl chunk";
        return false;
    }

    std::vector<std::uint8_t> phdr, pbag, pgen, inst, ibag, igen, shdr;
    if (!parse_pdta(b, pdta, phdr, pbag, pgen, inst, ibag, igen, shdr, error)) return false;
    if (!valid_record_count(phdr.size(), 38) || !valid_record_count(pbag.size(), 4) ||
        !valid_record_count(pgen.size(), 4) || !valid_record_count(inst.size(), 22) ||
        !valid_record_count(ibag.size(), 4) || !valid_record_count(igen.size(), 4) ||
        !valid_record_count(shdr.size(), 46)) {
        error = "SF2 pdta record alignment is invalid";
        return false;
    }

    const std::size_t phdr_n = phdr.size() / 38u;
    const std::size_t pbag_n = pbag.size() / 4u;
    const std::size_t pgen_n = pgen.size() / 4u;
    const std::size_t inst_n = inst.size() / 22u;
    const std::size_t ibag_n = ibag.size() / 4u;
    const std::size_t igen_n = igen.size() / 4u;
    const std::size_t shdr_n = shdr.size() / 46u;
    if (phdr_n < 2 || pbag_n < 2 || inst_n < 2 || ibag_n < 2 || shdr_n < 2) {
        error = "SF2 does not contain terminal records";
        return false;
    }

    std::vector<Shdr> samples;
    samples.resize(shdr_n);
    samples_.reserve(shdr_n - 1u);
    for (std::size_t i = 0; i < shdr_n; ++i) {
        const auto* r = shdr.data() + i * 46u;
        Shdr x;
        x.start = le32(r + 20); x.end = le32(r + 24);
        x.loop_start = le32(r + 28); x.loop_end = le32(r + 32);
        x.rate = le32(r + 36);
        x.original_pitch = r[40]; x.pitch_correction = static_cast<std::int8_t>(r[41]);
        x.link = le16(r + 42); x.type = le16(r + 44);
        if (i + 1u < shdr_n) {
            if (x.start > x.end || static_cast<std::size_t>(x.end) * 2u > (smpl.end - smpl.data)) {
                error = "SF2 sample range is invalid"; return false;
            }
        }
        samples[i] = x;
    }

    // Materialize all PCM as float32 once. The bundled GMGSx file is small enough
    // that keeping the decoded sample bank resident is practical and keeps the
    // realtime callback free of file IO and allocations.
    for (std::size_t i = 0; i + 1u < shdr_n; ++i) {
        const auto& s = samples[i];
        const std::size_t frames = static_cast<std::size_t>(s.end - s.start);
        try {
            auto r = std::make_shared<ResidentSample>();
            r->uid_full = "SF2:" + std::to_string(i);
            r->sample_rate = s.rate > 0 ? static_cast<int>(s.rate) : 44100;
            r->channels = 1;
            r->pcm.resize(frames);
            const auto* raw = b.data() + smpl.data + static_cast<std::size_t>(s.start) * 2u;
            for (std::size_t j = 0; j < frames; ++j) r->pcm[j] = static_cast<float>(sle16(raw + j * 2u)) / 32768.0f;
            samples_.push_back(std::move(r));
        } catch (const std::bad_alloc&) {
            error = "not enough RAM to decode SF2 sample bank"; return false;
        }
    }

    const std::size_t terminal_preset = phdr_n - 1u;
    const std::size_t terminal_inst = inst_n - 1u;

    struct PresetRec { std::uint16_t preset=0, bank=0, bag=0; };
    std::vector<PresetRec> presets; presets.reserve(terminal_preset);
    for (std::size_t i = 0; i < terminal_preset; ++i) {
        const auto* r = phdr.data() + i * 38u;
        presets.push_back({le16(r + 20), le16(r + 22), le16(r + 24)});
    }

    std::vector<std::uint16_t> pbag_gen; pbag_gen.reserve(pbag_n);
    for (std::size_t i = 0; i < pbag_n; ++i) pbag_gen.push_back(le16(pbag.data() + i * 4u));
    std::vector<std::uint16_t> ibag_gen; ibag_gen.reserve(ibag_n);
    for (std::size_t i = 0; i < ibag_n; ++i) ibag_gen.push_back(le16(ibag.data() + i * 4u));

    struct InstRec { std::uint16_t bag=0; };
    std::vector<InstRec> instruments; instruments.reserve(terminal_inst);
    for (std::size_t i = 0; i < terminal_inst; ++i) instruments.push_back({le16(inst.data() + i * 22u + 20u)});

    // Build instrument zones. A bag containing a sampleID generator is local;
    // a preceding bag without one is the instrument-global zone.
    std::vector<GenSet> inst_global(terminal_inst), inst_zone_global(terminal_inst);
    std::vector<std::vector<std::pair<GenSet, std::size_t>>> instrument_zones(terminal_inst);
    for (std::size_t ii = 0; ii < terminal_inst; ++ii) {
        const std::size_t first_bag = instruments[ii].bag;
        const std::size_t next_bag = (ii + 1u < terminal_inst) ? instruments[ii + 1u].bag : ibag_n - 1u;
        if (first_bag >= ibag_n || next_bag > ibag_n || next_bag < first_bag) continue;
        for (std::size_t bi = first_bag; bi < next_bag; ++bi) {
            const std::size_t g0 = ibag_gen[bi];
            const std::size_t g1 = (bi + 1u < ibag_gen.size()) ? ibag_gen[bi + 1u] : igen_n;
            if (g0 > g1 || g1 > igen_n) continue;
            GenSet g = read_gen_range(igen, g0, g1);
            if (!g.sample_set) { inst_zone_global[ii] = merge_gen(inst_zone_global[ii], g); }
            else instrument_zones[ii].push_back({g, static_cast<std::size_t>(g.sample_id)});
        }
    }

    // Build playable preset zones from each preset zone's instrument generator.
    // A preset global zone has no instrument generator; local zones inherit it.
    for (std::size_t pi = 0; pi < presets.size(); ++pi) {
        const auto& pr = presets[pi];
        const std::size_t first_bag = pr.bag;
        const std::size_t next_bag = (pi + 1u < presets.size()) ? presets[pi + 1u].bag : pbag_n - 1u;
        if (first_bag >= pbag_n || next_bag > pbag_n || next_bag < first_bag) continue;

        GenSet preset_global;
        for (std::size_t bi = first_bag; bi < next_bag; ++bi) {
            const std::size_t g0 = pbag_gen[bi];
            const std::size_t g1 = (bi + 1u < pbag_gen.size()) ? pbag_gen[bi + 1u] : pgen_n;
            if (g0 > g1 || g1 > pgen_n) continue;
            GenSet pg = read_gen_range(pgen, g0, g1);
            int instrument_id = -1;
            for (std::size_t p = g0; p < g1; ++p) {
                if (le16(pgen.data() + p * 4u) == 41u) {
                    instrument_id = std::max(0, static_cast<int>(sle16(pgen.data() + p * 4u + 2u)));
                    break;
                }
            }
            if (instrument_id < 0) {
                preset_global = merge_gen(preset_global, pg);
                continue;
            }
            if (static_cast<std::size_t>(instrument_id) >= terminal_inst) continue;
            const auto& iz = instrument_zones[static_cast<std::size_t>(instrument_id)];
            const auto ig = inst_zone_global[static_cast<std::size_t>(instrument_id)];
            for (const auto& pair : iz) {
                const auto merged = merge_gen(merge_gen(preset_global, pg), merge_gen(ig, pair.first));
                if (!merged.sample_set || merged.sample_id < 0 || static_cast<std::size_t>(merged.sample_id) >= samples_.size()) continue;
                if (merged.key_lo > merged.key_hi || merged.vel_lo > merged.vel_hi) continue;
                const auto& sh = samples[static_cast<std::size_t>(merged.sample_id)];
                Zone z;
                z.bank = pr.bank; z.program = static_cast<std::uint8_t>(pr.preset & 0x7Fu);
                z.key_lo = static_cast<std::uint8_t>(std::clamp(merged.key_lo, 0, 127));
                z.key_hi = static_cast<std::uint8_t>(std::clamp(merged.key_hi, static_cast<int>(z.key_lo), 127));
                z.velocity_lo = static_cast<std::uint8_t>(std::clamp(merged.vel_lo, 1, 127));
                z.velocity_hi = static_cast<std::uint8_t>(std::clamp(merged.vel_hi, static_cast<int>(z.velocity_lo), 127));
                z.coarse_tune = static_cast<std::int16_t>(merged.coarse);
                z.fine_tune = static_cast<std::int16_t>(merged.fine + static_cast<int>(sh.pitch_correction));
                z.attenuation_tenthdB = static_cast<std::int16_t>(std::clamp(merged.atten, 0, 14400));
                z.pan_tenths_percent = static_cast<std::int16_t>(std::clamp(merged.pan, -500, 500));
                z.root_override = merged.root_set ? static_cast<std::int16_t>(merged.root) : static_cast<std::int16_t>(sh.original_pitch);
                z.loop = merged.loop &&
                         sh.loop_start >= sh.start && sh.loop_end <= sh.end &&
                         sh.loop_end > sh.loop_start + 1u;
                if (z.loop) {
                    z.loop_start_frame = static_cast<std::size_t>(sh.loop_start - sh.start);
                    z.loop_end_frame = static_cast<std::size_t>(sh.loop_end - sh.start);
                }
                z.sample = samples_[static_cast<std::size_t>(merged.sample_id)];
                zones_[PresetKey{z.bank, z.program}].push_back(std::move(z));
                ++zone_count_;
            }
        }
    }

    // Deterministic specificity: narrower key/velocity ranges win over wide ranges.
    for (auto& kv : zones_) {
        auto& zs = kv.second;
        std::stable_sort(zs.begin(), zs.end(), [](const Zone& a, const Zone& b) {
            const int ak = static_cast<int>(a.key_hi) - static_cast<int>(a.key_lo);
            const int bk = static_cast<int>(b.key_hi) - static_cast<int>(b.key_lo);
            if (ak != bk) return ak < bk;
            const int av = static_cast<int>(a.velocity_hi) - static_cast<int>(a.velocity_lo);
            const int bv = static_cast<int>(b.velocity_hi) - static_cast<int>(b.velocity_lo);
            return av < bv;
        });
    }

    path_ = path;
    loaded_ = !zones_.empty() && !samples_.empty();
    if (!loaded_) { error = "SF2 parsed but no playable preset zones were found"; return false; }
    return true;
}

const SoundFontBank::Zone* SoundFontBank::choose(std::uint16_t bank, std::uint8_t program,
                                                  std::uint8_t key, std::uint8_t velocity) const noexcept {
    const auto exact = zones_.find(PresetKey{bank, program});
    const std::vector<Zone>* z = exact != zones_.end() ? &exact->second : nullptr;
    if (!z && bank != 0u) {
        const auto gm = zones_.find(PresetKey{0, program});
        if (gm != zones_.end()) z = &gm->second;
    }
    if (!z) return nullptr;
    for (const auto& row : *z) {
        if (key >= row.key_lo && key <= row.key_hi && velocity >= row.velocity_lo && velocity <= row.velocity_hi)
            return &row;
    }
    return nullptr;
}

} // namespace arranger
