#pragma once

#include "arranger_engine.hpp"
#include "native_gui_ppf_audio.hpp"
#include "performance_runtime.hpp"

#include <atomic>
#include <chrono>
#include <cstdint>
#include <memory>
#include <mutex>
#include <string>
#include <thread>
#include <vector>
#ifdef _WIN32
#ifndef NOMINMAX
#define NOMINMAX
#endif
#include <windows.h>
#include <mmsystem.h>
#endif

namespace arranger {

struct NativeArrangerRuntimeState {
    bool running = false;
    bool audio_active = false;
    bool scheduler_active = false;
    bool acmp_enabled = false;
    int transpose = 0;
    double bpm = 120.0;
    std::uint16_t division = 480;
    std::uint32_t transport_tick = 0;
    std::uint32_t bar_ticks = 1920;
    std::string current_section;
    std::string active_main;
};

class NativeArrangerRuntime {
public:
    NativeArrangerRuntime();
    ~NativeArrangerRuntime();

    NativeArrangerRuntime(const NativeArrangerRuntime&) = delete;
    NativeArrangerRuntime& operator=(const NativeArrangerRuntime&) = delete;

    bool load_style(const std::string& style_path, std::string& error);
    bool install_ppf(const std::string& ppf_path,
                     InstalledVoiceAddress installed_base,
                     std::string& error);
    bool uninstall_ppf(std::size_t bank_id, std::string& error);

    // JALAN PINTAS UNTUK MENGIRIM SF2 KE MESIN AUDIO OBOE
    inline bool load_soundfont(const std::string& path, std::string& error) {
        return audio_.load_soundfont(path, error);
    }

    bool start(std::string& error);
    void stop() noexcept;
    bool running() const noexcept;

    bool queue_main(const std::string& name, std::string& error);
    bool queue_fill(const std::string& name, std::string& error);
    bool queue_intro(const std::string& name, std::string& error);
    bool queue_ending(const std::string& name, std::string& error);

    void feed_midi(std::uint8_t status, std::uint8_t data1, std::uint8_t data2) noexcept;
    void clear_performance_notes() noexcept;
    void set_finger_mode(std::uint8_t mode) noexcept;
    void set_split_point(int note) noexcept;
    void set_smart_chord_key(int root_pc) noexcept;
    void set_smart_chord_type(std::uint8_t type) noexcept;

    void set_acmp(bool enabled) noexcept;
    void set_chord(std::uint8_t root_pc, std::uint8_t chord_type) noexcept;
    void set_transpose(int semitones) noexcept;
    void set_tempo(double bpm) noexcept;

    bool set_audio_device_id(const std::string& device_id, std::string& error);
    std::string audio_device_id() const;
    bool open_midi_input(std::uint32_t device_index, std::string& error);
    void close_midi_input() noexcept;
    bool midi_input_active() const noexcept;
    static std::vector<std::string> midi_input_device_names();

    bool advance_to(std::uint32_t global_tick,
                    std::vector<ArrangerOutputEvent>& out,
                    std::string& error);

    NativeArrangerRuntimeState state() const;
    PerformanceRuntimeState performance_state() const;
    bool start_scheduler_only_for_test(std::string& error);

    NativeGuiAudioMetrics audio_metrics() const noexcept { return audio_.metrics(); }
    std::vector<NativeGuiPpfBankInfo> ppf_banks() const { return audio_.installed_ppf_banks(); }
    std::vector<NativeGuiPpfVoiceInfo> ppf_voices() const { return audio_.installed_ppf_voices(); }

private:
    using Clock = std::chrono::steady_clock;

    bool require_engine(std::string& error) const noexcept;
    bool enqueue_events(const std::vector<ArrangerOutputEvent>& events) noexcept;
    std::uint32_t clock_tick_locked(Clock::time_point now) const noexcept;
    void reset_clock_locked(Clock::time_point now) noexcept;
    void scheduler_thread_main();

    mutable std::mutex mutex_;
    YamahaStyleRuntime style_;
    std::unique_ptr<CppArrangerEngine> engine_;
    NativeGuiPpfAudio audio_;
    PerformanceRuntime performance_;

    std::atomic<bool> scheduler_running_{false};
    std::thread scheduler_thread_;
    std::atomic<std::uint32_t> last_scheduled_tick_{0};
    std::atomic<std::uint64_t> scheduler_dropped_events_{0};
    std::atomic<std::uint64_t> scheduler_event_batches_{0};

    Clock::time_point clock_anchor_ = Clock::now();
    std::uint32_t tick_anchor_ = 0;
    double bpm_ = 120.0;
#ifdef _WIN32
    static void CALLBACK midi_in_proc(HMIDIIN, UINT, DWORD_PTR, DWORD_PTR, DWORD_PTR);
#endif
    void handle_midi_input_short_message(std::uint32_t packed_message) noexcept;
#ifdef _WIN32
    void* midi_in_handle_ = nullptr;
    std::uint32_t midi_in_device_index_ = 0xFFFFFFFFu;
#endif
    std::string audio_device_id_;
};

} // namespace arranger