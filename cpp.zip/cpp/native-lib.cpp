#include <jni.h>
#include <unistd.h>
#include <sys/mman.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <android/log.h>
#include <SLES/OpenSLES.h>
#include <SLES/OpenSLES_Android.h>
#include <mutex>
#include <cstring>
#include <algorithm>
#include <climits>
#include <cmath>
#include <cstdlib>
#include <memory>
#include <string>
#include <vector>

#define TSF_IMPLEMENTATION
#include "tsf.h"

#define TML_IMPLEMENTATION
#include "tml.h"

#include "yamaha_style_runtime.hpp"
#include "arranger_engine.hpp"

#define LOG_TAG "IDArrangerPro"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, LOG_TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, LOG_TAG, __VA_ARGS__)

struct MmappedSoundFont {
    void* data = nullptr;
    size_t size = 0;
    int fd = -1;
    tsf* soundfont = nullptr;
};

static MmappedSoundFont g_mmappedSf;

static void freeMmappedSf(MmappedSoundFont& sf) {
    if (sf.soundfont) {
        tsf_close(sf.soundfont);
        sf.soundfont = nullptr;
    }
    if (sf.data && sf.data != MAP_FAILED) {
        munmap(sf.data, sf.size);
        sf.data = nullptr;
    }
    if (sf.fd != -1) {
        close(sf.fd);
        sf.fd = -1;
    }
    sf.size = 0;
}

// Global Objects
static tsf *g_soundFont = nullptr;
static arranger::YamahaStyleRuntime g_styleRuntime;
static std::unique_ptr<arranger::CppArrangerEngine> g_arrangerEngine;

static bool isPlaying = false;
static double g_accumulatedTicks = 0.0;
static int g_currentBeat = 0;

// Performance & Control State
static double g_tempoBpm = 120.0;
static int g_transpose = 0;
static int g_acmpEnabled = 1;
static float g_trackVolumes[16] = {
    1.0f, 1.0f, 1.0f, 1.0f, 1.0f, 1.0f, 1.0f, 1.0f,
    1.0f, 1.0f, 1.0f, 1.0f, 1.0f, 1.0f, 1.0f, 1.0f
};

static uint8_t g_channelMsb[16] = {0};
static uint8_t g_channelLsb[16] = {0};
static uint8_t g_channelProgram[16] = {0};
static bool g_channelPresetValid[16] = {};
static uint16_t g_channelMidiVolume[16] = {
    16383, 16383, 16383, 16383, 16383, 16383, 16383, 16383,
    16383, 16383, 16383, 16383, 16383, 16383, 16383, 16383
};
static uint16_t g_channelMidiExpression[16] = {
    16383, 16383, 16383, 16383, 16383, 16383, 16383, 16383,
    16383, 16383, 16383, 16383, 16383, 16383, 16383, 16383
};

static int g_currentRootPc = 0;
static int g_currentChordType = 0;
static int g_currentBassPc = 0;

static std::mutex g_audioMutex;

// OpenSL ES Engine Objects
static SLObjectItf engineObject = nullptr;
static SLEngineItf engineEngine = nullptr;
static SLObjectItf outputMixObject = nullptr;
static SLObjectItf bqPlayerObject = nullptr;
static SLPlayItf bqPlayerPlay = nullptr;
static SLAndroidSimpleBufferQueueItf bqPlayerBufferQueue = nullptr;

#define SAMPLE_RATE 48000 // Android Native FastMixer rate
#define BUFFER_FRAMES 192
constexpr int MAX_SOUNDFONT_VOICES = 256;

// DOUBLE BUFFERING
static float audioFrameBuffer[BUFFER_FRAMES * 2];
static int16_t pcmOutputBuffer[2][BUFFER_FRAMES * 2];
static int currentBufferIndex = 0;
static std::vector<arranger::ArrangerOutputEvent> g_renderEvents;
static std::string g_renderError;

static int findSoundFontPreset(tsf* f, int ch, int msb, int lsb, int program) {
    if (!f || program < 0 || program > 127) return -1;

    const bool isDrum = ch == 9 || ch == 8;
    const int bank = ((msb & 0x7F) << 7) | (lsb & 0x7F);
    int presetIndex = -1;
    if (isDrum) {
        const auto findDrumPreset = [&](int drumBank) {
            presetIndex = tsf_get_presetindex(f, drumBank, program);
            return presetIndex;
        };
        if (bank != 0 && findDrumPreset(bank) >= 0) return presetIndex;
        if (bank != 0 && findDrumPreset(128 | bank) >= 0) return presetIndex;
        if (msb != 0 && findDrumPreset(msb) >= 0) return presetIndex;
        const int drumBanks[] = {127, 128, 62};
        for (int drumBank : drumBanks) {
            if (findDrumPreset(drumBank) >= 0) return presetIndex;
        }
        return -1;
    }

    presetIndex = tsf_get_presetindex(f, bank, program);
    if (presetIndex < 0 && bank != 0) presetIndex = tsf_get_presetindex(f, 0, program);
    return presetIndex;
}

static bool applySoundFontProgram(tsf* f, int ch, int msb, int lsb, int program) {
    const int presetIndex = findSoundFontPreset(f, ch, msb, lsb, program);
    if (presetIndex < 0) {
        LOGE("No matching SF2 preset for channel %d, bank %d:%d, program %d",
            ch + 1, msb, lsb, program + 1);
        g_channelPresetValid[ch] = false;
        return false;
    }
    g_channelPresetValid[ch] = tsf_channel_set_presetindex(f, ch, presetIndex) != 0;
    return g_channelPresetValid[ch];
}

static float channelMidiVolumeGain(int ch) {
    const float volume = static_cast<float>(g_channelMidiVolume[ch]) / 16383.0f;
    const float expression = static_cast<float>(g_channelMidiExpression[ch]) / 16383.0f;
    const float combined = volume * expression;
    return combined * combined * combined;
}

static void applyChannelVolume(tsf* f, int ch) {
    tsf_channel_set_volume(f, ch, g_trackVolumes[ch] * channelMidiVolumeGain(ch));
}

void bqPlayerCallback(SLAndroidSimpleBufferQueueItf bq, void *context) {
    std::lock_guard<std::mutex> lock(g_audioMutex);

    if (g_soundFont != nullptr) {
        int framesLeft = BUFFER_FRAMES;
        int frameOffset = 0;
        const int SLICE_SIZE = 64;

        while (framesLeft > 0) {
            int renderBatch = std::min(framesLeft, SLICE_SIZE);

            if (isPlaying && g_arrangerEngine && g_arrangerEngine->running()) {
                uint16_t div = g_arrangerEngine->division();
                if (div == 0) div = 480;

                double ticksPerFrame = ((g_tempoBpm / 60.0) * static_cast<double>(div)) / static_cast<double>(SAMPLE_RATE);
                g_accumulatedTicks += renderBatch * ticksPerFrame;

                auto targetTick = static_cast<uint32_t>(g_accumulatedTicks);
                g_currentBeat = static_cast<int>((targetTick / div) % 4);

                if (g_arrangerEngine->advance_to(targetTick, g_renderEvents, g_renderError)) {
                    for (const auto& ev : g_renderEvents) {
                        uint8_t statusType = ev.status & 0xF0u;
                        uint8_t ch = ev.status & 0x0Fu;
                        if (ch >= 16) continue;

                        switch (statusType) {
                            case 0x90: {
                                if (ev.data2 > 0) {
                                    if ((g_acmpEnabled || ch == 9 || ch == 8) &&
                                        ((ch != 9 && ch != 8) || g_channelPresetValid[ch])) {
                                        if (g_soundFont) {
                                            tsf_channel_note_on(g_soundFont, ch, ev.data1, static_cast<float>(ev.data2) / 127.0f);
                                        }
                                    }
                                } else {
                                    if (g_soundFont) {
                                        tsf_channel_note_off(g_soundFont, ch, ev.data1);
                                    }
                                }
                                break;
                            }
                            case 0x80: {
                                if (g_soundFont) {
                                    tsf_channel_note_off(g_soundFont, ch, ev.data1);
                                }
                                break;
                            }
                            case 0xC0: {
                                g_channelProgram[ch] = ev.data1;
                                if (g_soundFont) {
                                    applySoundFontProgram(g_soundFont, ch, g_channelMsb[ch],
                                        g_channelLsb[ch], g_channelProgram[ch]);
                                }
                                break;
                            }
                            case 0xB0: {
                                uint8_t ctrl = ev.data1;
                                uint8_t val = ev.data2;
                                if (ctrl == 0) g_channelMsb[ch] = val;
                                else if (ctrl == 32) g_channelLsb[ch] = val;
                                else if (ctrl == 7) g_channelMidiVolume[ch] =
                                    static_cast<uint16_t>((g_channelMidiVolume[ch] & 0x7F) | (val << 7));
                                else if (ctrl == 39) g_channelMidiVolume[ch] =
                                    static_cast<uint16_t>((g_channelMidiVolume[ch] & 0x3F80) | val);
                                else if (ctrl == 11) g_channelMidiExpression[ch] =
                                    static_cast<uint16_t>((g_channelMidiExpression[ch] & 0x7F) | (val << 7));
                                else if (ctrl == 43) g_channelMidiExpression[ch] =
                                    static_cast<uint16_t>((g_channelMidiExpression[ch] & 0x3F80) | val);
                                else if (ctrl == 121) {
                                    g_channelMsb[ch] = 0;
                                    g_channelLsb[ch] = 0;
                                    g_channelMidiVolume[ch] = 16383;
                                    g_channelMidiExpression[ch] = 16383;
                                }

                                if (g_soundFont) {
                                    tsf_channel_midi_control(g_soundFont, ch, ctrl, val);
                                    if (ctrl == 7 || ctrl == 39 || ctrl == 11 ||
                                        ctrl == 43 || ctrl == 121) {
                                        applyChannelVolume(g_soundFont, ch);
                                    }
                                }
                                break;
                            }
                            case 0xE0: {
                                auto bend = static_cast<uint16_t>(ev.data1 | (ev.data2 << 7));
                                if (g_soundFont) {
                                    tsf_channel_set_pitchwheel(g_soundFont, ch, bend);
                                }
                                break;
                            }
                            default:
                                break;
                        }
                    }
                }
            }

            if (g_soundFont != nullptr) {
                tsf_render_float(g_soundFont, audioFrameBuffer + (frameOffset * 2), renderBatch, 0);
            } else {
                memset(audioFrameBuffer + (frameOffset * 2), 0, renderBatch * 2 * sizeof(float));
            }

            frameOffset += renderBatch;
            framesLeft -= renderBatch;
        }

        currentBufferIndex = 1 - currentBufferIndex;
        for (int i = 0; i < BUFFER_FRAMES * 2; i++) {
            float sample = audioFrameBuffer[i];
            const float magnitude = std::fabs(sample);
            constexpr float kneeStart = 0.85f;
            constexpr float kneeWidth = 1.0f - kneeStart;
            if (magnitude > kneeStart) {
                const float excess = magnitude - kneeStart;
                const float limited = kneeStart + (kneeWidth * excess) / (kneeWidth + excess);
                sample = std::copysign(limited, sample);
            }
            pcmOutputBuffer[currentBufferIndex][i] = static_cast<int16_t>(sample * 32767.0f);
        }
    } else {
        currentBufferIndex = 1 - currentBufferIndex;
        memset(pcmOutputBuffer[currentBufferIndex], 0, sizeof(pcmOutputBuffer[currentBufferIndex]));
    }

    (*bq)->Enqueue(bq, pcmOutputBuffer[currentBufferIndex], sizeof(pcmOutputBuffer[currentBufferIndex]));
}

// ========================================================================
// ENGINE SETUP
// ========================================================================
void stopAudioEngine();

bool startAudioEngine() {
    if (bqPlayerObject && bqPlayerPlay && bqPlayerBufferQueue) return true;
    if (engineObject || outputMixObject || bqPlayerObject) stopAudioEngine();

    const auto fail = []() {
        stopAudioEngine();
        return false;
    };

    SLresult result;
    result = slCreateEngine(&engineObject, 0, nullptr, 0, nullptr, nullptr);
    if (result != SL_RESULT_SUCCESS) return fail();

    result = (*engineObject)->Realize(engineObject, SL_BOOLEAN_FALSE);
    if (result != SL_RESULT_SUCCESS) return fail();

    result = (*engineObject)->GetInterface(engineObject, SL_IID_ENGINE, &engineEngine);
    if (result != SL_RESULT_SUCCESS) return fail();

    result = (*engineEngine)->CreateOutputMix(engineEngine, &outputMixObject, 0, nullptr, nullptr);
    if (result != SL_RESULT_SUCCESS) return fail();

    result = (*outputMixObject)->Realize(outputMixObject, SL_BOOLEAN_FALSE);
    if (result != SL_RESULT_SUCCESS) return fail();

    SLDataLocator_AndroidSimpleBufferQueue loc_bufq = {SL_DATALOCATOR_ANDROIDSIMPLEBUFFERQUEUE, 2};
    SLDataFormat_PCM format_pcm = {
        SL_DATAFORMAT_PCM, 2, SL_SAMPLINGRATE_48,
        SL_PCMSAMPLEFORMAT_FIXED_16, 16,
        SL_SPEAKER_FRONT_LEFT | SL_SPEAKER_FRONT_RIGHT, SL_BYTEORDER_LITTLEENDIAN
    };

    SLDataSource audioSrc = {&loc_bufq, &format_pcm};
    SLDataLocator_OutputMix loc_outmix = {SL_DATALOCATOR_OUTPUTMIX, outputMixObject};
    SLDataSink audioSnk = {&loc_outmix, nullptr};

    const SLInterfaceID ids[2] = {
        SL_IID_BUFFERQUEUE,
        SL_IID_ANDROIDCONFIGURATION
    };
    const SLboolean req[2] = {SL_BOOLEAN_TRUE, SL_BOOLEAN_FALSE};

    result = (*engineEngine)->CreateAudioPlayer(engineEngine, &bqPlayerObject, &audioSrc, &audioSnk, 2, ids, req);
    if (result != SL_RESULT_SUCCESS) return fail();

    SLAndroidConfigurationItf config = nullptr;
    if ((*bqPlayerObject)->GetInterface(bqPlayerObject, SL_IID_ANDROIDCONFIGURATION, &config) == SL_RESULT_SUCCESS) {
        const SLuint32 performanceMode = SL_ANDROID_PERFORMANCE_LATENCY;
        const SLresult configResult = (*config)->SetConfiguration(
            config,
            SL_ANDROID_KEY_PERFORMANCE_MODE,
            &performanceMode,
            sizeof(performanceMode));
        if (configResult != SL_RESULT_SUCCESS) {
            LOGE("Could not request low-latency audio mode: %u", configResult);
        }
    } else {
        LOGE("Android low-latency audio configuration is unavailable");
    }

    result = (*bqPlayerObject)->Realize(bqPlayerObject, SL_BOOLEAN_FALSE);
    if (result != SL_RESULT_SUCCESS) return fail();

    result = (*bqPlayerObject)->GetInterface(bqPlayerObject, SL_IID_PLAY, &bqPlayerPlay);
    if (result != SL_RESULT_SUCCESS) return fail();

    result = (*bqPlayerObject)->GetInterface(bqPlayerObject, SL_IID_BUFFERQUEUE, &bqPlayerBufferQueue);
    if (result != SL_RESULT_SUCCESS) return fail();

    result = (*bqPlayerBufferQueue)->RegisterCallback(bqPlayerBufferQueue, bqPlayerCallback, nullptr);
    if (result != SL_RESULT_SUCCESS) return fail();

    result = (*bqPlayerPlay)->SetPlayState(bqPlayerPlay, SL_PLAYSTATE_PLAYING);
    if (result != SL_RESULT_SUCCESS) return fail();

    currentBufferIndex = 0;
    memset(pcmOutputBuffer[currentBufferIndex], 0, sizeof(pcmOutputBuffer[currentBufferIndex]));
    result = (*bqPlayerBufferQueue)->Enqueue(bqPlayerBufferQueue, pcmOutputBuffer[currentBufferIndex], sizeof(pcmOutputBuffer[currentBufferIndex]));
    if (result != SL_RESULT_SUCCESS) return fail();
    return true;
}

void stopAudioEngine() {
    if (bqPlayerPlay) (*bqPlayerPlay)->SetPlayState(bqPlayerPlay, SL_PLAYSTATE_STOPPED);
    if (bqPlayerObject) { (*bqPlayerObject)->Destroy(bqPlayerObject); bqPlayerObject = nullptr; bqPlayerPlay = nullptr; bqPlayerBufferQueue = nullptr; }
    if (outputMixObject) { (*outputMixObject)->Destroy(outputMixObject); outputMixObject = nullptr; }
    if (engineObject) { (*engineObject)->Destroy(engineObject); engineObject = nullptr; engineEngine = nullptr; }
}

// ========================================================================
// JNI METHODS
// ========================================================================
extern "C" JNIEXPORT jint JNICALL Java_com_example_MainActivity_nativeGetCurrentBeat(JNIEnv *env, jobject thiz) {
    std::lock_guard<std::mutex> lock(g_audioMutex);
    return isPlaying ? g_currentBeat : -1;
}

extern "C" JNIEXPORT jstring JNICALL Java_com_example_MainActivity_nativePlayArranger(JNIEnv *env, jobject thiz) {
    std::lock_guard<std::mutex> lock(g_audioMutex);
    if (isPlaying) {
        isPlaying = false;
        if (g_soundFont) {
            tsf_note_off_all(g_soundFont);
            for (int i = 0; i < 16; i++) {
                tsf_channel_sounds_off_all(g_soundFont, i);
            }
        }
        if (g_arrangerEngine) {
            g_arrangerEngine->stop();
        }
        g_accumulatedTicks = 0.0;
        g_currentBeat = 0;
        return env->NewStringUTF("Arranger Stopped.");
    }

    if (!g_soundFont) return env->NewStringUTF("Muat file SF2 terlebih dahulu.");
    if (!g_arrangerEngine) return env->NewStringUTF("Muat file Style terlebih dahulu.");
    if (!startAudioEngine()) return env->NewStringUTF("Gagal memulai output audio.");

    std::string err;
    if (!g_arrangerEngine->start(err)) {
        LOGE("Failed to start arranger: %s", err.c_str());
        return env->NewStringUTF(("Gagal memulai Style: " + err).c_str());
    }

    tsf_note_off_all(g_soundFont);
    g_accumulatedTicks = 0.0;
    g_currentBeat = 0;
    isPlaying = true;
    LOGI("Arranger playback started");
    return env->NewStringUTF("Arranger Playing...");
}

static const char* loadSoundFontFromFd(int fd, bool allowCopyFallback) {
    struct stat st{};
    if (fstat(fd, &st) < 0 || !S_ISREG(st.st_mode)) {
        if (allowCopyFallback) return "SF2_DIRECT_MAP_UNAVAILABLE";
        LOGE("fstat failed");
        return "Gagal Membaca File SF2 Secara Langsung";
    }

    auto fileSize = static_cast<size_t>(st.st_size);
    if (fileSize == 0) {
        return "Ukuran File SF2 0 Byte";
    }
    if (fileSize > static_cast<size_t>(INT_MAX)) {
        return "Ukuran SF2 melebihi batas parser (2 GB).";
    }

    // Samples stay file-backed; only pages used during playback need to enter memory.
    void *mappedData = mmap(nullptr, fileSize, PROT_READ, MAP_SHARED, fd, 0);
    if (mappedData == MAP_FAILED) {
        if (allowCopyFallback) return "SF2_DIRECT_MAP_UNAVAILABLE";
        LOGE("mmap failed for file size: %zu", fileSize);
        return "Gagal Memory Mapping File SF2";
    }

    (void)madvise(mappedData, fileSize, MADV_RANDOM);
    tsf *newSf = tsf_load_memory_mapped(mappedData, static_cast<int>(fileSize));
    if (!newSf) {
        munmap(mappedData, fileSize);
        LOGE("Failed to parse SoundFont from mmapped memory");
        return "Gagal Muat SF2: Format tidak valid atau memori tidak cukup";
    }

    tsf_set_output(newSf, TSF_STEREO_INTERLEAVED, SAMPLE_RATE, -12.0f);
    if (!tsf_set_max_voices(newSf, MAX_SOUNDFONT_VOICES)) {
        tsf_close(newSf);
        munmap(mappedData, fileSize);
        LOGE("Failed to allocate %d SoundFont voices", MAX_SOUNDFONT_VOICES);
        return "Gagal Menyediakan Memori Voice SF2";
    }

    MmappedSoundFont newMmappedSf;
    newMmappedSf.data = mappedData;
    newMmappedSf.size = fileSize;
    newMmappedSf.fd = -1;
    newMmappedSf.soundfont = newSf;

    MmappedSoundFont oldSf;
    {
        std::lock_guard<std::mutex> lock(g_audioMutex);
        oldSf = g_mmappedSf;
        g_mmappedSf = newMmappedSf;
        g_soundFont = newSf;

        for (int i = 0; i < 16; i++) {
            g_channelMsb[i] = 0;
            g_channelLsb[i] = 0;
            g_channelProgram[i] = 0;
            g_channelMidiVolume[i] = 16383;
            g_channelMidiExpression[i] = 16383;
            tsf_channel_midi_control(g_soundFont, i, 121, 0);
            applySoundFontProgram(g_soundFont, i, g_channelMsb[i], g_channelLsb[i],
                g_channelProgram[i]);
            applyChannelVolume(g_soundFont, i);
        }
        startAudioEngine();
    }

    // Release the previous SoundFont after the callback has stopped using it.
    freeMmappedSf(oldSf);

    LOGI("SoundFont loaded with mapped samples (%zu MB)", fileSize / (1024 * 1024));
    return "SF2 Berhasil Dimuat (hemat memori)!";
}

// ULTRA-FAST MMAP SOUNDFONT LOADER: maps samples from the selected file without copying them to heap.
extern "C" JNIEXPORT jstring JNICALL Java_com_example_MainActivity_nativeLoadSoundFontPath(JNIEnv *env, jobject thiz, jstring pathStr) {
    if (pathStr == nullptr) return env->NewStringUTF("Error: Path Null");

    const char *path = env->GetStringUTFChars(pathStr, nullptr);
    if (!path) return env->NewStringUTF("Error: JNI GetStringUTFChars Failed");

    int fd = open(path, O_RDONLY);
    env->ReleaseStringUTFChars(pathStr, path);
    if (fd < 0) {
        LOGE("Failed to open SoundFont file");
        return env->NewStringUTF("Gagal Membuka File SF2");
    }

    const char* result = loadSoundFontFromFd(fd, false);
    close(fd);
    return env->NewStringUTF(result);
}

// NON-BLOCKING Style Loader: Parses style runtime outside audio mutex
extern "C" JNIEXPORT jstring JNICALL Java_com_example_MainActivity_nativeLoadStylePath(JNIEnv *env, jobject thiz, jstring pathStr) {
    if (pathStr == nullptr) return env->NewStringUTF("Error: Path Null");

    const char *path = env->GetStringUTFChars(pathStr, nullptr);
    if (!path) return env->NewStringUTF("Error: JNI GetStringUTFChars Failed");

    arranger::YamahaStyleRuntime newRuntime;
    std::string err;
    bool ok = newRuntime.load(path, err);
    env->ReleaseStringUTFChars(pathStr, path);

    if (!ok) {
        LOGE("Failed to parse Yamaha Style: %s", err.c_str());
        return env->NewStringUTF(("Gagal Parsing Style: " + err).c_str());
    }

    {
        std::lock_guard<std::mutex> lock(g_audioMutex);
        g_styleRuntime = std::move(newRuntime);
        g_arrangerEngine = std::make_unique<arranger::CppArrangerEngine>(g_styleRuntime);
        g_arrangerEngine->set_acmp(g_acmpEnabled != 0);
        g_arrangerEngine->set_transpose(g_transpose);
        g_arrangerEngine->set_chord(static_cast<uint8_t>(g_currentRootPc),
                                    static_cast<uint8_t>(g_currentChordType),
                                    static_cast<uint8_t>(g_currentBassPc),
                                    true);

        g_accumulatedTicks = 0.0;
        g_currentBeat = 0;

        if (g_soundFont) {
            for (int i = 0; i < 16; i++) {
                g_channelMsb[i] = 0;
                g_channelLsb[i] = 0;
                g_channelProgram[i] = 0;
                g_channelMidiVolume[i] = 16383;
                g_channelMidiExpression[i] = 16383;
                tsf_channel_sounds_off_all(g_soundFont, i);
                tsf_channel_midi_control(g_soundFont, i, 121, 0);
                applySoundFontProgram(g_soundFont, i, g_channelMsb[i], g_channelLsb[i],
                    g_channelProgram[i]);
                applyChannelVolume(g_soundFont, i);
            }
        }
    }

    LOGI("Yamaha Style loaded successfully.");
    return env->NewStringUTF("Style Yamaha Berhasil Dimuat!");
}

extern "C" JNIEXPORT jstring JNICALL Java_com_example_MainActivity_nativeLoadSoundFontByFd(JNIEnv *env, jobject thiz, jobject fileDescriptor) {
    if (fileDescriptor == nullptr) return env->NewStringUTF("SF2_DIRECT_MAP_UNAVAILABLE");

    jclass fdClass = env->GetObjectClass(fileDescriptor);
    jfieldID descriptorField = fdClass ? env->GetFieldID(fdClass, "descriptor", "I") : nullptr;
    if (!descriptorField) {
        if (env->ExceptionCheck()) env->ExceptionClear();
        return env->NewStringUTF("SF2_DIRECT_MAP_UNAVAILABLE");
    }

    const int fd = env->GetIntField(fileDescriptor, descriptorField);
    if (fd < 0) return env->NewStringUTF("SF2_DIRECT_MAP_UNAVAILABLE");
    return env->NewStringUTF(loadSoundFontFromFd(fd, true));
}

extern "C" JNIEXPORT jstring JNICALL Java_com_example_MainActivity_nativeLoadStyleByFd(JNIEnv *env, jobject thiz, jobject fileDescriptor) {
    return env->NewStringUTF("Deprecated: Use Path");
}

extern "C" JNIEXPORT void JNICALL Java_com_example_MainActivity_nativeNoteOn(JNIEnv *env, jobject thiz, jint note, jint velocity) {
    std::lock_guard<std::mutex> lock(g_audioMutex);
    if (g_soundFont) {
        int key = note + g_transpose;
        key = std::max(0, std::min(127, key));

        float velFloat = (float)velocity / 127.0f;
        if (velFloat < 0.1f) velFloat = 1.0f;

        tsf_channel_note_on(g_soundFont, 0, key, velFloat);
    }
}

extern "C" JNIEXPORT void JNICALL Java_com_example_MainActivity_nativeNoteOff(JNIEnv *env, jobject thiz, jint note) {
    std::lock_guard<std::mutex> lock(g_audioMutex);
    if (g_soundFont) {
        int key = note + g_transpose;
        key = std::max(0, std::min(127, key));
        tsf_channel_note_off(g_soundFont, 0, key);
    }
}

extern "C" JNIEXPORT jstring JNICALL Java_com_example_MainActivity_nativeQueueMain(JNIEnv *env, jobject thiz, jstring nameStr) {
    std::lock_guard<std::mutex> lock(g_audioMutex);
    if (!g_arrangerEngine) return env->NewStringUTF("Style Belum Dimuat");

    const char *name = env->GetStringUTFChars(nameStr, nullptr);
    std::string err;
    bool ok = g_arrangerEngine->queue_main(name ? name : "MAIN A", err);
    if (name) env->ReleaseStringUTFChars(nameStr, name);

    LOGI("Queued Main: %s (ok=%d, err=%s)", name ? name : "MAIN A", ok, err.c_str());
    return env->NewStringUTF(ok ? "MAIN Queued" : err.c_str());
}

extern "C" JNIEXPORT jstring JNICALL Java_com_example_MainActivity_nativeQueueIntro(JNIEnv *env, jobject thiz, jstring nameStr) {
    std::lock_guard<std::mutex> lock(g_audioMutex);
    if (!g_arrangerEngine) return env->NewStringUTF("Style Belum Dimuat");

    const char *name = env->GetStringUTFChars(nameStr, nullptr);
    std::string err;
    bool ok = g_arrangerEngine->queue_intro(name ? name : "INTRO A", err);
    if (name) env->ReleaseStringUTFChars(nameStr, name);

    LOGI("Queued Intro: %s (ok=%d, err=%s)", name ? name : "INTRO A", ok, err.c_str());
    return env->NewStringUTF(ok ? "INTRO Queued" : err.c_str());
}

extern "C" JNIEXPORT jstring JNICALL Java_com_example_MainActivity_nativeQueueFill(JNIEnv *env, jobject thiz, jstring nameStr) {
    std::lock_guard<std::mutex> lock(g_audioMutex);
    if (!g_arrangerEngine) return env->NewStringUTF("Style Belum Dimuat");

    const char *name = env->GetStringUTFChars(nameStr, nullptr);
    std::string err;
    bool ok = g_arrangerEngine->queue_fill(name ? name : "FILL IN AA", err);
    if (name) env->ReleaseStringUTFChars(nameStr, name);

    LOGI("Queued Fill: %s (ok=%d, err=%s)", name ? name : "FILL IN AA", ok, err.c_str());
    return env->NewStringUTF(ok ? "FILL Queued" : err.c_str());
}

extern "C" JNIEXPORT jstring JNICALL Java_com_example_MainActivity_nativeQueueEnding(JNIEnv *env, jobject thiz, jstring nameStr) {
    std::lock_guard<std::mutex> lock(g_audioMutex);
    if (!g_arrangerEngine) return env->NewStringUTF("Style Belum Dimuat");

    const char *name = env->GetStringUTFChars(nameStr, nullptr);
    std::string err;
    bool ok = g_arrangerEngine->queue_ending(name ? name : "ENDING A", err);
    if (name) env->ReleaseStringUTFChars(nameStr, name);

    LOGI("Queued Ending: %s (ok=%d, err=%s)", name ? name : "ENDING A", ok, err.c_str());
    return env->NewStringUTF(ok ? "ENDING Queued" : err.c_str());
}

extern "C" JNIEXPORT void JNICALL Java_com_example_MainActivity_nativeSetTempo(JNIEnv *env, jobject thiz, jdouble bpm) {
    std::lock_guard<std::mutex> lock(g_audioMutex);
    if (bpm >= 40.0 && bpm <= 280.0) {
        g_tempoBpm = bpm;
        LOGI("Tempo updated: %.1f BPM", g_tempoBpm);
    }
}

extern "C" JNIEXPORT void JNICALL Java_com_example_MainActivity_nativeSetTranspose(JNIEnv *env, jobject thiz, jint semitones) {
    std::lock_guard<std::mutex> lock(g_audioMutex);
    if (semitones >= -24 && semitones <= 24) {
        g_transpose = semitones;
        if (g_arrangerEngine) {
            g_arrangerEngine->set_transpose(semitones);
        }
        LOGI("Transpose updated: %d semitones", g_transpose);
    }
}

extern "C" JNIEXPORT void JNICALL Java_com_example_MainActivity_nativeSetChord(JNIEnv *env, jobject thiz, jint rootPc, jint chordType, jint bassPc) {
    std::lock_guard<std::mutex> lock(g_audioMutex);
    g_currentRootPc = rootPc;
    g_currentChordType = chordType;
    g_currentBassPc = bassPc;

    if (g_arrangerEngine) {
        g_arrangerEngine->set_chord(static_cast<uint8_t>(rootPc),
                                    static_cast<uint8_t>(chordType),
                                    static_cast<uint8_t>(bassPc),
                                    true);
    }
}

extern "C" JNIEXPORT void JNICALL Java_com_example_MainActivity_nativeSetAcmp(JNIEnv *env, jobject thiz, jint enabled) {
    std::lock_guard<std::mutex> lock(g_audioMutex);
    g_acmpEnabled = enabled;
    if (g_arrangerEngine) {
        g_arrangerEngine->set_acmp(enabled != 0);
    }
    if (enabled == 0 && g_soundFont) {
        for (int i = 0; i < 16; i++) {
            if (i != 8 && i != 9) {
                tsf_channel_sounds_off_all(g_soundFont, i);
            }
        }
    }
    LOGI("ACMP state updated: %d", g_acmpEnabled);
}

extern "C" JNIEXPORT void JNICALL Java_com_example_MainActivity_nativeSetTrackVolume(JNIEnv *env, jobject thiz, jint channel, jint volume) {
    std::lock_guard<std::mutex> lock(g_audioMutex);
    if (channel >= 0 && channel < 16) {
        float volFloat = (float)volume / 127.0f;
        g_trackVolumes[channel] = volFloat;
        if (g_soundFont) {
            applyChannelVolume(g_soundFont, channel);
        }
    }
}

extern "C" JNIEXPORT void JNICALL JNI_OnUnload(JavaVM *vm, void *reserved) {
    stopAudioEngine();
    std::lock_guard<std::mutex> lock(g_audioMutex);
    freeMmappedSf(g_mmappedSf);
    if (g_arrangerEngine) { g_arrangerEngine->stop(); g_arrangerEngine.reset(); }
}
