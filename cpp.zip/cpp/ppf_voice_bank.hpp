#pragma once

#include "ppf_reader.hpp"
#include <array>
#include <cstddef>
#include <cstdint>
#include <string>
#include <unordered_map>
#include <vector>

namespace arranger {

// C++ representation of the installed PPF Voice Bank.
// The routing contract mirrors the proven Yamaha-side behavior:
//   1) exact MSB + LSB + Program match
//   2) otherwise, MSB + Program alias only when that MSB has exactly one
//      unambiguous source LSB in the installed PPF pack
// Program-only lookup is never used for runtime routing.
class PpfInstalledVoiceBank {
public:
    static constexpr std::size_t kPartCount = 16;
    static constexpr std::size_t kRhythm1Channel = 8; // MIDI CH9, zero-based
    static constexpr std::size_t kRhythm2Channel = 9; // MIDI CH10, zero-based

    bool install(const PpfReader& reader, std::string& error);
    void clear() noexcept;

    std::size_t voice_count() const noexcept { return voices_.size(); }
    const std::vector<PpfVoiceDescriptor>& voices() const noexcept { return voices_; }

    const PpfVoiceDescriptor* resolve(std::uint8_t midi_channel,
                                      std::uint8_t msb,
                                      std::uint8_t lsb,
                                      std::uint8_t program) const noexcept;

    bool set_channel_address(std::uint8_t midi_channel,
                             std::uint8_t msb,
                             std::uint8_t lsb,
                             std::uint8_t program) noexcept;

    const PpfVoiceDescriptor* resolve_channel(std::uint8_t midi_channel) const noexcept;

    void reset_channel_addresses() noexcept;
    bool has_channel_address(std::uint8_t midi_channel) const noexcept;

private:
    struct AddressKey {
        std::uint8_t msb = 0;
        std::uint8_t lsb = 0;
        std::uint8_t program = 0;
        bool operator==(const AddressKey& other) const noexcept {
            return msb == other.msb && lsb == other.lsb && program == other.program;
        }
    };
    struct AddressHash {
        std::size_t operator()(const AddressKey& k) const noexcept {
            return (static_cast<std::size_t>(k.msb) << 14) ^
                   (static_cast<std::size_t>(k.lsb) << 7) ^
                   static_cast<std::size_t>(k.program);
        }
    };
    struct MsbPcKey {
        std::uint8_t msb = 0;
        std::uint8_t program = 0;
        bool operator==(const MsbPcKey& other) const noexcept {
            return msb == other.msb && program == other.program;
        }
    };
    struct MsbPcHash {
        std::size_t operator()(const MsbPcKey& k) const noexcept {
            return (static_cast<std::size_t>(k.msb) << 7) ^ static_cast<std::size_t>(k.program);
        }
    };

    std::vector<PpfVoiceDescriptor> voices_;
    std::unordered_map<AddressKey, std::size_t, AddressHash> exact_;
    std::unordered_map<MsbPcKey, std::vector<std::size_t>, MsbPcHash> by_msb_pc_;
    std::unordered_map<std::uint8_t, std::vector<std::uint8_t>> lsbs_by_msb_;
    std::array<std::uint8_t, kPartCount> channel_msb_{};
    std::array<std::uint8_t, kPartCount> channel_lsb_{};
    std::array<std::uint8_t, kPartCount> channel_program_{};
    std::array<bool, kPartCount> channel_address_set_{};
};

} // namespace arranger
