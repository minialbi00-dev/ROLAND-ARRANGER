#pragma once

#include <stddef.h>
#include <stdint.h>

#ifdef _WIN32
#define YPA_EXPORT extern "C" __declspec(dllexport)
#define YPA_CALL __cdecl
#else
#define YPA_EXPORT extern "C"
#define YPA_CALL
#endif

#ifdef __cplusplus
extern "C" {
#endif

typedef struct YpaPpfBankInfo {
    uint64_t bank_id;
    uint8_t installed_msb;
    uint8_t installed_lsb;
    uint32_t voice_count;
} YpaPpfBankInfo;

typedef struct YpaPpfVoiceInfo {
    uint64_t bank_id;
    uint64_t source_index;
    uint8_t source_msb;
    uint8_t source_lsb;
    uint8_t source_program;
    uint8_t installed_msb;
    uint8_t installed_lsb;
    uint8_t installed_program;
    uint8_t source_address_valid;
    uint8_t installed_address_valid;
    uint32_t zone_count;
    uint32_t resident_zone_count;
    char title[256];
    char source_path[512];
    char voice_type[64];
} YpaPpfVoiceInfo;

typedef struct YpaAudioStats {
    uint32_t output_rate;
    uint32_t buffer_frames;
    uint32_t ppf_voices;
    uint32_t ppf_banks;
    uint32_t resident_zones;
    uint32_t unique_pcm;
    uint64_t resident_pcm_bytes;
    uint32_t active_voices;
    uint64_t rendered_frames;
    uint64_t nonzero_samples;
    uint64_t nonfinite_samples;
    uint64_t deadline_misses;
    uint64_t dropped_events;
    uint64_t events_processed;
    uint64_t max_render_us;
    uint32_t peak_milli;
    uint8_t active;
    double buffer_latency_ms;
} YpaAudioStats;

YPA_EXPORT void* YPA_CALL ypa_create(char* error_buf, size_t error_cap);
YPA_EXPORT void YPA_CALL ypa_destroy(void* handle);
YPA_EXPORT int YPA_CALL ypa_load_soundfont(void* handle, const char* sf2_path,
                                           char* error_buf, size_t error_cap);
YPA_EXPORT int YPA_CALL ypa_has_soundfont(void* handle);

YPA_EXPORT int YPA_CALL ypa_install_ppf(void* handle,
                                        const char* ppf_path,
                                        uint8_t installed_msb,
                                        uint8_t installed_lsb,
                                        char* error_buf,
                                        size_t error_cap);

// Pass installed_msb=0xFF and installed_lsb=0xFF to preserve the exact PPF source slot.
// Any explicitly supplied slot must match the PPF source MSB/LSB; the engine never renumbers.
YPA_EXPORT int YPA_CALL ypa_uninstall_ppf(void* handle,
                                          uint64_t bank_id,
                                          char* error_buf,
                                          size_t error_cap);

YPA_EXPORT size_t YPA_CALL ypa_get_ppf_bank_count(void* handle);
YPA_EXPORT int YPA_CALL ypa_get_ppf_bank_info(void* handle,
                                              size_t index,
                                              YpaPpfBankInfo* out_info);

YPA_EXPORT size_t YPA_CALL ypa_get_ppf_voice_count(void* handle);
YPA_EXPORT int YPA_CALL ypa_get_ppf_voice_info(void* handle,
                                               size_t index,
                                               YpaPpfVoiceInfo* out_info);

// Returns 1 when the exact source/installed Voice resolves and is resident,
// 0 when no Voice matches the supplied MSB/LSB/PC, and -1 on an actual error.
YPA_EXPORT int YPA_CALL ypa_preload_voice(void* handle,
                                          uint8_t msb,
                                          uint8_t lsb,
                                          uint8_t program,
                                          char* error_buf,
                                          size_t error_cap);

YPA_EXPORT int YPA_CALL ypa_start(void* handle,
                                  double bpm,
                                  uint16_t division,
                                  char* error_buf,
                                  size_t error_cap);
YPA_EXPORT void YPA_CALL ypa_stop(void* handle);
YPA_EXPORT int YPA_CALL ypa_active(void* handle);

YPA_EXPORT int YPA_CALL ypa_set_timing(void* handle, double bpm, uint16_t division);
YPA_EXPORT void YPA_CALL ypa_reanchor(void* handle, uint32_t tick);

// Timestamp is supplied by the Original Baseline clock adapter. The audio
// engine only schedules/renderers the already-transformed MIDI bytes; it does
// not parse Style/CASM/chord/section semantics.
YPA_EXPORT int YPA_CALL ypa_enqueue_midi(void* handle,
                                          uint32_t tick,
                                          uint8_t status,
                                          uint8_t data1,
                                          uint8_t data2);

YPA_EXPORT void YPA_CALL ypa_get_stats(void* handle, YpaAudioStats* out_stats);

#ifdef __cplusplus
}
#endif
