#pragma once

#include "voice_install_catalog.hpp"
#include "yamaha_style_runtime.hpp"
#include <array>
#include <cstdint>
#include <string>
#include <vector>

namespace arranger {

// Generic Style -> installed Voice resolver. This is the C++ product-layer
// router shared by PPF and YEP installations. It preserves the existing
// Yamaha/CASM channel semantics and delegates the address decision to the
// InstalledVoiceCatalog.
class InstalledStyleVoiceRouter {
public:
    bool scan(const YamahaStyleRuntime& style,
              const InstalledVoiceCatalog& catalog,
              std::vector<InstalledVoiceResolution>& out,
              std::string& error) const;

private:
    static std::uint8_t channel_for_event(const YamahaStyleRuntime& style,
                                          const YamahaStyleMidiEvent& e) noexcept;
    static bool is_bank_cc(const YamahaStyleMidiEvent& e) noexcept;
    static bool is_program_change(const YamahaStyleMidiEvent& e) noexcept;
};

} // namespace arranger
