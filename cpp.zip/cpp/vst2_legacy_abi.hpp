#pragma once

#include <cstddef>
#include <cstdint>
#include <cstring>

#if defined(_WIN32)
  #define VSTCALLBACK __cdecl
  #define VST_EXPORT extern "C" __declspec(dllexport)
#else
  #define VSTCALLBACK
  #define VST_EXPORT extern "C"
#endif

namespace vst2mini {

using VstInt32 = std::int32_t;
using VstIntPtr = std::intptr_t;

struct AEffect;
using audioMasterCallback = VstIntPtr (VSTCALLBACK *)(AEffect*, VstInt32, VstInt32, VstIntPtr, void*, float);
using AEffectDispatcherProc = VstIntPtr (VSTCALLBACK *)(AEffect*, VstInt32, VstInt32, VstIntPtr, void*, float);
using AEffectProcessProc = void (VSTCALLBACK *)(AEffect*, float**, float**, VstInt32);
using AEffectProcessDoubleProc = void (VSTCALLBACK *)(AEffect*, double**, double**, VstInt32);
using AEffectSetParameterProc = void (VSTCALLBACK *)(AEffect*, VstInt32, float);
using AEffectGetParameterProc = float (VSTCALLBACK *)(AEffect*, VstInt32);

constexpr VstInt32 cconst(char a, char b, char c, char d) noexcept {
    return (static_cast<VstInt32>(static_cast<unsigned char>(a)) << 24) |
           (static_cast<VstInt32>(static_cast<unsigned char>(b)) << 16) |
           (static_cast<VstInt32>(static_cast<unsigned char>(c)) << 8) |
           (static_cast<VstInt32>(static_cast<unsigned char>(d)));
}

constexpr VstInt32 kEffectMagic = cconst('V','s','t','P');
constexpr VstInt32 kVstMidiType = 1;
constexpr VstInt32 kVstSysExType = 6;

// VST 2.x effect flags.
enum : VstInt32 {
    effFlagsCanReplacing = 1 << 4,
    effFlagsIsSynth      = 1 << 8,
};

// Host -> plugin dispatcher opcodes.
enum : VstInt32 {
    effOpen = 0,
    effClose = 1,
    effSetProgram = 2,
    effSetSampleRate = 10,
    effSetBlockSize = 11,
    effMainsChanged = 12,
    effProcessEvents = 25,
    effGetEffectName = 45,
    effGetVendorString = 47,
    effGetProductString = 48,
    effGetVendorVersion = 49,
    effCanDo = 51,
    effGetVstVersion = 58,
    effGetPlugCategory = 35,
};

// Plug-in category values.
constexpr VstInt32 kPlugCategSynth = 2;

// Host callback opcodes.
enum : VstInt32 {
    audioMasterWantMidi = 6,
    audioMasterGetTime = 7,
    audioMasterProcessEvents = 8,
    audioMasterGetSampleRate = 16,
    audioMasterGetBlockSize = 17,
};

struct VstEvent {
    VstInt32 type;
    VstInt32 byteSize;
    VstInt32 deltaFrames;
    VstInt32 flags;
    char data[16];
};

struct VstMidiEvent {
    VstInt32 type;
    VstInt32 byteSize;
    VstInt32 deltaFrames;
    VstInt32 flags;
    VstInt32 noteLength;
    VstInt32 noteOffset;
    char midiData[4];
    char detune;
    char noteOffVelocity;
    char reserved1;
    char reserved2;
};

struct VstSysExEvent {
    VstInt32 type;
    VstInt32 byteSize;
    VstInt32 deltaFrames;
    VstInt32 flags;
    VstInt32 dumpBytes;
    VstIntPtr resvd1;
    char* sysexDump;
    VstIntPtr resvd2;
};

struct VstEvents {
    VstInt32 numEvents;
    VstIntPtr reserved;
    VstEvent* events[2];
};

struct AEffect {
    VstInt32 magic;
    AEffectDispatcherProc dispatcher;
    AEffectProcessProc process;
    AEffectSetParameterProc setParameter;
    AEffectGetParameterProc getParameter;
    VstInt32 numPrograms;
    VstInt32 numParams;
    VstInt32 numInputs;
    VstInt32 numOutputs;
    VstInt32 flags;
    VstIntPtr resvd1;
    VstIntPtr resvd2;
    VstInt32 initialDelay;
    VstInt32 realQualities;
    VstInt32 offQualities;
    float ioRatio;
    void* object;
    void* user;
    VstInt32 uniqueID;
    VstInt32 version;
    AEffectProcessProc processReplacing;
    AEffectProcessDoubleProc processDoubleReplacing;
    char future[56];
};

static_assert(offsetof(AEffect, dispatcher) == (sizeof(void*) == 8 ? 8u : 4u));
static_assert(offsetof(AEffect, processReplacing) == (sizeof(void*) == 8 ? 120u : 80u));
static_assert(sizeof(VstMidiEvent) == 32);
static_assert(offsetof(VstMidiEvent, midiData) == 24);
static_assert(offsetof(VstSysExEvent, sysexDump) == (sizeof(void*) == 8 ? 32u : 24u));

} // namespace vst2mini

using vst2mini::AEffect;
using vst2mini::audioMasterCallback;
using vst2mini::VstEvent;
using vst2mini::VstEvents;
using vst2mini::VstMidiEvent;
using vst2mini::VstSysExEvent;
