#pragma once
#include "arranger_engine.hpp"
#include "vst2_legacy_abi.hpp"
#include <array>
#include <cstddef>
#include <cstdint>
#include <string>
#include <vector>

namespace arranger {

struct VstMidiPacket {
    std::int32_t delta_frames = 0;
    std::array<std::uint8_t, 3> midi{};
};

class Vst2StyleEventSink {
public:
    bool push(const ArrangerOutputEvent& event,
              std::uint32_t block_start_tick,
              double frames_per_tick,
              std::size_t block_frames,
              std::string& error);
    void clear() noexcept { packets_.clear(); }
    const std::vector<VstMidiPacket>& packets() const noexcept { return packets_; }

    bool build_events(VstEvents* out,
                      std::vector<VstMidiEvent>& storage,
                      std::vector<VstEvent*>& pointers,
                      std::string& error) const;

private:
    std::vector<VstMidiPacket> packets_;
};

} // namespace arranger
