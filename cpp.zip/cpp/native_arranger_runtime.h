#pragma once

#include <stddef.h>
#include <stdint.h>

#ifdef _WIN32
#define YAR_EXPORT extern "C" __declspec(dllexport)
#define YAR_CALL __cdecl
#else
#define YAR_EXPORT extern "C"
#define YAR_CALL
#endif

#ifdef __cplusplus
extern "C" {
#endif

typedef struct YarNativeState {
    uint8_t running;
    uint8_t audio_active;
    uint8_t scheduler_active;
    uint8_t acmp_enabled;
    int16_t transpose;
    uint16_t division;
    uint32_t transport_tick;
    uint32_t bar_ticks;
    double bpm;
    char current_section[64];
    char active_main[64];
} YarNativeState;


typedef struct YarPerformanceState {
    uint8_t acmp_enabled;
    uint8_t note_gate;
    uint8_t finger_mode;
    int16_t transpose;
    uint8_t chord_root_pc;
    uint8_t chord_type;
    char chord_name[32];
    uint8_t held_notes[128];
    uint16_t held_note_count;
    uint64_t note_on_count;
    uint64_t note_off_count;
    uint8_t chord_bass_pc;
    uint8_t chord_bass_valid;
    uint8_t split_point;
    uint8_t smart_chord_key_pc;
    uint8_t smart_chord_type;
} YarPerformanceState;

typedef struct YarNativeAudioStats {
    uint32_t output_rate;
    uint32_t buffer_frames;
    uint32_t ppf_voices;
    uint32_t ppf_banks;
    uint32_t resident_zones;
    uint32_t unique_pcm;
    uint64_t resident_pcm_bytes;
    uint32_t active_voices;
    uint64_t rendered_frames;
    uint64_t nonzero_samples;
    uint64_t nonfinite_samples;
    uint64_t deadline_misses;
    uint64_t dropped_events;
    uint64_t events_processed;
    uint64_t max_render_us;
    uint32_t peak_milli;
    uint8_t active;
    double buffer_latency_ms;
} YarNativeAudioStats;

YAR_EXPORT void* YAR_CALL yar_create(char* error_buf, size_t error_cap);
YAR_EXPORT void YAR_CALL yar_destroy(void* handle);
YAR_EXPORT int YAR_CALL yar_load_style(void* handle, const char* style_path, char* error_buf, size_t error_cap);
YAR_EXPORT int YAR_CALL yar_install_ppf(void* handle, const char* ppf_path, uint8_t installed_msb, uint8_t installed_lsb, char* error_buf, size_t error_cap);
YAR_EXPORT int YAR_CALL yar_uninstall_ppf(void* handle, uint64_t bank_id, char* error_buf, size_t error_cap);
YAR_EXPORT int YAR_CALL yar_start(void* handle, char* error_buf, size_t error_cap);
YAR_EXPORT void YAR_CALL yar_stop(void* handle);
YAR_EXPORT int YAR_CALL yar_running(void* handle);
YAR_EXPORT int YAR_CALL yar_queue_main(void* handle, const char* name, char* error_buf, size_t error_cap);
YAR_EXPORT int YAR_CALL yar_queue_fill(void* handle, const char* name, char* error_buf, size_t error_cap);
YAR_EXPORT int YAR_CALL yar_queue_intro(void* handle, const char* name, char* error_buf, size_t error_cap);
YAR_EXPORT int YAR_CALL yar_queue_ending(void* handle, const char* name, char* error_buf, size_t error_cap);
YAR_EXPORT void YAR_CALL yar_set_acmp(void* handle, int enabled);
YAR_EXPORT void YAR_CALL yar_set_chord(void* handle, uint8_t root_pc, uint8_t chord_type);
YAR_EXPORT void YAR_CALL yar_set_transpose(void* handle, int semitones);
YAR_EXPORT void YAR_CALL yar_set_tempo(void* handle, double bpm);
YAR_EXPORT int YAR_CALL yar_set_audio_output_device(void* handle, const char* device_id, char* error_buf, size_t error_cap);
YAR_EXPORT int YAR_CALL yar_get_audio_output_device(void* handle, char* out, size_t out_cap);
YAR_EXPORT size_t YAR_CALL yar_audio_output_device_count(void);
YAR_EXPORT int YAR_CALL yar_audio_output_device_name(size_t index, char* out, size_t out_cap);
YAR_EXPORT int YAR_CALL yar_audio_output_device_id(size_t index, char* out, size_t out_cap);
YAR_EXPORT size_t YAR_CALL yar_midi_input_device_count(void);
YAR_EXPORT int YAR_CALL yar_midi_input_device_name(size_t index, char* out, size_t out_cap);
YAR_EXPORT int YAR_CALL yar_midi_input_open(void* handle, uint32_t device_index, char* error_buf, size_t error_cap);
YAR_EXPORT void YAR_CALL yar_midi_input_close(void* handle);
YAR_EXPORT int YAR_CALL yar_midi_input_active(void* handle);
YAR_EXPORT void YAR_CALL yar_midi_input(void* handle, uint8_t status, uint8_t data1, uint8_t data2);
YAR_EXPORT void YAR_CALL yar_clear_performance_notes(void* handle);
YAR_EXPORT void YAR_CALL yar_set_finger_mode(void* handle, uint8_t mode);
YAR_EXPORT void YAR_CALL yar_set_split_point(void* handle, int note);
YAR_EXPORT void YAR_CALL yar_set_smart_chord_key(void* handle, int root_pc);
YAR_EXPORT void YAR_CALL yar_set_smart_chord_type(void* handle, uint8_t type);
YAR_EXPORT int YAR_CALL yar_get_performance_state(void* handle, YarPerformanceState* out_state);
YAR_EXPORT int YAR_CALL yar_get_state(void* handle, YarNativeState* out_state);
YAR_EXPORT void YAR_CALL yar_get_audio_stats(void* handle, YarNativeAudioStats* out_stats);
#ifdef __cplusplus
}
#endif
