#include "native_arranger_runtime.hpp"

#include <algorithm>
#include <cmath>
#include <sstream>
#include <limits>
#ifdef _WIN32
#ifndef NOMINMAX
#define NOMINMAX
#endif
#include <windows.h>
#include <mmsystem.h>
#endif

namespace arranger {

NativeArrangerRuntime::NativeArrangerRuntime() = default;

NativeArrangerRuntime::~NativeArrangerRuntime() {
    close_midi_input();
    stop();
}

bool NativeArrangerRuntime::require_engine(std::string& error) const noexcept {
    if (!engine_) {
        error = "no Style loaded into native arranger runtime";
        return false;
    }
    return true;
}

void NativeArrangerRuntime::reset_clock_locked(Clock::time_point now) noexcept {
    clock_anchor_ = now;
    tick_anchor_ = engine_ ? engine_->current_tick() : 0;
    last_scheduled_tick_.store(tick_anchor_, std::memory_order_release);
}

std::uint32_t NativeArrangerRuntime::clock_tick_locked(Clock::time_point now) const noexcept {
    if (!engine_) return tick_anchor_;
    const double elapsed = std::chrono::duration<double>(now - clock_anchor_).count();
    const double ticks_per_second = std::max(1.0, bpm_) *
                                    static_cast<double>(std::max<std::uint16_t>(1, engine_->division())) /
                                    60.0;
    const double tick_value = static_cast<double>(tick_anchor_) + std::max(0.0, elapsed) * ticks_per_second;
    if (tick_value <= 0.0) return 0;
    if (tick_value >= static_cast<double>(std::numeric_limits<std::uint32_t>::max()))
        return std::numeric_limits<std::uint32_t>::max();
    return static_cast<std::uint32_t>(std::floor(tick_value));
}

bool NativeArrangerRuntime::load_style(const std::string& style_path, std::string& error) {
    error.clear();
    stop();
    YamahaStyleRuntime fresh;
    if (!fresh.load(style_path, error)) return false;
    {
        std::lock_guard<std::mutex> lock(mutex_);
        performance_.reset();
        style_ = std::move(fresh);
        // CppArrangerEngine stores a reference to YamahaStyleRuntime, so it
        // must be constructed only after the owning style_ has its final
        // address. Never bind the engine to a temporary/moved-from Style.
        engine_ = std::make_unique<CppArrangerEngine>(style_);
        bpm_ = std::clamp(style_.summary().tempo_bpm, 30.0, 300.0);
        reset_clock_locked(Clock::now());
    }
    if (!audio_.prepare_style(style_, error)) {
        std::lock_guard<std::mutex> lock(mutex_);
        engine_.reset();
        return false;
    }
    error.clear();
    return true;
}

bool NativeArrangerRuntime::install_ppf(const std::string& ppf_path,
                                         InstalledVoiceAddress installed_base,
                                         std::string& error) {
    std::lock_guard<std::mutex> lock(mutex_);
    if (scheduler_running_.load(std::memory_order_acquire) || audio_.is_active()) {
        error = "PPF Voice banks cannot be installed while native arranger is running";
        return false;
    }
    if (!audio_.install_ppf_bank_audio_only(ppf_path, installed_base, error)) return false;
    if (engine_ && !audio_.prepare_style(style_, error)) return false;
    return true;
}

bool NativeArrangerRuntime::uninstall_ppf(std::size_t bank_id, std::string& error) {
    std::lock_guard<std::mutex> lock(mutex_);
    if (scheduler_running_.load(std::memory_order_acquire) || audio_.is_active()) {
        error = "PPF Voice banks cannot be uninstalled while native arranger is running";
        return false;
    }
    return audio_.uninstall_ppf_bank(bank_id, error);
}

bool NativeArrangerRuntime::start(std::string& error) {
    error.clear();
    {
        std::lock_guard<std::mutex> lock(mutex_);
        if (!require_engine(error)) return false;
        if (scheduler_running_.load(std::memory_order_acquire)) return true;
        if (!engine_->start(error)) return false;
        bpm_ = std::clamp(bpm_, 30.0, 300.0);
        reset_clock_locked(Clock::now());
    }

    // Start the native audio sink before the scheduler pump so tick-zero events
    // are accepted immediately. The scheduler remains the only producer.
    if (!audio_.start(bpm_, engine_->division(), error)) {
        std::lock_guard<std::mutex> lock(mutex_);
        engine_->stop();
        return false;
    }

    scheduler_running_.store(true, std::memory_order_release);
    try {
        scheduler_thread_ = std::thread([this] { scheduler_thread_main(); });
    } catch (...) {
        scheduler_running_.store(false, std::memory_order_release);
        audio_.stop();
        std::lock_guard<std::mutex> lock(mutex_);
        if (engine_) engine_->stop();
        error = "failed to create native arranger scheduler thread";
        return false;
    }
    return true;
}

void NativeArrangerRuntime::stop() noexcept {
    scheduler_running_.store(false, std::memory_order_release);
    if (scheduler_thread_.joinable()) scheduler_thread_.join();
    audio_.stop();
    std::lock_guard<std::mutex> lock(mutex_);
    if (engine_) engine_->stop();
    reset_clock_locked(Clock::now());
}


bool NativeArrangerRuntime::start_scheduler_only_for_test(std::string& error) {
    error.clear();
    std::lock_guard<std::mutex> lock(mutex_);
    if (!require_engine(error)) return false;
    if (scheduler_running_.load(std::memory_order_acquire)) return true;
    if (!engine_->start(error)) return false;
    bpm_ = std::clamp(bpm_, 30.0, 300.0);
    reset_clock_locked(Clock::now());
    scheduler_running_.store(true, std::memory_order_release);
    try {
        scheduler_thread_ = std::thread([this] { scheduler_thread_main(); });
    } catch (...) {
        scheduler_running_.store(false, std::memory_order_release);
        engine_->stop();
        error = "failed to create native arranger scheduler test thread";
        return false;
    }
    return true;
}
bool NativeArrangerRuntime::running() const noexcept {
    return scheduler_running_.load(std::memory_order_acquire);
}

bool NativeArrangerRuntime::queue_main(const std::string& name, std::string& error) {
    std::lock_guard<std::mutex> lock(mutex_);
    return require_engine(error) && engine_->queue_main(name, error);
}

bool NativeArrangerRuntime::queue_fill(const std::string& name, std::string& error) {
    std::lock_guard<std::mutex> lock(mutex_);
    return require_engine(error) && engine_->queue_fill(name, error);
}

bool NativeArrangerRuntime::queue_intro(const std::string& name, std::string& error) {
    std::lock_guard<std::mutex> lock(mutex_);
    return require_engine(error) && engine_->queue_intro(name, error);
}

bool NativeArrangerRuntime::queue_ending(const std::string& name, std::string& error) {
    std::lock_guard<std::mutex> lock(mutex_);
    return require_engine(error) && engine_->queue_ending(name, error);
}

void NativeArrangerRuntime::feed_midi(std::uint8_t status, std::uint8_t data1, std::uint8_t data2) noexcept {
    std::lock_guard<std::mutex> lock(mutex_);
    performance_.feed_midi(status, data1, data2);
    if (engine_) {
        const auto& ps = performance_.state();
        if (ps.chord_name != "No Chord")
            engine_->set_chord(ps.chord_root_pc, ps.chord_type, ps.chord_bass_pc, ps.chord_bass_valid);
        engine_->set_acmp(ps.acmp_enabled);
        engine_->set_transpose(ps.transpose);
    }
}

void NativeArrangerRuntime::clear_performance_notes() noexcept {
    std::lock_guard<std::mutex> lock(mutex_);
    performance_.clear_notes();
    if (engine_) {
        const auto& ps = performance_.state();
        if (ps.chord_name != "No Chord")
            engine_->set_chord(ps.chord_root_pc, ps.chord_type, ps.chord_bass_pc, ps.chord_bass_valid);
    }
}

void NativeArrangerRuntime::set_finger_mode(std::uint8_t mode) noexcept {
    std::lock_guard<std::mutex> lock(mutex_);
    performance_.set_finger_mode(mode);
    if (engine_) {
        const auto& ps = performance_.state();
        if (ps.chord_name != "No Chord")
            engine_->set_chord(ps.chord_root_pc, ps.chord_type, ps.chord_bass_pc, ps.chord_bass_valid);
    }
}

void NativeArrangerRuntime::set_split_point(int note) noexcept {
    std::lock_guard<std::mutex> lock(mutex_);
    performance_.set_split_point(note);
    if (engine_) {
        const auto& ps = performance_.state();
        if (ps.chord_name != "No Chord")
            engine_->set_chord(ps.chord_root_pc, ps.chord_type, ps.chord_bass_pc, ps.chord_bass_valid);
    }
}

void NativeArrangerRuntime::set_smart_chord_key(int root_pc) noexcept {
    std::lock_guard<std::mutex> lock(mutex_);
    performance_.set_smart_chord_key(root_pc);
    if (engine_) {
        const auto& ps = performance_.state();
        if (ps.chord_name != "No Chord")
            engine_->set_chord(ps.chord_root_pc, ps.chord_type, ps.chord_bass_pc, ps.chord_bass_valid);
    }
}

void NativeArrangerRuntime::set_smart_chord_type(std::uint8_t type) noexcept {
    std::lock_guard<std::mutex> lock(mutex_);
    performance_.set_smart_chord_type(type);
    if (engine_) {
        const auto& ps = performance_.state();
        if (ps.chord_name != "No Chord")
            engine_->set_chord(ps.chord_root_pc, ps.chord_type, ps.chord_bass_pc, ps.chord_bass_valid);
    }
}

void NativeArrangerRuntime::set_acmp(bool enabled) noexcept {
    std::lock_guard<std::mutex> lock(mutex_);
    performance_.set_acmp(enabled);
    if (engine_) engine_->set_acmp(enabled);
}

void NativeArrangerRuntime::set_chord(std::uint8_t root_pc, std::uint8_t chord_type) noexcept {
    std::lock_guard<std::mutex> lock(mutex_);
    performance_.set_chord(root_pc, chord_type);
    if (engine_) engine_->set_chord(root_pc, chord_type);
}

void NativeArrangerRuntime::set_transpose(int semitones) noexcept {
    std::lock_guard<std::mutex> lock(mutex_);
    performance_.set_transpose(semitones);
    if (engine_) engine_->set_transpose(performance_.state().transpose);
}

void NativeArrangerRuntime::set_tempo(double bpm) noexcept {
    if (!std::isfinite(bpm)) return;
    const double clamped = std::clamp(bpm, 30.0, 300.0);
    std::lock_guard<std::mutex> lock(mutex_);
    if (!engine_) { bpm_ = clamped; return; }
    if (scheduler_running_.load(std::memory_order_acquire)) {
        const auto now = Clock::now();
        tick_anchor_ = clock_tick_locked(now);
        clock_anchor_ = now;
        tick_anchor_ = engine_->current_tick() > tick_anchor_ ? engine_->current_tick() : tick_anchor_;
        // Reanchor exactly at the scheduler's current tick before changing tempo.
        reset_clock_locked(now);
    }
    bpm_ = clamped;
    audio_.set_timing(bpm_, engine_->division());
}

bool NativeArrangerRuntime::advance_to(std::uint32_t global_tick,
                                        std::vector<ArrangerOutputEvent>& out,
                                        std::string& error) {
    std::lock_guard<std::mutex> lock(mutex_);
    if (!require_engine(error)) return false;
    // NativeGuiPpfAudio uses a single-producer event ring. During realtime
    // playback the scheduler thread is that sole producer; deterministic
    // external advances must never race it.
    if (scheduler_running_.load(std::memory_order_acquire)) {
        error = "deterministic advance is unavailable while native realtime scheduler is running";
        return false;
    }
    if (!engine_->advance_to(global_tick, out, error)) return false;
    if (audio_.is_active() && !enqueue_events(out)) {
        error = "native audio event queue overflow";
        return false;
    }
    return true;
}

bool NativeArrangerRuntime::enqueue_events(const std::vector<ArrangerOutputEvent>& events) noexcept {
    if (!audio_.is_active()) return true;
    for (const auto& event : events) {
        if (!audio_.enqueue(event)) {
            scheduler_dropped_events_.fetch_add(1, std::memory_order_relaxed);
            return false;
        }
    }
    scheduler_event_batches_.fetch_add(1, std::memory_order_relaxed);
    return true;
}

void NativeArrangerRuntime::scheduler_thread_main() {
    auto last = Clock::now();
    while (scheduler_running_.load(std::memory_order_acquire)) {
        const auto now = Clock::now();
        if (now == last) {
            std::this_thread::yield();
            continue;
        }
        last = now;
        std::vector<ArrangerOutputEvent> events;
        std::string error;
        {
            std::lock_guard<std::mutex> lock(mutex_);
            if (!engine_) break;
            const auto target = clock_tick_locked(now);
            const auto previous = last_scheduled_tick_.load(std::memory_order_acquire);
            if (target > previous) {
                if (!engine_->advance_to(target, events, error)) {
                    scheduler_running_.store(false, std::memory_order_release);
                    break;
                }
                last_scheduled_tick_.store(target, std::memory_order_release);
            }
        }
        if (!events.empty()) {
            if (!enqueue_events(events)) {
                scheduler_running_.store(false, std::memory_order_release);
                break;
            }
        }
        std::this_thread::sleep_for(std::chrono::milliseconds(2));
    }
}


void NativeArrangerRuntime::handle_midi_input_short_message(std::uint32_t packed_message) noexcept {
    const std::uint8_t status = static_cast<std::uint8_t>(packed_message & 0xFFu);
    const std::uint8_t data1 = static_cast<std::uint8_t>((packed_message >> 8u) & 0x7Fu);
    const std::uint8_t data2 = static_cast<std::uint8_t>((packed_message >> 16u) & 0x7Fu);
    feed_midi(status, data1, data2);
}

bool NativeArrangerRuntime::set_audio_device_id(const std::string& device_id, std::string& error) {
    if (audio_.is_active()) {
        error = "audio device cannot be changed while native audio is running";
        return false;
    }
    audio_device_id_ = device_id;
    audio_.set_audio_device_id(device_id);
    error.clear();
    return true;
}

std::string NativeArrangerRuntime::audio_device_id() const {
    std::lock_guard<std::mutex> lock(mutex_);
    return audio_device_id_;
}

bool NativeArrangerRuntime::open_midi_input(std::uint32_t device_index, std::string& error) {
#ifdef _WIN32
    close_midi_input();
    const UINT count = midiInGetNumDevs();
    if (device_index >= count) {
        error = "MIDI IN device index is out of range";
        return false;
    }
    HMIDIIN h = nullptr;
    const MMRESULT rc = midiInOpen(&h, static_cast<UINT>(device_index),
                                   reinterpret_cast<DWORD_PTR>(&midi_in_proc),
                                   reinterpret_cast<DWORD_PTR>(this), CALLBACK_FUNCTION);
    if (rc != MMSYSERR_NOERROR) {
        error = "Windows MIDI IN could not be opened (MMRESULT " + std::to_string(rc) + ")";
        return false;
    }
    if (midiInStart(h) != MMSYSERR_NOERROR) {
        midiInClose(h);
        error = "Windows MIDI IN could not be started";
        return false;
    }
    midi_in_handle_ = h;
    midi_in_device_index_ = device_index;
    error.clear();
    return true;
#else
    (void)device_index;
    error = "Native MIDI IN requires Windows WinMM";
    return false;
#endif
}

void NativeArrangerRuntime::close_midi_input() noexcept {
#ifdef _WIN32
    HMIDIIN h = static_cast<HMIDIIN>(midi_in_handle_);
    midi_in_handle_ = nullptr;
    midi_in_device_index_ = 0xFFFFFFFFu;
    if (!h) return;
    midiInStop(h);
    midiInReset(h);
    midiInClose(h);
#else
    // MIDI IN is unavailable on non-Windows hosts.
#endif
}

bool NativeArrangerRuntime::midi_input_active() const noexcept {
#ifdef _WIN32
    return midi_in_handle_ != nullptr;
#else
    return false;
#endif
}

std::vector<std::string> NativeArrangerRuntime::midi_input_device_names() {
    std::vector<std::string> out;
#ifdef _WIN32
    const UINT count = midiInGetNumDevs();
    for (UINT i = 0; i < count; ++i) {
        MIDIINCAPSW caps{};
        if (midiInGetDevCapsW(i, &caps, sizeof(caps)) == MMSYSERR_NOERROR) {
            int needed = WideCharToMultiByte(CP_UTF8, 0, caps.szPname, -1, nullptr, 0, nullptr, nullptr);
            if (needed > 0) {
                std::string name(static_cast<std::size_t>(needed - 1), '\0');
                WideCharToMultiByte(CP_UTF8, 0, caps.szPname, -1, name.data(), needed, nullptr, nullptr);
                out.push_back(std::move(name));
            }
        }
    }
#endif
    return out;
}

#ifdef _WIN32
void CALLBACK NativeArrangerRuntime::midi_in_proc(HMIDIIN, UINT msg, DWORD_PTR instance,
                                                   DWORD_PTR param1, DWORD_PTR) {
    if (msg != MIM_DATA || !instance) return;
    auto* self = reinterpret_cast<NativeArrangerRuntime*>(instance);
    self->handle_midi_input_short_message(static_cast<std::uint32_t>(param1));
}
#endif

NativeArrangerRuntimeState NativeArrangerRuntime::state() const {
    NativeArrangerRuntimeState s;
    std::lock_guard<std::mutex> lock(mutex_);
    s.running = scheduler_running_.load(std::memory_order_acquire);
    s.audio_active = audio_.is_active();
    s.scheduler_active = s.running;
    s.bpm = bpm_;
    if (engine_) {
        s.acmp_enabled = engine_->acmp_enabled();
        s.transpose = engine_->transpose();
        s.division = engine_->division();
        s.transport_tick = engine_->current_tick();
        s.bar_ticks = engine_->bar_ticks();
        s.current_section = engine_->current_section();
        s.active_main = engine_->active_main();
    }
    return s;
}

PerformanceRuntimeState NativeArrangerRuntime::performance_state() const {
    std::lock_guard<std::mutex> lock(mutex_);
    return performance_.state();
}

} // namespace arranger
