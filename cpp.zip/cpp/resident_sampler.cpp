#include "resident_sampler.hpp"
#include <algorithm>
#include <cmath>

namespace arranger {

void ResidentSampler::atomic_max(std::atomic<std::uint64_t>& target, std::uint64_t value) noexcept {
    auto current = target.load(std::memory_order_relaxed);
    while (current < value &&
           !target.compare_exchange_weak(current, value,
                                         std::memory_order_release,
                                         std::memory_order_relaxed)) {}
}

void ResidentSampler::reset_signal_telemetry() noexcept {
    preclamp_over_unity_samples_.store(0, std::memory_order_release);
    preclamp_nonfinite_samples_.store(0, std::memory_order_release);
    preclamp_measured_samples_.store(0, std::memory_order_release);
    preclamp_max_peak_milli_.store(0, std::memory_order_release);
    for (auto& x : preclamp_part_over_unity_) x.store(0, std::memory_order_release);
    for (auto& x : preclamp_part_max_peak_milli_) x.store(0, std::memory_order_release);
}

bool ResidentSampler::note_on(const ResidentSamplePtr& sample,
                              std::uint8_t note,
                              std::uint8_t velocity,
                              float gain,
                              float pan,
                              double pitch_ratio) {
    return note_on(sample, note, velocity, gain, pan, pitch_ratio, 0, 0, false);
}

bool ResidentSampler::note_on(const ResidentSamplePtr& sample,
                              std::uint8_t note,
                              std::uint8_t velocity,
                              float gain,
                              float pan,
                              double pitch_ratio,
                              std::size_t loop_start_frame,
                              std::size_t loop_end_frame,
                              bool loop_enabled) {
    if (!sample || sample->pcm.empty() || sample->sample_rate <= 0 ||
        !std::isfinite(pitch_ratio) || pitch_ratio <= 0.0) return false;

    const std::size_t slot = find_reclaimable_slot();
    if (slot == kMaxVoices) return false;
    return note_on_at_slot(slot, sample, note, velocity, gain, pan, pitch_ratio,
                           loop_start_frame, loop_end_frame, loop_enabled);
}

bool ResidentSampler::note_on_at_slot(std::size_t slot,
                                       const ResidentSamplePtr& sample,
                                       std::uint8_t note,
                                       std::uint8_t velocity,
                                       float gain,
                                       float pan,
                                       double pitch_ratio,
                                       std::size_t loop_start_frame,
                                       std::size_t loop_end_frame,
                                       bool loop_enabled,
                                       std::uint8_t part_index,
                                       std::uint8_t alternate_group,
                                       bool receive_note_off,
                                       bool receive_note_on) noexcept {
    if (slot >= kMaxVoices || !sample || sample->pcm.empty() || sample->sample_rate <= 0 ||
        !std::isfinite(pitch_ratio) || pitch_ratio <= 0.0) return false;

    const std::size_t channels = (sample->channels == 2) ? 2u : 1u;
    const std::size_t frames = sample->pcm.size() / channels;
    if (frames == 0 || sample->pcm.size() != frames * channels) return false;
    bool valid_loop = loop_enabled && loop_end_frame > loop_start_frame + 1 && loop_start_frame < frames;
    if (valid_loop) loop_end_frame = std::min(loop_end_frame, frames);
    else { loop_start_frame = 0; loop_end_frame = 0; }

    auto& v = voices_[slot];
    v.sample = sample;
    v.source_pos = 0.0;
    v.step = pitch_ratio;
    v.base_pitch_ratio = pitch_ratio;
    v.pitch_bend_norm = 0.0f;
    v.pitch_bend_range = 2.0f;
    v.modulation = 0.0f;
    v.modulation_phase = 0.0;
    v.expression = 1.0f;
    v.gain = std::max(0.0f, gain) * (static_cast<float>(velocity) / 127.0f);
    v.pan = std::clamp(pan, -1.0f, 1.0f);
    v.note = note;
    v.velocity = velocity;
    v.part_index = static_cast<std::uint8_t>(part_index & 0x0F);
    v.alternate_group = alternate_group > 127u ? 0u : alternate_group;
    v.receive_note_off = receive_note_off;
    v.receive_note_on = receive_note_on;
    v.loop_enabled = valid_loop;
    v.releasing = false;
    v.key_down = true;
    v.sustain_held = false;
    v.loop_start = loop_start_frame;
    v.loop_end = loop_end_frame;
    v.age = next_age_++;
    if (next_age_ == 0) next_age_ = 1;
    v.release_remaining_seconds = 0.0;
    v.active = true;
    return true;
}

void ResidentSampler::note_off(std::uint8_t note) noexcept {
    for (auto& v : voices_) {
        if (!v.active || v.note != note || !v.receive_note_off) continue;
        v.key_down = false;
        v.sustain_held = false;
        v.releasing = true;
        v.release_remaining_seconds = kDefaultReleaseSeconds;
    }
}

void ResidentSampler::note_off_slot(std::size_t slot) noexcept {
    if (slot >= kMaxVoices) return;
    auto& v = voices_[slot];
    if (!v.active) return;
    v.key_down = false;
    v.sustain_held = false;
    v.releasing = true;
    v.release_remaining_seconds = kDefaultReleaseSeconds;
}

void ResidentSampler::defer_note_off_slot(std::size_t slot) noexcept {
    if (slot >= kMaxVoices) return;
    auto& v = voices_[slot];
    if (!v.active) return;
    v.key_down = false;
    if (!v.releasing) v.sustain_held = true;
}

void ResidentSampler::release_sustained_slot(std::size_t slot) noexcept {
    if (slot >= kMaxVoices) return;
    auto& v = voices_[slot];
    if (!v.active || !v.sustain_held) return;
    v.sustain_held = false;
    v.releasing = true;
    v.release_remaining_seconds = kDefaultReleaseSeconds;
}

void ResidentSampler::choke_alternate_group(std::size_t part, std::uint8_t alternate_group) noexcept {
    if (part >= kPartCount || alternate_group == 0u) return;
    for (auto& v : voices_) {
        if (!v.active || v.part_index != static_cast<std::uint8_t>(part) || v.alternate_group != alternate_group) continue;
        // Alternate Group is an immediate choke, not the normal 50 ms MIDI
        // Note-Off release. This mirrors Yamaha's open/close hi-hat behavior.
        v.active = false;
        v.releasing = false;
        v.key_down = false;
        v.sustain_held = false;
        v.release_remaining_seconds = 0.0;
        v.sample.reset();
    }
}

bool ResidentSampler::voice_active(std::size_t slot) const noexcept {
    return slot < kMaxVoices && voices_[slot].active;
}

bool ResidentSampler::voice_releasing(std::size_t slot) const noexcept {
    return slot < kMaxVoices && voices_[slot].active && voices_[slot].releasing;
}

std::uint8_t ResidentSampler::voice_note(std::size_t slot) const noexcept {
    return slot < kMaxVoices ? voices_[slot].note : 0;
}

std::uint8_t ResidentSampler::voice_part_index(std::size_t slot) const noexcept {
    return slot < kMaxVoices ? voices_[slot].part_index : 0xFF;
}

std::uint8_t ResidentSampler::voice_alternate_group(std::size_t slot) const noexcept {
    return slot < kMaxVoices ? voices_[slot].alternate_group : 0;
}

bool ResidentSampler::voice_receive_note_off(std::size_t slot) const noexcept {
    return slot < kMaxVoices && voices_[slot].active && voices_[slot].receive_note_off;
}

bool ResidentSampler::voice_receive_note_on(std::size_t slot) const noexcept {
    return slot < kMaxVoices && voices_[slot].active && voices_[slot].receive_note_on;
}

bool ResidentSampler::voice_key_down(std::size_t slot) const noexcept {
    return slot < kMaxVoices && voices_[slot].active && voices_[slot].key_down;
}

bool ResidentSampler::voice_sustain_held(std::size_t slot) const noexcept {
    return slot < kMaxVoices && voices_[slot].active && voices_[slot].sustain_held;
}

float ResidentSampler::voice_pitch_bend(std::size_t slot) const noexcept {
    return slot < kMaxVoices ? voices_[slot].pitch_bend_norm : 0.0f;
}

float ResidentSampler::voice_modulation(std::size_t slot) const noexcept {
    return slot < kMaxVoices ? voices_[slot].modulation : 0.0f;
}

float ResidentSampler::voice_expression(std::size_t slot) const noexcept {
    return slot < kMaxVoices ? voices_[slot].expression : 1.0f;
}

void ResidentSampler::set_part_pitch_bend(std::size_t part, float normalized, float range_semitones) noexcept {
    if (part >= 16 || !std::isfinite(normalized) || !std::isfinite(range_semitones)) return;
    normalized = std::clamp(normalized, -1.0f, 1.0f);
    range_semitones = std::clamp(range_semitones, 0.5f, 24.0f);
    const double semitones = static_cast<double>(normalized) * static_cast<double>(range_semitones);
    const double bend_ratio = std::pow(2.0, semitones / 12.0);
    if (!std::isfinite(bend_ratio) || bend_ratio <= 0.0) return;
    for (auto& v : voices_) {
        if (!v.active || v.part_index != static_cast<std::uint8_t>(part)) continue;
        v.pitch_bend_norm = normalized;
        v.pitch_bend_range = range_semitones;
        v.step = v.base_pitch_ratio * bend_ratio;
    }
}

void ResidentSampler::set_part_modulation(std::size_t part, float normalized) noexcept {
    if (part >= 16 || !std::isfinite(normalized)) return;
    normalized = std::clamp(normalized, 0.0f, 1.0f);
    for (auto& v : voices_) {
        if (!v.active || v.part_index != static_cast<std::uint8_t>(part)) continue;
        v.modulation = normalized;
    }
}

void ResidentSampler::set_part_expression(std::size_t part, float normalized) noexcept {
    if (part >= 16 || !std::isfinite(normalized)) return;
    normalized = std::clamp(normalized, 0.0f, 1.0f);
    for (auto& v : voices_) {
        if (!v.active || v.part_index != static_cast<std::uint8_t>(part)) continue;
        v.expression = normalized;
    }
}

void ResidentSampler::all_notes_off() noexcept {
    for (auto& v : voices_) {
        v.active = false;
        v.releasing = false;
        v.source_pos = 0.0;
        v.step = 1.0;
        v.base_pitch_ratio = 1.0;
        v.pitch_bend_norm = 0.0f;
        v.pitch_bend_range = 2.0f;
        v.modulation = 0.0f;
        v.modulation_phase = 0.0;
        v.expression = 1.0f;
        v.alternate_group = 0;
        v.receive_note_off = true;
        v.receive_note_on = true;
        v.key_down = false;
        v.sustain_held = false;
        v.release_remaining_seconds = 0.0;
        v.sample.reset();
    }
}

std::size_t ResidentSampler::render(float* out_stereo, std::size_t frames, int output_rate) noexcept {
    if (!out_stereo || frames == 0 || output_rate <= 0) return 0;

    std::fill_n(out_stereo, frames * 2, 0.0f);
    for (auto& v : voices_) {
        if (!v.active || !v.sample || v.sample->pcm.empty()) continue;
        const auto& pcm = v.sample->pcm;
        const std::size_t channels = (v.sample->channels == 2) ? 2u : 1u;
        const std::size_t sample_frames = pcm.size() / channels;
        const double source_step_base = (static_cast<double>(v.sample->sample_rate) /
                                          static_cast<double>(output_rate)) * v.step;
        if (!std::isfinite(source_step_base) || source_step_base <= 0.0) {
            v.active = false;
            v.sample.reset();
            continue;
        }

        const double p = static_cast<double>(v.pan) * 0.5 + 0.5;
        const float left_gain = channels == 1
            ? static_cast<float>(std::cos(p * 3.14159265358979323846 * 0.5) * v.gain)
            : static_cast<float>((v.pan <= 0.0f ? 1.0f : 1.0f - v.pan) * v.gain);
        const float right_gain = channels == 1
            ? static_cast<float>(std::sin(p * 3.14159265358979323846 * 0.5) * v.gain)
            : static_cast<float>((v.pan >= 0.0f ? 1.0f : 1.0f + v.pan) * v.gain);

        for (std::size_t i = 0; i < frames && v.active; ++i) {
            if (v.loop_enabled && v.source_pos >= static_cast<double>(v.loop_end)) {
                const double span = static_cast<double>(v.loop_end - v.loop_start);
                if (span > 1.0) {
                    v.source_pos = static_cast<double>(v.loop_start) +
                                   std::fmod(v.source_pos - static_cast<double>(v.loop_start), span);
                } else {
                    v.loop_enabled = false;
                }
            }

            if (v.source_pos >= static_cast<double>(sample_frames)) {
                v.active = false;
                v.sample.reset();
                break;
            }

            const std::size_t i0 = static_cast<std::size_t>(v.source_pos);
            const std::size_t i1 = std::min(i0 + 1, sample_frames - 1);
            const double frac = v.source_pos - static_cast<double>(i0);
            const std::size_t b0 = i0 * channels;
            const std::size_t b1 = i1 * channels;
            const float s0l = pcm[b0];
            const float s1l = pcm[b1];
            const float sample_l = static_cast<float>(static_cast<double>(s0l) +
                                                       (static_cast<double>(s1l) - static_cast<double>(s0l)) * frac);
            const float sample_r = channels == 2
                ? static_cast<float>(static_cast<double>(pcm[b0 + 1]) +
                                     (static_cast<double>(pcm[b1 + 1]) - static_cast<double>(pcm[b0 + 1])) * frac)
                : sample_l;

            float env = 1.0f;
            if (v.releasing) {
                env = static_cast<float>(std::clamp(v.release_remaining_seconds / kDefaultReleaseSeconds, 0.0, 1.0));
            }
            const double mod_ratio = 1.0 + 0.0293022366 * static_cast<double>(v.modulation) *
                                     std::sin(v.modulation_phase);
            out_stereo[i * 2] += sample_l * left_gain * env * v.expression;
            out_stereo[i * 2 + 1] += sample_r * right_gain * env * v.expression;

            v.source_pos += source_step_base * mod_ratio;
            v.modulation_phase += 2.0 * 3.14159265358979323846 * 5.5 / static_cast<double>(output_rate);
            if (v.modulation_phase >= 2.0 * 3.14159265358979323846)
                v.modulation_phase = std::fmod(v.modulation_phase, 2.0 * 3.14159265358979323846);
            if (v.releasing) {
                v.release_remaining_seconds -= 1.0 / static_cast<double>(output_rate);
                if (v.release_remaining_seconds <= 0.0) {
                    v.active = false;
                    v.sample.reset();
                    break;
                }
            }
        }

        if (v.active && !v.loop_enabled && !v.releasing && v.source_pos >= static_cast<double>(pcm.size() - 1)) {
            v.active = false;
            v.sample.reset();
        }
    }

    const std::size_t count = frames * 2;
    for (std::size_t i = 0; i < count; ++i) out_stereo[i] = std::clamp(out_stereo[i], -1.0f, 1.0f);
    return active_voice_count();
}

std::size_t ResidentSampler::render_to_parts(float* out_part_stereo,
                                                std::size_t frames,
                                                int output_rate) noexcept {
    constexpr std::size_t kRenderPartCount = 16;
    if (!out_part_stereo || frames == 0 || output_rate <= 0) return 0;

    std::fill_n(out_part_stereo, frames * kRenderPartCount * 2, 0.0f);
    for (auto& v : voices_) {
        if (!v.active || !v.sample || v.sample->pcm.empty()) continue;
        const auto& pcm = v.sample->pcm;
        const std::size_t channels = (v.sample->channels == 2) ? 2u : 1u;
        const std::size_t sample_frames = pcm.size() / channels;
        const double source_step_base = (static_cast<double>(v.sample->sample_rate) /
                                          static_cast<double>(output_rate)) * v.step;
        if (!std::isfinite(source_step_base) || source_step_base <= 0.0) {
            v.active = false;
            v.sample.reset();
            continue;
        }

        const std::size_t part = static_cast<std::size_t>(v.part_index & 0x0F);
        const std::size_t stride = kPartCount * 2;
        const std::size_t part_offset = part * 2;
        const float p = static_cast<float>(v.pan) * 0.5f + 0.5f;
        const float left_gain = channels == 1
            ? static_cast<float>(std::cos(p * 3.14159265358979323846 * 0.5) * v.gain)
            : static_cast<float>((v.pan <= 0.0f ? 1.0f : 1.0f - v.pan) * v.gain);
        const float right_gain = channels == 1
            ? static_cast<float>(std::sin(p * 3.14159265358979323846 * 0.5) * v.gain)
            : static_cast<float>((v.pan >= 0.0f ? 1.0f : 1.0f + v.pan) * v.gain);

        for (std::size_t i = 0; i < frames && v.active; ++i) {
            if (v.loop_enabled && v.source_pos >= static_cast<double>(v.loop_end)) {
                const double span = static_cast<double>(v.loop_end - v.loop_start);
                if (span > 1.0) {
                    v.source_pos = static_cast<double>(v.loop_start) +
                                   std::fmod(v.source_pos - static_cast<double>(v.loop_start), span);
                } else {
                    v.loop_enabled = false;
                }
            }

            if (v.source_pos >= static_cast<double>(sample_frames)) {
                v.active = false;
                v.sample.reset();
                break;
            }

            const std::size_t i0 = static_cast<std::size_t>(v.source_pos);
            const std::size_t i1 = std::min(i0 + 1, sample_frames - 1);
            const double frac = v.source_pos - static_cast<double>(i0);
            const std::size_t b0 = i0 * channels;
            const std::size_t b1 = i1 * channels;
            const float s0l = pcm[b0];
            const float s1l = pcm[b1];
            const float sample_l = static_cast<float>(static_cast<double>(s0l) +
                                                       (static_cast<double>(s1l) - static_cast<double>(s0l)) * frac);
            const float sample_r = channels == 2
                ? static_cast<float>(static_cast<double>(pcm[b0 + 1]) +
                                     (static_cast<double>(pcm[b1 + 1]) - static_cast<double>(pcm[b0 + 1])) * frac)
                : sample_l;

            float env = 1.0f;
            if (v.releasing) {
                env = static_cast<float>(std::clamp(v.release_remaining_seconds / kDefaultReleaseSeconds, 0.0, 1.0));
            }
            const std::size_t base = i * stride + part_offset;
            const double mod_ratio = 1.0 + 0.0293022366 * static_cast<double>(v.modulation) *
                                     std::sin(v.modulation_phase);
            out_part_stereo[base] += sample_l * left_gain * env * v.expression;
            out_part_stereo[base + 1] += sample_r * right_gain * env * v.expression;

            v.source_pos += source_step_base * mod_ratio;
            v.modulation_phase += 2.0 * 3.14159265358979323846 * 5.5 / static_cast<double>(output_rate);
            if (v.modulation_phase >= 2.0 * 3.14159265358979323846)
                v.modulation_phase = std::fmod(v.modulation_phase, 2.0 * 3.14159265358979323846);
            if (v.releasing) {
                v.release_remaining_seconds -= 1.0 / static_cast<double>(output_rate);
                if (v.release_remaining_seconds <= 0.0) {
                    v.active = false;
                    v.sample.reset();
                    break;
                }
            }
        }

        if (v.active && !v.loop_enabled && !v.releasing && v.source_pos >= static_cast<double>(pcm.size() - 1)) {
            v.active = false;
            v.sample.reset();
        }
    }

    for (std::size_t i = 0; i < frames * kRenderPartCount * 2; ++i) {
        const float value = out_part_stereo[i];
        if (!std::isfinite(value)) {
            preclamp_nonfinite_samples_.fetch_add(1, std::memory_order_relaxed);
        } else {
            const float av = std::fabs(value);
            const std::size_t part = (i / 2) % kPartCount;
            if (av > 1.0f) {
                preclamp_over_unity_samples_.fetch_add(1, std::memory_order_relaxed);
                preclamp_part_over_unity_[part].fetch_add(1, std::memory_order_relaxed);
            }
            const auto peak_milli = static_cast<std::uint64_t>(std::llround(av * 1000.0f));
            atomic_max(preclamp_max_peak_milli_, peak_milli);
            atomic_max(preclamp_part_max_peak_milli_[part], peak_milli);
        }
        preclamp_measured_samples_.fetch_add(1, std::memory_order_relaxed);
        out_part_stereo[i] = value;
    }
    return active_voice_count();
}

std::size_t ResidentSampler::find_reclaimable_slot() const noexcept {
    for (std::size_t i = 0; i < kMaxVoices; ++i) {
        if (!voices_[i].active) return i;
    }
    std::size_t best = kMaxVoices;
    std::uint64_t best_age = UINT64_MAX;
    // Reclaim the oldest released voice first.
    for (std::size_t i = 0; i < kMaxVoices; ++i) {
        const auto& v = voices_[i];
        if (v.active && v.releasing && v.age < best_age) { best = i; best_age = v.age; }
    }
    if (best != kMaxVoices) return best;
    // Sustained/active notes are the last resort.
    for (std::size_t i = 0; i < kMaxVoices; ++i) {
        const auto& v = voices_[i];
        if (v.active && v.age < best_age) { best = i; best_age = v.age; }
    }
    return best;
}

std::size_t ResidentSampler::active_voice_count() const noexcept {
    std::size_t count = 0;
    for (const auto& v : voices_) if (v.active) ++count;
    return count;
}

std::size_t ResidentSampler::releasing_voice_count() const noexcept {
    std::size_t count = 0;
    for (const auto& v : voices_) if (v.active && v.releasing) ++count;
    return count;
}

} // namespace arranger
